# NOOR AL HUDA ISLAMIC SHOP
## Complete Environment Variables & Service Configuration Guide

> **Security Rule:** Server secrets (such as `GOOGLE_PRIVATE_KEY` and service account keys) are **strictly backend variables** and must **NEVER** have the `VITE_` prefix, nor be committed to public repositories or bundled into frontend JavaScript.

---

### Variable Audit & Reference Table

| Variable Name | Layer | Mandatory / Optional | Exact Dashboard & Menu Location | Safe Example Format |
|---|---|---|---|---|
| `PORT` | **Backend** | Optional (defaults to `3000`) | Server environment settings or Cloud Run port | `3000` |
| `APP_URL` | **Backend** | Optional (auto-set in Cloud Run) | Google Cloud Run > Service details > URL | `https://ais-dev-...run.app` |
| `GEMINI_API_KEY` | **Backend** | Optional (Injected by AI Studio) | Google AI Studio > Secrets Panel | `AIzaSyD...` |
| `GOOGLE_SPREADSHEET_ID` | **Backend** | Optional (Required for live Sheets sync) | Google Sheets (open sheet in Chrome) > Browser URL bar between `/d/` and `/edit` | `1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms` |
| `GOOGLE_SERVICE_ACCOUNT_EMAIL` | **Backend** | Optional (Required for live Sheets/Drive sync) | Google Cloud Console > IAM & Admin > Service Accounts | `noor-backend@noor-al-huda-2026.iam.gserviceaccount.com` |
| `GOOGLE_PRIVATE_KEY` | **Backend (Secret)** | Optional (Required for live Sheets/Drive sync) | Google Cloud Console > IAM & Admin > Service Accounts > Keys tab > JSON file (`private_key` field) | `"-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFA...\n-----END PRIVATE KEY-----\n"` |
| `GOOGLE_DRIVE_FOLDER_ID` | **Backend** | Optional (Required for live Drive uploads) | Google Drive > Open `NOOR AL HUDA ISLAMIC SHOP` folder > URL after `/folders/` | `1AbCdEfGhIjKlMnOpQrStUvWxYz12345` |
| `VITE_STORE_NAME` | **Frontend** | Optional (defaults to `NOOR AL HUDA ISLAMIC SHOP`) | Custom store branding name | `NOOR AL HUDA ISLAMIC SHOP` |
| `VITE_OWNER_EMAIL` | **Frontend & Backend** | Optional (defaults to `uskshayeem@gmail.com`) | Store Owner primary email address | `uskshayeem@gmail.com` |
| `VITE_WHATSAPP_NUMBER` | **Frontend & Backend** | Optional (defaults to `+91 7003735250`) | WhatsApp Business app profile phone | `+91 7003735250` |
| `VITE_FIREBASE_API_KEY` | **Frontend (Public)** | Optional (Required for client Firebase Auth) | Firebase Console > Project Settings > General > Your apps (Web) > `apiKey` | `AIzaSyBv_AbCdEfGhIjKlMnOpQrStUvWxYz` |
| `VITE_FIREBASE_AUTH_DOMAIN` | **Frontend (Public)** | Optional (Required for client Firebase Auth) | Firebase Console > Project Settings > General > `authDomain` | `noor-al-huda-shop.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | **Frontend & Backend** | Optional (Required for client Firebase Auth) | Firebase Console > Project Settings > General > `projectId` | `noor-al-huda-shop` |
| `VITE_FIREBASE_STORAGE_BUCKET`| **Frontend (Public)** | Optional | Firebase Console > Project Settings > General > `storageBucket` | `noor-al-huda-shop.appspot.com` |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | **Frontend (Public)** | Optional | Firebase Console > Project Settings > General > `messagingSenderId` | `231074056791` |
| `VITE_FIREBASE_APP_ID` | **Frontend (Public)** | Optional | Firebase Console > Project Settings > General > `appId` | `1:231074056791:web:abcdef123456` |

---

### Step-by-Step Mobile (Android Chrome) Setup Guide

You can complete this entire configuration using **Google Chrome on your Android smartphone** by following these instructions:

#### 1. Obtaining Google Sheets Database ID
1. Open the **Google Sheets app** or visit [sheets.google.com](https://sheets.google.com) in Chrome.
2. Tap **+ (Create new spreadsheet)** and name it: `NOOR AL HUDA PRODUCTION DATABASE`.
3. In Chrome, switch to **"Desktop site"** (tap the 3 dots in the top-right corner of Chrome > check *Desktop site*).
4. Tap the address bar. The URL will look like:
   `https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit`
5. Copy the long string of letters and numbers between `/d/` and `/edit`.
   That value is your `GOOGLE_SPREADSHEET_ID`.

#### 2. Obtaining Google Drive Folder ID
1. Open [drive.google.com](https://drive.google.com) in Chrome (enable **"Desktop site"** mode).
2. Tap **New > New Folder** and name it `NOOR AL HUDA ISLAMIC SHOP`.
3. Tap into the folder. The address bar will show:
   `https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrStUvWxYz12345`
4. The string after `/folders/` is your `GOOGLE_DRIVE_FOLDER_ID`.

#### 3. Creating Google Cloud Service Account (for Sheets & Drive API)
1. Open [console.cloud.google.com](https://console.cloud.google.com) in Chrome.
2. Tap the top navigation bar and select your Google Cloud Project.
3. Open the left menu (3 horizontal lines) > **APIs & Services > Library**.
4. Search for **Google Sheets API** and tap **Enable**.
5. Search for **Google Drive API** and tap **Enable**.
6. Open menu > **IAM & Admin > Service Accounts**.
7. Tap **+ Create Service Account**:
   - Name: `noor-backend`
   - Tap **Create and Continue**, then **Done**.
8. Tap on the created service account email. Copy the email address (e.g. `noor-backend@<project-id>.iam.gserviceaccount.com`).
   That value is your `GOOGLE_SERVICE_ACCOUNT_EMAIL`.
9. Tap the **Keys** tab at the top > **Add Key > Create new key > JSON > Create**.
10. The JSON file downloads to your phone's *Downloads* folder.
11. Open the downloaded `.json` file in any text editor. Copy the value of the `"private_key"` field (including `-----BEGIN PRIVATE KEY-----` and `-----END PRIVATE KEY-----`).
    That value is your `GOOGLE_PRIVATE_KEY`.

#### 4. Sharing Google Sheet & Drive Folder with Service Account
- Open your Google Spreadsheet > Tap **Share** > Paste your `GOOGLE_SERVICE_ACCOUNT_EMAIL` > Set role to **Editor** > Tap **Send**.
- Open your Google Drive folder > Tap **Share** > Paste your `GOOGLE_SERVICE_ACCOUNT_EMAIL` > Set role to **Editor** > Tap **Send**.

#### 5. Obtaining Firebase Authentication Web Keys
1. Open [console.firebase.google.com](https://console.firebase.google.com) in Chrome.
2. Select your project or tap **Add project**.
3. In the left menu, tap **Build > Authentication > Get started**.
4. Under the **Sign-in method** tab, tap **Email/Password** > Enable **Email/Password** > Tap **Save**.
5. Tap the **Gear icon (Project Settings)** next to Project Overview.
6. Under the **General** tab, scroll down to **Your apps** > Tap the **Web icon (</>)**.
7. Register the app name (e.g., `Noor Al Huda Web`).
8. You will see a `firebaseConfig` snippet. Copy the corresponding values:
   - `apiKey` → `VITE_FIREBASE_API_KEY`
   - `authDomain` → `VITE_FIREBASE_AUTH_DOMAIN`
   - `projectId` → `VITE_FIREBASE_PROJECT_ID`
   - `storageBucket` → `VITE_FIREBASE_STORAGE_BUCKET`
   - `messagingSenderId` → `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `appId` → `VITE_FIREBASE_APP_ID`

---

### How to Test Each Connection and Resolve Errors

1. **How to Test in the Admin Dashboard:**
   - Log in as the owner (`uskshayeem@gmail.com`) to open the **Admin Control Panel**.
   - Navigate to **Google Sheets & Drive Hub (`/admin/google-sheets`)**.
   - Tap the button: **"Test Live Connections"**.
   - The system checks each service live and displays a status card.

2. **Error Resolution Guide:**

| Error Message | Cause | Resolution |
|---|---|---|
| `PERMISSION_DENIED` on Google Sheets | Spreadsheet was not shared with the service account | Open the Google Sheet, tap **Share**, and grant **Editor** access to `GOOGLE_SERVICE_ACCOUNT_EMAIL`. |
| `Spreadsheet ID not found` | Typos in the `GOOGLE_SPREADSHEET_ID` | Check the URL in the browser bar; copy only the characters between `/d/` and `/edit`. |
| `Invalid Private Key format` | Newline characters `\n` were escaped incorrectly | Ensure the private key preserves `\n` characters and includes the full `BEGIN` and `END` header/footer. |
| `Drive folder not writable` | Service account lacks editor role on Drive folder | Open Drive folder > **Share** > add `GOOGLE_SERVICE_ACCOUNT_EMAIL` as **Editor**. |
| `auth/api-key-not-valid` | Typo in `VITE_FIREBASE_API_KEY` | Re-copy the `apiKey` string from Firebase Project Settings. |
