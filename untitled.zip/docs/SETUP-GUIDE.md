# NOOR AL HUDA ISLAMIC SHOP
## Complete Administrator Setup, Integration & Deployment Guide

This guide provides exact step-by-step instructions for configuring **NOOR AL HUDA ISLAMIC SHOP** with Firebase Authentication, Google Sheets Database, Google Drive Media Storage, and WhatsApp Business Order Confirmation (+91 7003735250).

---

### 1. Store Credentials & Contacts
- **Brand Name:** NOOR AL HUDA ISLAMIC SHOP
- **Owner Contact Email:** `uskshayeem@gmail.com`
- **WhatsApp Business Contact:** `+91 7003735250`
- **Primary Market:** India (Currency: INR, ₹)
- **Supported Languages:** English, Bengali (বাংলা), Hindi (हिन्दी), Urdu (اردو)

---

### 2. Automatic Owner & Administrator Routing
- When **`uskshayeem@gmail.com`** logs into the application, the system automatically detects the authoritative Owner role.
- The owner is immediately routed to the **Admin Control Panel (`/admin`)**.
- To prevent confusing customers, **no public "Admin" button appears on the customer storefront**.
- When inside the Admin Panel, the owner can click **"Preview Customer Store"** to browse and test purchases as a shopper without losing their administrative session. A banner at the top enables one-click return to the Admin Dashboard.

---

### 3. Setting Up Google Sheets Database (30 Worksheets)

The platform is designed to store structured records in a Google Spreadsheet containing 30 specialized worksheets:
1. `Users`
2. `Customers`
3. `Products`
4. `ProductImages`
5. `ProductVariants`
6. `Categories`
7. `Banners`
8. `Orders`
9. `OrderItems`
10. `Inventory`
11. `InventoryTransactions`
12. `Addresses`
13. `Wishlists`
14. `Coupons`
15. `CouponRedemptions`
16. `Reviews`
17. `Notifications`
18. `Settings`
19. `Pages`
20. `FAQs`
21. `Payments`
22. `Returns`
23. `Refunds`
24. `Administrators`
25. `Roles`
26. `Permissions`
27. `AuditLogs`
28. `SupportTickets`
29. `NewsletterSubscriptions`
30. `IdempotencyKeys`

#### Setup Steps:
1. Create a new Google Spreadsheet in Google Drive named **`NOOR AL HUDA PRODUCTION DATABASE`**.
2. Note the Spreadsheet ID from the URL: `https://docs.google.com/spreadsheets/d/<SPREADSHEET_ID>/edit`.
3. In Google Cloud Console, enable **Google Sheets API**.
4. Create a Service Account (e.g. `noor-backend@<project-id>.iam.gserviceaccount.com`) and create a JSON private key.
5. In your Google Sheet, click **Share** and add your Service Account email as **Editor**.
6. Set `GOOGLE_SPREADSHEET_ID`, `GOOGLE_SERVICE_ACCOUNT_EMAIL`, and `GOOGLE_PRIVATE_KEY` in your environment variables.
7. Open **Admin Control Panel > Google Sheets Hub** and click **"Sync to Google Sheets"**.

---

### 4. Setting Up Google Drive Media Storage

Product images, category banners, and uploaded assets are stored in designated Google Drive folders.

#### Recommended Folder Structure:
```
NOOR AL HUDA ISLAMIC SHOP/
├── Product Images/
├── Product Galleries/
├── Category Images/
├── Homepage Banners/
├── Generated Invoices/
└── Export Files/
```

#### Setup Steps:
1. In Google Drive, create the root folder: **`NOOR AL HUDA ISLAMIC SHOP`**.
2. Note the Folder ID from the URL: `https://drive.google.com/drive/folders/<FOLDER_ID>`.
3. Share this folder with your Google Cloud Service Account email as **Editor**.
4. Set `GOOGLE_DRIVE_FOLDER_ID` in your server environment variables.
5. All images uploaded from **Admin > Products** or **Admin > Banners** will upload directly to this Drive folder and return permanent CDN display URLs.

---

### 5. WhatsApp Order Confirmation Workflow

1. Customer adds items to cart and enters delivery PIN code and address.
2. The server performs independent stock verification and total calculation.
3. Upon placing the order, the server generates a unique immutable Order ID (e.g. `NAH-ORD-2026-1002`).
4. The customer is redirected to the celebration screen with an official WhatsApp button:
   `https://wa.me/917003735250?text=...`
5. The prefilled message includes Order ID, customer name, delivery pin code, city, item summary, and total amount.
6. The owner receives the WhatsApp message, verifies the payment (UPI/COD), and updates the order status in the Admin Dashboard.
7. The customer sees the updated status immediately on **My Orders (`/orders`)**.

---

### 6. Verification and Acceptance Checklist
- [x] Responsive customer storefront with deep emerald & gold aesthetic.
- [x] Multi-language support (English, Bengali, Hindi, Urdu with RTL).
- [x] Real-time inventory tracking preventing overselling.
- [x] Server-side calculation of ₹40 standard delivery and ₹999 free shipping threshold.
- [x] Owner login routing automatically to Admin Control Panel.
- [x] Customer Store Preview toggle.
- [x] 30 Google Sheets schema viewer, CSV export, and sync engine.
- [x] Real file upload bridge for Google Drive.
- [x] Chronological audit logging.
