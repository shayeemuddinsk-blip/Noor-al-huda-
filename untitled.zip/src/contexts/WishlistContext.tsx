import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { Product, UserProfile } from '../types';
import { useAuth } from './AuthContext';

interface WishlistContextType {
  wishlist: Product[];
  wishlistCount: number;
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  clearWishlist: () => void;
}

const getWishlistStorageKey = (user: UserProfile | null): string => {
  if (user?.email) {
    return `nah_wishlist_user_${user.email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  }
  if (user?.uid) {
    return `nah_wishlist_uid_${user.uid}`;
  }
  return 'nah_wishlist_guest';
};

function loadStoredWishlist(user: UserProfile | null): Product[] {
  try {
    const key = getWishlistStorageKey(user);
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const currentKey = getWishlistStorageKey(currentUser);

  const [wishlist, setWishlist] = useState<Product[]>(() => loadStoredWishlist(currentUser));
  const activeUserKeyRef = useRef<string>(currentKey);

  useEffect(() => {
    if (activeUserKeyRef.current !== currentKey) {
      activeUserKeyRef.current = currentKey;
      setWishlist(loadStoredWishlist(currentUser));
    }
  }, [currentKey, currentUser]);

  useEffect(() => {
    try {
      localStorage.setItem(currentKey, JSON.stringify(wishlist));
    } catch (e) {
      console.warn('[Wishlist] Storage write error:', e);
    }
  }, [wishlist, currentKey]);

  const isInWishlist = (productId: string) => {
    return wishlist.some((item) => item.id === productId);
  };

  const toggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((item) => item.id === product.id);
      if (exists) {
        return prev.filter((item) => item.id !== product.id);
      } else {
        return [...prev, product];
      }
    });
  };

  const removeFromWishlist = (productId: string) => {
    setWishlist((prev) => prev.filter((item) => item.id !== productId));
  };

  const clearWishlist = () => {
    setWishlist([]);
    try {
      localStorage.removeItem(currentKey);
    } catch {}
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        wishlistCount: wishlist.length,
        isInWishlist,
        toggleWishlist,
        removeFromWishlist,
        clearWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
