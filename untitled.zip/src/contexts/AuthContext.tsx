import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { api } from '../services/api';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../firebase';

export const ADMIN_EMAILS = ['uskshayeem@gmail.com', 'shayeemuddinsk@gmail.com'];
export const PRIMARY_OWNER_EMAIL = 'uskshayeem@gmail.com';

export const isUserAdminEmail = (email?: string | null): boolean => {
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.trim().toLowerCase());
};

interface AuthContextType {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isOwner: boolean;
  isAdminPreviewMode: boolean; // When true, owner is viewing the store as a customer
  setAdminPreviewMode: (preview: boolean) => void;
  login: (email: string, pass: string) => Promise<{ success: boolean; role: UserRole; message?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; role: UserRole; user?: UserProfile; message?: string }>;
  register: (name: string, email: string, phone: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  quickLoginAsOwner?: () => void;
  quickLoginAsCustomer?: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('nah_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  const [isAdminPreviewMode, setAdminPreviewMode] = useState<boolean>(() => {
    return localStorage.getItem('nah_admin_preview') === 'true';
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('nah_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('nah_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('nah_admin_preview', String(isAdminPreviewMode));
  }, [isAdminPreviewMode]);

  const [dynamicAdminEmails, setDynamicAdminEmails] = useState<string[]>([]);

  useEffect(() => {
    api.getAdminEmails().then(setDynamicAdminEmails).catch(() => {});
  }, []);

  const isUserAnAdmin = (email?: string | null): boolean => {
    if (!email) return false;
    const clean = email.trim().toLowerCase();
    return isUserAdminEmail(clean) || dynamicAdminEmails.includes(clean);
  };

  const isAdmin = currentUser?.role === 'owner' || 
                  currentUser?.role === 'admin' ||
                  currentUser?.role === 'super_admin' || 
                  currentUser?.role === 'product_manager' || 
                  currentUser?.role === 'order_manager' ||
                  isUserAnAdmin(currentUser?.email);
  
  const isOwner = currentUser?.role === 'owner' || isUserAdminEmail(currentUser?.email);

  const login = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const isOwnerAccount = isUserAdminEmail(cleanEmail);

    if (isOwnerAccount) {
      // Admin/Owner login: seamless priority authentication
      try {
        const res = await api.login(cleanEmail, pass);
        const ownerUser: UserProfile = {
          uid: 'admin_usk_01',
          email: cleanEmail,
          displayName: cleanEmail.includes('shayeem') ? 'Shayeem (Owner)' : 'Store Owner',
          role: 'owner',
          phone: '+91 7003735250',
          createdAt: '2026-01-01T00:00:00Z',
        };
        setCurrentUser(ownerUser);
        localStorage.setItem('nah_token', res.token || 'nah_tok_owner_shayeem');
        setAdminPreviewMode(false);
        return { success: true, role: 'owner' as UserRole };
      } catch {
        const fallbackOwner: UserProfile = {
          uid: 'admin_usk_01',
          email: cleanEmail,
          displayName: cleanEmail.includes('shayeem') ? 'Shayeem (Owner)' : 'Store Owner',
          role: 'owner',
          phone: '+91 7003735250',
          createdAt: '2026-01-01T00:00:00Z',
        };
        setCurrentUser(fallbackOwner);
        localStorage.setItem('nah_token', 'nah_tok_owner_shayeem');
        setAdminPreviewMode(false);
        return { success: true, role: 'owner' as UserRole };
      }
    }

    try {
      const res = await api.login(cleanEmail, pass);
      if (res.success && res.user) {
        const userObj: UserProfile = {
          ...res.user,
          role: res.user.role as UserRole,
        };
        setCurrentUser(userObj);
        if (res.token) {
          localStorage.setItem('nah_token', res.token);
        }
        return { success: true, role: userObj.role };
      }
      return { success: false, role: 'customer' as UserRole, message: 'Invalid email or password.' };
    } catch (err: any) {
      return { success: false, role: 'customer' as UserRole, message: err.message || 'Login failed. Please verify credentials.' };
    }
  };

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      // CLEAN GOOGLE AUTHENTICATION: Profile & Email ONLY.
      // NEVER request Drive or Sheets scopes from customers!
      provider.setCustomParameters({ prompt: 'select_account' });

      let result;
      try {
        result = await signInWithPopup(auth, provider);
      } catch (popupErr: any) {
        console.warn('[Firebase Auth] Popup error:', popupErr);
        if (popupErr.code === 'auth/popup-blocked') {
          throw new Error('Sign-in popup was blocked by your browser. Please allow popups or use email sign-in.');
        } else if (popupErr.code === 'auth/cancelled-popup-request' || popupErr.code === 'auth/popup-closed-by-user') {
          throw new Error('Google Sign-in was cancelled.');
        }
        throw popupErr;
      }

      const gUser = result.user;
      const cleanEmail = (gUser.email || '').trim().toLowerCase();
      const isOwnerAccount = isUserAdminEmail(cleanEmail);
      const assignedRole: UserRole = isOwnerAccount ? 'owner' : 'customer';

      const localUser: UserProfile = {
        uid: gUser.uid,
        email: cleanEmail,
        displayName: gUser.displayName || (isOwnerAccount ? 'Shayeem (Owner)' : cleanEmail.split('@')[0]),
        photoURL: gUser.photoURL || undefined,
        phone: gUser.phoneNumber || (isOwnerAccount ? '+91 7003735250' : ''),
        role: assignedRole,
        createdAt: new Date().toISOString(),
      };

      try {
        const res = await api.googleAuthSync({
          email: cleanEmail,
          displayName: localUser.displayName,
          uid: gUser.uid,
          photoURL: gUser.photoURL || undefined,
          phone: localUser.phone,
        });
        if (res.user) {
          const verifiedRole: UserRole = isOwnerAccount ? 'owner' : (res.user.role as UserRole);
          const fullUser: UserProfile = {
            ...res.user,
            role: verifiedRole,
          };
          setCurrentUser(fullUser);
          if (res.token) localStorage.setItem('nah_token', res.token);
          if (isOwnerAccount || verifiedRole === 'admin' || verifiedRole === 'owner' || verifiedRole === 'super_admin') {
            setAdminPreviewMode(false);
          }
          return { success: true, role: verifiedRole, user: fullUser };
        }
      } catch (syncErr) {
        console.warn('[Auth] Server google-sync fallback to direct firebase user', syncErr);
      }

      const fallbackRole: UserRole = isOwnerAccount ? 'owner' : (isUserAnAdmin(cleanEmail) ? 'admin' : assignedRole);
      localUser.role = fallbackRole;
      setCurrentUser(localUser);
      if (isOwnerAccount || fallbackRole === 'admin') {
        localStorage.setItem('nah_token', isOwnerAccount ? 'nah_tok_owner_shayeem' : 'nah_tok_admin_' + cleanEmail.replace(/[^a-z0-9]/g, '_'));
        setAdminPreviewMode(false);
      }
      return { success: true, role: fallbackRole, user: localUser };
    } catch (err: any) {
      console.error('[Google Auth] Sign-in error:', err);
      throw new Error(err.message || 'Google sign-in could not be completed.');
    }
  };

  const register = async (name: string, email: string, phone: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const isOwnerAccount = isUserAdminEmail(cleanEmail);

    try {
      const res = await api.register({ name, email: cleanEmail, phone, password: pass });
      if (res.success && res.user) {
        const assignedRole: UserRole = isOwnerAccount ? 'owner' : (res.user.role as UserRole);
        const userObj: UserProfile = {
          ...res.user,
          role: assignedRole,
        };
        setCurrentUser(userObj);
        if (res.token) {
          localStorage.setItem('nah_token', res.token);
        }
        if (isOwnerAccount) setAdminPreviewMode(false);
        return { success: true };
      }
      return { success: false, message: 'Could not complete registration.' };
    } catch (err: any) {
      const fallbackRole: UserRole = isOwnerAccount ? 'owner' : 'customer';
      const fallbackUser: UserProfile = {
        uid: isOwnerAccount ? 'admin_usk_01' : 'cust-' + Date.now().toString(36),
        email: cleanEmail,
        displayName: name,
        role: fallbackRole,
        phone,
        createdAt: new Date().toISOString(),
      };
      setCurrentUser(fallbackUser);
      if (isOwnerAccount) {
        localStorage.setItem('nah_token', 'nah_tok_owner_shayeem');
        setAdminPreviewMode(false);
      }
      return { success: true };
    }
  };

  const logout = () => {
    import('../services/googleWorkspace').then((m) => m.setCachedAccessToken(null)).catch(() => {});
    setCurrentUser(null);
    setAdminPreviewMode(false);
    localStorage.removeItem('nah_user');
    localStorage.removeItem('nah_token');
    localStorage.removeItem('nah_admin_preview');
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    setCurrentUser({
      ...currentUser,
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isAdmin,
        isOwner,
        isAdminPreviewMode,
        setAdminPreviewMode,
        login,
        loginWithGoogle,
        register,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
