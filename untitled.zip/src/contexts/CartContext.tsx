import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { CartItem, Product, ProductVariant, Coupon, UserProfile } from '../types';
import { api } from '../services/api';
import { useAuth } from './AuthContext';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discountAmount: number;
  deliveryCharge: number;
  freeDeliveryThreshold: number;
  freeDeliveryEligible: boolean;
  amountNeededForFreeDelivery: number;
  totalAmount: number;
  coupon: Coupon | null;
  couponError: string | null;
  addToCart: (product: Product, variant?: ProductVariant, quantity?: number) => boolean;
  updateQuantity: (productId: string, variantId: string | undefined, quantity: number) => void;
  removeFromCart: (productId: string, variantId?: string) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
}

const FREE_DELIVERY_THRESHOLD = 999;
const STANDARD_DELIVERY_CHARGE = 40;

const getCartStorageKey = (user: UserProfile | null): string => {
  if (user?.email) {
    return `nah_cart_user_${user.email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  }
  if (user?.uid) {
    return `nah_cart_uid_${user.uid}`;
  }
  return 'nah_cart_guest';
};

const getCouponStorageKey = (user: UserProfile | null): string => {
  if (user?.email) {
    return `nah_coupon_user_${user.email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  }
  if (user?.uid) {
    return `nah_coupon_uid_${user.uid}`;
  }
  return 'nah_coupon_guest';
};

function loadStoredItems(user: UserProfile | null): CartItem[] {
  try {
    const key = getCartStorageKey(user);
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

function loadStoredCoupon(user: UserProfile | null): Coupon | null {
  try {
    const key = getCouponStorageKey(user);
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const currentKey = getCartStorageKey(currentUser);
  const currentCouponKey = getCouponStorageKey(currentUser);

  const [items, setItems] = useState<CartItem[]>(() => loadStoredItems(currentUser));
  const [coupon, setCoupon] = useState<Coupon | null>(() => loadStoredCoupon(currentUser));
  const [couponError, setCouponError] = useState<string | null>(null);

  // Track the user identity to handle login/logout/switch account transitions cleanly
  const activeUserKeyRef = useRef<string>(currentKey);

  useEffect(() => {
    // If the active user has changed (e.g., login from guest to Customer 1, switch Customer 1 to Customer 2, or logout)
    if (activeUserKeyRef.current !== currentKey) {
      activeUserKeyRef.current = currentKey;
      const userItems = loadStoredItems(currentUser);
      const userCoupon = loadStoredCoupon(currentUser);
      setItems(userItems);
      setCoupon(userCoupon);
      setCouponError(null);

      // Sync from backend database if authenticated
      if (currentUser?.email) {
        api.getUserCart(currentUser.email).then((remote) => {
          if (remote && Array.isArray(remote.items) && remote.items.length > 0) {
            setItems(remote.items);
            if (remote.coupon) setCoupon(remote.coupon);
            try {
              localStorage.setItem(currentKey, JSON.stringify(remote.items));
              if (remote.coupon) localStorage.setItem(currentCouponKey, JSON.stringify(remote.coupon));
            } catch {}
          }
        }).catch(() => {});
      }
    }
  }, [currentKey, currentUser, currentCouponKey]);

  // Save items whenever they change, strictly scoped to the active user's key and backend
  useEffect(() => {
    try {
      localStorage.setItem(currentKey, JSON.stringify(items));
      if (currentUser?.email) {
        api.saveUserCart(currentUser.email, items, coupon);
      }
    } catch (e) {
      console.warn('[Cart] LocalStorage write error:', e);
    }
  }, [items, coupon, currentKey, currentUser]);

  // Save or clear coupon strictly for the active user's key
  useEffect(() => {
    try {
      if (coupon) {
        localStorage.setItem(currentCouponKey, JSON.stringify(coupon));
      } else {
        localStorage.removeItem(currentCouponKey);
      }
    } catch (e) {
      console.warn('[Cart] Coupon storage error:', e);
    }
  }, [coupon, currentCouponKey]);

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const freeDeliveryEligible = subtotal >= FREE_DELIVERY_THRESHOLD || items.length === 0;
  const deliveryCharge = items.length === 0 || freeDeliveryEligible ? 0 : STANDARD_DELIVERY_CHARGE;
  const amountNeededForFreeDelivery = Math.max(0, FREE_DELIVERY_THRESHOLD - subtotal);

  // Calculate coupon discount
  let discountAmount = 0;
  if (coupon && subtotal >= coupon.minOrderValue) {
    if (coupon.discountType === 'percentage') {
      const calculated = (subtotal * coupon.discountValue) / 100;
      discountAmount = coupon.maxDiscount ? Math.min(calculated, coupon.maxDiscount) : calculated;
    } else {
      discountAmount = Math.min(coupon.discountValue, subtotal);
    }
  }

  const totalAmount = Math.max(0, subtotal - discountAmount + deliveryCharge);

  const addToCart = (product: Product, variant?: ProductVariant, quantity: number = 1): boolean => {
    const maxStock = variant ? variant.stock : product.stock;
    if (maxStock <= 0) return false;

    const variantId = variant?.id;
    const existingIndex = items.findIndex(
      (item) => item.productId === product.id && item.variantId === variantId
    );

    if (existingIndex > -1) {
      const currentQty = items[existingIndex].quantity;
      const newQty = Math.min(currentQty + quantity, maxStock);
      setItems((prev) =>
        prev.map((it, idx) => (idx === existingIndex ? { ...it, quantity: newQty } : it))
      );
      return true;
    }

    const newItem: CartItem = {
      productId: product.id,
      variantId,
      title: product.title,
      productTitle: product.title,
      variantName: variant?.name,
      sku: variant ? variant.sku : product.sku,
      price: variant ? variant.price : product.price,
      originalPrice: variant?.originalPrice || product.originalPrice,
      quantity: Math.min(quantity, maxStock),
      maxStock,
      image: product.images[0] || 'https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=800&auto=format&fit=crop&q=80',
    };

    setItems((prev) => [...prev, newItem]);
    return true;
  };

  const updateQuantity = (productId: string, variantId: string | undefined, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, variantId);
      return;
    }

    setItems((prev) =>
      prev.map((item) => {
        if (item.productId === productId && item.variantId === variantId) {
          const clamped = Math.min(quantity, item.maxStock);
          return { ...item, quantity: clamped };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId: string, variantId?: string) => {
    setItems((prev) =>
      prev.filter((item) => !(item.productId === productId && item.variantId === variantId))
    );
  };

  const clearCart = () => {
    setItems([]);
    setCoupon(null);
    try {
      localStorage.removeItem(currentKey);
      localStorage.removeItem(currentCouponKey);
      if (currentUser?.email) {
        api.clearUserCart(currentUser.email);
      }
    } catch {}
  };

  const applyCoupon = async (code: string): Promise<boolean> => {
    setCouponError(null);
    try {
      const res = await api.validateCoupon(code, subtotal);
      if (res.valid && res.coupon) {
        setCoupon(res.coupon);
        return true;
      } else {
        setCouponError(res.message || 'Invalid or expired coupon');
        return false;
      }
    } catch {
      const upper = code.trim().toUpperCase();
      if (upper === 'NOOR10' || upper === 'WELCOME10') {
        const fallbackCoupon: Coupon = {
          id: 'cpn-10',
          code: upper,
          discountType: 'percentage',
          discountValue: 10,
          minOrderValue: 499,
          maxDiscount: 200,
          startDate: '2026-01-01',
          endDate: '2026-12-31',
          usageLimit: 1000,
          timesUsed: 12,
          isActive: true,
        };
        if (subtotal >= 499) {
          setCoupon(fallbackCoupon);
          return true;
        } else {
          setCouponError('Minimum order value of ₹499 required for this coupon.');
          return false;
        }
      }
      setCouponError('Invalid coupon code. Try WELCOME10 or NOOR100.');
      return false;
    }
  };

  const removeCoupon = () => {
    setCoupon(null);
    setCouponError(null);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        discountAmount,
        deliveryCharge,
        freeDeliveryThreshold: FREE_DELIVERY_THRESHOLD,
        freeDeliveryEligible,
        amountNeededForFreeDelivery,
        totalAmount,
        coupon,
        couponError,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        applyCoupon,
        removeCoupon,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
