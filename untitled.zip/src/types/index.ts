export type LanguageCode = 'en' | 'bn' | 'hi' | 'ur';

export type UserRole = 
  | 'owner' 
  | 'admin'
  | 'super_admin' 
  | 'product_manager' 
  | 'order_manager' 
  | 'support_manager' 
  | 'read_only_staff' 
  | 'customer';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: UserRole;
  avatarUrl?: string;
  photoURL?: string;
  preferredLanguage?: LanguageCode;
  createdAt: string;
  updatedAt?: string;
}

export interface Address {
  id: string;
  userId: string;
  fullName: string;
  phone: string;
  houseFlat: string;
  street: string;
  locality: string;
  city: string;
  state: string;
  pinCode: string;
  landmark?: string;
  addressType: 'home' | 'work' | 'other';
  isDefault: boolean;
}

export interface ProductVariant {
  id: string;
  name: string; // e.g. "6ml", "12ml", "50ml", "Standard", "Large", "Black", "Maroon"
  sku: string;
  price: number;
  originalPrice?: number;
  stock: number;
}

export interface Product {
  id: string;
  title: string;
  slug: string;
  sku: string;
  description: string;
  categoryId: string;
  categoryName?: string;
  brand?: string;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  stock: number;
  lowStockThreshold: number;
  images: string[];
  variants?: ProductVariant[];
  isActive: boolean;
  isFeatured: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  sellerName?: string;
  rating: number;
  reviewCount: number;
  specifications?: Record<string, string>;
  createdAt: string;
  updatedAt?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  imageUrl: string;
  sortOrder: number;
  isActive: boolean;
  itemCount?: number;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  eyebrow?: string;
  imageUrl: string;
  buttonText: string;
  buttonLink: string;
  sortOrder: number;
  isActive: boolean;
}

export interface CartItem {
  productId: string;
  variantId?: string;
  title: string;
  productTitle?: string;
  variantName?: string;
  sku?: string;
  price: number;
  originalPrice?: number;
  image: string;
  quantity: number;
  maxStock: number;
}

export type OrderStatus =
  | 'Order Placed'
  | 'Order Confirmed'
  | 'Processing'
  | 'Packed'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Return Requested'
  | 'Returned'
  | 'Refund Pending'
  | 'Refunded';

export type PaymentMethod = 
  | 'whatsapp_assisted' 
  | 'cash_on_delivery' 
  | 'upi_manual';

export type PaymentStatus = 'pending' | 'confirmed' | 'failed' | 'refunded';

export interface OrderItem {
  productId: string;
  variantId?: string;
  productTitle: string;
  variantName?: string;
  sku: string;
  price: number;
  quantity: number;
  image: string;
  lineTotal: number;
}

export interface Order {
  id: string; // e.g., "NAH-ORD-2026-8812"
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: Address;
  items: OrderItem[];
  subtotal: number;
  discountAmount: number;
  deliveryCharge: number;
  totalAmount: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  couponCode?: string;
  whatsappConfirmationUrl?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  timeline: {
    status: OrderStatus;
    timestamp: string;
    note?: string;
    actor?: string;
  }[];
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  maxDiscount?: number;
  startDate: string;
  endDate: string;
  usageLimit: number;
  timesUsed: number;
  isActive: boolean;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number; // 1 to 5
  comment: string;
  images?: string[];
  isVerifiedPurchase: boolean;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system' | 'price_drop';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface StoreSettings {
  storeName: string;
  tagline?: string;
  logoUrl?: string;
  aboutUsText?: string;
  ownerEmail: string;
  supportEmail?: string;
  whatsappNumber: string;
  supportPhone?: string;
  storeAddress?: string;
  standardDeliveryCharge: number;
  freeDeliveryThreshold: number;
  currencySymbol: string;
  announcementText: string;
  announcementActive: boolean;
  googleSheetsId?: string;
  googleDriveFolderId?: string;
  googleServiceAccountEmail?: string;
  upiId?: string;
  upiQrCodeUrl?: string;
  updatedAt?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actorEmail: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
}
