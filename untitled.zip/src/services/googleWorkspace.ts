/**
 * Google Workspace Service for Noor Al Huda Islamic Shop
 * Direct integration with user's Google Drive & Google Sheets
 */

export const SPREADSHEET_ID = '1LDACYhI5jFe2HS-jtvV-nwmOiqoMgeiM-tKWk-X-i6g';
export const DRIVE_FOLDER_ID = '1s5XtR7hmiNMVoA3H2J1fF4TgVnSobwao';

export const SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/spreadsheets',
];

// In-memory token cache (NEVER in localStorage/sessionStorage per security guidelines)
let inMemoryAccessToken: string | null = null;

export const setCachedAccessToken = (token: string | null) => {
  inMemoryAccessToken = token;
};

export const getCachedAccessToken = (): string | null => {
  return inMemoryAccessToken;
};

/**
 * Upload an image file directly to the user's designated Google Drive Folder
 */
export async function uploadImageToGoogleDrive(
  file: File,
  folderId: string = DRIVE_FOLDER_ID
): Promise<{ id: string; name: string; url: string; webViewLink?: string }> {
  const token = getCachedAccessToken();
  if (!token) {
    throw new Error('Google Workspace session required. Please sign in with Google.');
  }

  // 1. Metadata part
  const metadata = {
    name: `nah_product_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`,
    parents: folderId ? [folderId] : undefined,
    mimeType: file.type || 'image/jpeg',
  };

  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', file);

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,webContentLink,thumbnailLink', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: form,
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Google Drive upload failed: ${res.status} - ${errorText}`);
  }

  const data = await res.json();

  // Create public read permission for this file so it can be viewed by customers in the shop
  try {
    await fetch(`https://www.googleapis.com/drive/v3/files/${data.id}/permissions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        role: 'reader',
        type: 'anyone',
      }),
    });
  } catch (permErr) {
    console.warn('Could not set public permission on drive file:', permErr);
  }

  // Generate web-friendly image URL for storefront display
  const directImageUrl = `https://lh3.googleusercontent.com/d/${data.id}`;

  return {
    id: data.id,
    name: data.name,
    webViewLink: data.webViewLink,
    url: directImageUrl,
  };
}

/**
 * Append row to a worksheet in the user's Google Spreadsheet
 */
export async function appendRowToGoogleSheet(
  sheetName: string,
  rowValues: any[]
): Promise<boolean> {
  const token = getCachedAccessToken();
  if (!token) {
    console.warn('[Google Sheets] No in-memory access token available for live sync.');
    return false;
  }

  try {
    const range = `${encodeURIComponent(sheetName)}!A1`;
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range: `${sheetName}!A1`,
        majorDimension: 'ROWS',
        values: [rowValues],
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.warn('[Google Sheets] Append row warning:', err);
      return false;
    }

    return true;
  } catch (err) {
    console.error('[Google Sheets] Error appending row:', err);
    return false;
  }
}

/**
 * Live sync customer profile to Google Sheets 'Customers' worksheet
 */
export async function syncCustomerToGoogleSheet(customer: {
  id?: string;
  name: string;
  email: string;
  phone?: string;
  totalOrders?: number;
  totalSpent?: number;
}): Promise<boolean> {
  const row = [
    customer.id || `cust-${Date.now().toString(36)}`,
    customer.name,
    customer.email,
    customer.phone || '',
    customer.totalOrders || 1,
    customer.totalSpent || 0,
    new Date().toISOString(),
  ];
  return appendRowToGoogleSheet('Customers', row);
}

/**
 * Live sync order to Google Sheets 'Orders' worksheet
 */
export async function syncOrderToGoogleSheet(order: {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  subtotal: number;
  discountAmount?: number;
  deliveryCharge?: number;
  totalAmount: number;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  items?: any[];
}): Promise<boolean> {
  const orderRow = [
    order.id,
    order.customerName,
    order.customerEmail,
    order.customerPhone,
    order.subtotal,
    order.discountAmount || 0,
    order.deliveryCharge || 0,
    order.totalAmount,
    order.status,
    order.paymentMethod,
    order.paymentStatus,
    new Date().toISOString(),
  ];

  const ok = await appendRowToGoogleSheet('Orders', orderRow);

  // Also sync order line items to 'OrderItems' sheet
  if (order.items && order.items.length > 0) {
    for (const it of order.items) {
      const itemRow = [
        `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        order.id,
        it.productId,
        it.productTitle,
        it.variantName || 'Standard',
        it.sku || '',
        it.price,
        it.quantity,
        it.lineTotal || it.price * it.quantity,
      ];
      await appendRowToGoogleSheet('OrderItems', itemRow);
    }
  }

  return ok;
}

/**
 * Test connectivity to Google Spreadsheet and Google Drive Folder
 */
export async function verifyGoogleWorkspaceAccess(): Promise<{
  sheetsLive: boolean;
  driveLive: boolean;
  sheetsTitle?: string;
  driveFilesCount?: number;
  message: string;
}> {
  const token = getCachedAccessToken();
  if (!token) {
    return {
      sheetsLive: false,
      driveLive: false,
      message: 'Not connected: Sign in with Google to enable real-time Drive & Sheets sync.',
    };
  }

  let sheetsLive = false;
  let driveLive = false;
  let sheetsTitle: string | undefined = undefined;
  let driveFilesCount = 0;

  try {
    const sRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}?fields=properties.title,sheets.properties.title`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (sRes.ok) {
      const sData = await sRes.json();
      sheetsLive = true;
      sheetsTitle = sData.properties?.title || 'Noor Al Huda Database';
    }
  } catch (e) {
    console.warn('Sheets verify error:', e);
  }

  try {
    const dRes = await fetch(`https://www.googleapis.com/drive/v3/files?q='${DRIVE_FOLDER_ID}'+in+parents+and+trashed=false&fields=files(id,name)`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (dRes.ok) {
      const dData = await dRes.json();
      driveLive = true;
      driveFilesCount = dData.files?.length || 0;
    }
  } catch (e) {
    console.warn('Drive verify error:', e);
  }

  return {
    sheetsLive,
    driveLive,
    sheetsTitle,
    driveFilesCount,
    message: sheetsLive && driveLive
      ? 'Connected and verified with Google Drive and Google Sheets!'
      : 'Partial or pending authorization. Please re-authenticate via Google Sign In.',
  };
}
