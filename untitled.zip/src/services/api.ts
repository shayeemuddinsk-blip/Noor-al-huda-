import { 
  Product, Category, Banner, Order, Coupon, 
  StoreSettings, AuditLog, UserProfile, CartItem 
} from '../types';

const CLOUDFLARE_WORKER_URL = (import.meta as any).env?.VITE_CLOUDFLARE_WORKER_URL || '';
export const API_BASE = CLOUDFLARE_WORKER_URL ? `${CLOUDFLARE_WORKER_URL.replace(/\/+$/, '')}/api` : '/api';

export interface OrderCreationPayload {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: {
    fullName: string;
    phone: string;
    houseFlat: string;
    street: string;
    locality: string;
    city: string;
    state: string;
    pinCode: string;
    landmark?: string;
    addressType: 'home' | 'work' | 'other';
  };
  items: {
    productId: string;
    variantId?: string;
    quantity: number;
  }[];
  couponCode?: string;
  paymentMethod: 'whatsapp_assisted' | 'cash_on_delivery' | 'upi_manual';
  notes?: string;
}

export const api = {
  // Products
  async getProducts(params?: { category?: string; search?: string; sort?: string; minPrice?: number; maxPrice?: number; inStockOnly?: boolean }): Promise<Product[]> {
    const query = new URLSearchParams();
    if (params?.category) query.append('category', params.category);
    if (params?.search) query.append('search', params.search);
    if (params?.sort) query.append('sort', params.sort);
    if (params?.minPrice !== undefined) query.append('minPrice', String(params.minPrice));
    if (params?.maxPrice !== undefined) query.append('maxPrice', String(params.maxPrice));
    if (params?.inStockOnly) query.append('inStockOnly', 'true');

    const res = await fetch(`${API_BASE}/products?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch products');
    return res.json();
  },

  async getProductById(id: string): Promise<Product> {
    const res = await fetch(`${API_BASE}/products/${id}`);
    if (!res.ok) throw new Error('Product not found');
    return res.json();
  },

  async createProduct(product: Partial<Product>): Promise<Product> {
    const res = await fetch(`${API_BASE}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to create product');
    }
    return res.json();
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
    const res = await fetch(`${API_BASE}/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update product');
    return res.json();
  },

  async deleteProduct(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/products/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete product');
  },

  // Categories
  async getCategories(): Promise<Category[]> {
    const res = await fetch(`${API_BASE}/categories`);
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  async createCategory(cat: Partial<Category>): Promise<Category> {
    const res = await fetch(`${API_BASE}/categories`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cat),
    });
    if (!res.ok) throw new Error('Failed to create category');
    return res.json();
  },

  async updateCategory(id: string, updates: Partial<Category>): Promise<Category> {
    const res = await fetch(`${API_BASE}/categories/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update category');
    return res.json();
  },

  async deleteCategory(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/categories/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete category');
  },

  // Banners
  async getBanners(): Promise<Banner[]> {
    const res = await fetch(`${API_BASE}/banners`);
    if (!res.ok) throw new Error('Failed to fetch banners');
    return res.json();
  },

  async createBanner(banner: Partial<Banner>): Promise<Banner> {
    const res = await fetch(`${API_BASE}/banners`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(banner),
    });
    if (!res.ok) throw new Error('Failed to create banner');
    return res.json();
  },

  async updateBanner(id: string, updates: Partial<Banner>): Promise<Banner> {
    const res = await fetch(`${API_BASE}/banners/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update banner');
    return res.json();
  },

  async deleteBanner(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/banners/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete banner');
  },

  // Cart Validation
  async validateCart(items: CartItem[]): Promise<{
    valid: boolean;
    subtotal: number;
    deliveryCharge: number;
    freeDeliveryEligible: boolean;
    amountNeededForFreeDelivery: number;
    errors: string[];
  }> {
    const res = await fetch(`${API_BASE}/cart/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items }),
    });
    return res.json();
  },

  // Orders
  async createOrder(payload: OrderCreationPayload): Promise<{ order: Order; whatsappUrl: string }> {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to place order');
    }
    return res.json();
  },

  async getOrders(userEmail?: string): Promise<Order[]> {
    const query = userEmail ? `?email=${encodeURIComponent(userEmail)}` : '';
    const res = await fetch(`${API_BASE}/orders${query}`);
    if (!res.ok) throw new Error('Failed to fetch orders');
    return res.json();
  },

  async getOrderById(id: string): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders/${id}`);
    if (!res.ok) throw new Error('Order not found');
    return res.json();
  },

  async updateOrderStatus(id: string, status: string, note?: string, actor?: string): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note, actor }),
    });
    if (!res.ok) throw new Error('Failed to update order status');
    return res.json();
  },

  async updatePaymentStatus(id: string, paymentStatus: string, actor?: string): Promise<Order> {
    const res = await fetch(`${API_BASE}/orders/${id}/payment-status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentStatus, actor }),
    });
    if (!res.ok) throw new Error('Failed to update payment status');
    return res.json();
  },

  // Coupons
  async validateCoupon(code: string, subtotal: number): Promise<{ valid: boolean; discountAmount: number; message: string; coupon?: Coupon }> {
    const res = await fetch(`${API_BASE}/coupons/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, subtotal }),
    });
    return res.json();
  },

  async getCoupons(): Promise<Coupon[]> {
    const res = await fetch(`${API_BASE}/coupons`);
    if (!res.ok) throw new Error('Failed to fetch coupons');
    return res.json();
  },

  async createCoupon(coupon: Partial<Coupon>): Promise<Coupon> {
    const res = await fetch(`${API_BASE}/coupons`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(coupon),
    });
    if (!res.ok) throw new Error('Failed to create coupon');
    return res.json();
  },

  async updateCoupon(id: string, updates: Partial<Coupon>): Promise<Coupon> {
    const res = await fetch(`${API_BASE}/coupons/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update coupon');
    return res.json();
  },

  async deleteCoupon(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/coupons/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete coupon');
  },

  // Settings
  async getSettings(): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/settings`);
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async updateSettings(settings: Partial<StoreSettings>): Promise<StoreSettings> {
    const res = await fetch(`${API_BASE}/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update settings');
    return res.json();
  },

  // Admin Metrics & Dashboard
  async getAdminMetrics(): Promise<{
    totalOrders: number;
    awaitingConfirmation: number;
    awaitingShipment: number;
    deliveredOrders: number;
    cancelledOrders: number;
    grossOrderValue: number;
    activeProductsCount: number;
    lowStockProductsCount: number;
    outOfStockProductsCount: number;
    totalCustomersCount: number;
    recentOrders: Order[];
  }> {
    const res = await fetch(`${API_BASE}/admin/metrics`);
    if (!res.ok) throw new Error('Failed to fetch metrics');
    return res.json();
  },

  // Google Sheets & Drive Hub
  async getGoogleSheetsSyncInfo(): Promise<{
    configured: boolean;
    sheetsCount: number;
    spreadsheetId?: string;
    driveFolderId?: string;
    lastSyncedAt?: string;
    status: 'connected' | 'not_configured' | 'mock_mode';
    sheetsList: { name: string; recordCount: number; description: string }[];
  }> {
    const res = await fetch(`${API_BASE}/admin/sheets-sync`);
    if (!res.ok) throw new Error('Failed to fetch Google Sheets sync status');
    return res.json();
  },

  async triggerGoogleSheetsSync(): Promise<{ success: boolean; message: string; timestamp: string }> {
    const res = await fetch(`${API_BASE}/admin/sheets-sync`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to trigger sync');
    return res.json();
  },

  // Audit Logs
  async getAuditLogs(): Promise<AuditLog[]> {
    const res = await fetch(`${API_BASE}/audit-logs`);
    if (!res.ok) throw new Error('Failed to fetch audit logs');
    return res.json();
  },

  // Authentication & Authorization (Backend Authoritative)
  async register(data: { name: string; email: string; phone?: string; password?: string }): Promise<{ success: boolean; token: string; user: UserProfile }> {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Registration failed');
    }
    return res.json();
  },

  async login(email: string, password?: string): Promise<{ success: boolean; token: string; role: any; user: UserProfile }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Login failed');
    }
    return res.json();
  },

  async googleAuthSync(data: { email: string; displayName?: string; uid?: string; photoURL?: string; phone?: string }): Promise<{ success: boolean; token: string; role: any; user: UserProfile }> {
    const res = await fetch(`${API_BASE}/auth/google-sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Google authentication sync failed');
    }
    return res.json();
  },

  async getCurrentUser(token: string): Promise<{ user: UserProfile }> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    if (!res.ok) throw new Error('Session invalid');
    return res.json();
  },

  async resetPassword(email: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Password reset request failed');
    }
    return res.json();
  },

  async getAdminUsers(token?: string): Promise<any[]> {
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/users`, { headers });
    if (!res.ok) throw new Error('Failed to fetch admin users');
    return res.json();
  },

  async createAdminUser(data: { name: string; email: string; role: string; phone?: string; permissions?: string[] }, token?: string): Promise<any> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/users`, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to create admin user');
    }
    return res.json();
  },

  async getAllUsers(token?: string): Promise<any[]> {
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/all-users`, { headers });
    if (!res.ok) throw new Error('Failed to fetch user roster');
    return res.json();
  },

  async promoteUserToAdmin(data: { email: string; name?: string; phone?: string; role?: string }, token?: string): Promise<any> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/users/promote`, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to promote user');
    }
    return res.json();
  },

  async demoteUserFromAdmin(email: string, token?: string): Promise<any> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/users/demote`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to revoke admin role');
    }
    return res.json();
  },

  async updateUserRole(email: string, role: string, token?: string): Promise<any> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/admin/users/${encodeURIComponent(email)}/role`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ role }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Failed to update user role');
    }
    return res.json();
  },

  async getAdminEmails(): Promise<string[]> {
    const res = await fetch(`${API_BASE}/admin/admin-emails`);
    if (!res.ok) return [];
    return res.json();
  },

  async get15SheetsExport(): Promise<{ totalWorksheets: number; timestamp: string; worksheets: { name: string; headers: string[]; csv: string }[] }> {
    const res = await fetch(`${API_BASE}/admin/export-15-sheets`);
    if (!res.ok) throw new Error('Failed to export 15 worksheets');
    return res.json();
  },

  // User Isolated Cart & Wishlist Sync
  async getUserCart(email: string, token?: string): Promise<{ items: CartItem[]; coupon: Coupon | null }> {
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/user/cart?email=${encodeURIComponent(email)}`, { headers });
    if (!res.ok) return { items: [], coupon: null };
    return res.json();
  },

  async saveUserCart(email: string, items: CartItem[], coupon?: Coupon | null, token?: string): Promise<void> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    await fetch(`${API_BASE}/user/cart`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email, items, coupon }),
    }).catch(() => {});
  },

  async clearUserCart(email: string, token?: string): Promise<void> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    await fetch(`${API_BASE}/user/cart`, {
      method: 'DELETE',
      headers,
      body: JSON.stringify({ email }),
    }).catch(() => {});
  },

  async getUserWishlist(email: string, token?: string): Promise<string[]> {
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/user/wishlist?email=${encodeURIComponent(email)}`, { headers });
    if (!res.ok) return [];
    const data = await res.json();
    return data.productIds || [];
  },

  async saveUserWishlist(email: string, productIds: string[], token?: string): Promise<void> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    await fetch(`${API_BASE}/user/wishlist`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email, productIds }),
    }).catch(() => {});
  },

  // Upload
  async uploadImage(file: File, folder: string = 'products'): Promise<{ url: string; fileId: string }> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('folder', folder);

    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Image upload failed');
    }
    return res.json();
  }
};
