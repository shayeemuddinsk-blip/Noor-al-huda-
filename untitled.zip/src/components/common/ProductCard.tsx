import React, { useState } from 'react';
import { Heart, ShoppingBag, Eye, Star, Check, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product } from '../../types';
import { useCart } from '../../contexts/CartContext';
import { useWishlist } from '../../contexts/WishlistContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { t } = useLanguage();

  const [added, setAdded] = useState(false);
  const isWishlisted = isInWishlist(product.id);

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;

  // Calculate discount percentage accurately
  const discountPercent = product.originalPrice && product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isOutOfStock) return;

    const defaultVariant = product.variants?.[0];
    addToCart(product, defaultVariant, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  const handleQuickViewClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onQuickView) onQuickView(product);
  };

  return (
    <div className="group relative bg-white rounded-xl border border-gray-200/80 hover:border-emerald-700/50 hover:shadow-lg transition-all duration-200 flex flex-col overflow-hidden">
      
      {/* Top Badges */}
      <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
        {discountPercent > 0 && (
          <span className="px-2 py-0.5 bg-amber-500 text-emerald-950 font-extrabold text-[10px] rounded-md shadow-xs">
            {discountPercent}% {t('off')}
          </span>
        )}
        {product.isBestSeller && (
          <span className="px-2 py-0.5 bg-emerald-900 text-amber-300 font-bold text-[9px] rounded-md flex items-center gap-1 shadow-xs">
            <Sparkles className="w-2.5 h-2.5" />
            Bestseller
          </span>
        )}
        {isOutOfStock ? (
          <span className="px-2 py-0.5 bg-red-600 text-white font-extrabold text-[9px] rounded-md shadow-xs uppercase tracking-wider">
            {t('outOfStock')}
          </span>
        ) : isLowStock ? (
          <span className="px-2 py-0.5 bg-orange-600 text-white font-bold text-[9px] rounded-md">
            Only {product.stock} left
          </span>
        ) : null}
      </div>

      {/* Wishlist Button */}
      <button
        onClick={handleToggleWishlist}
        className={`absolute top-2.5 right-2.5 z-10 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center shadow-md transition hover:scale-110 cursor-pointer ${
          isWishlisted ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
        }`}
        title="Add to Wishlist"
      >
        <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500' : ''}`} />
      </button>

      {/* Product Image */}
      <Link to={`/product/${product.id}`} className="relative block aspect-square bg-[#fbfaf8] overflow-hidden p-2 sm:p-2.5">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=500&auto=format&fit=crop&q=80'}
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300 drop-shadow-2xs"
        />

        {/* Quick View Overlay (Desktop) */}
        {onQuickView && (
          <button
            onClick={handleQuickViewClick}
            className="hidden md:flex absolute bottom-2 left-2 right-2 py-1.5 bg-white/95 text-emerald-950 text-xs font-semibold rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition items-center justify-center gap-1.5 hover:bg-emerald-50 cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-emerald-800" />
            <span>{t('quickView')}</span>
          </button>
        )}
      </Link>

      {/* Product Info */}
      <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category */}
          <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block mb-1">
            {product.categoryName || 'Islamic Goods'}
          </span>

          {/* Title */}
          <Link to={`/product/${product.id}`}>
            <h3 className="text-xs sm:text-sm font-semibold text-gray-900 group-hover:text-emerald-800 transition line-clamp-2 leading-snug">
              {product.title}
            </h3>
          </Link>

          {/* Rating */}
          {product.rating > 0 && (
            <div className="flex items-center gap-1 mt-1.5 text-xs">
              <div className="flex items-center gap-0.5 px-1.5 py-0.2 bg-emerald-800 text-white rounded text-[10px] font-bold">
                <span>{product.rating.toFixed(1)}</span>
                <Star className="w-2.5 h-2.5 fill-white" />
              </div>
              <span className="text-[11px] text-gray-400">({product.reviewCount})</span>
            </div>
          )}
        </div>

        {/* Price & Add to Cart */}
        <div className="mt-3 pt-2.5 border-t border-gray-100 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm sm:text-base font-extrabold text-gray-900">
                ₹{product.price}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-xs text-gray-400 line-through">
                  ₹{product.originalPrice}
                </span>
              )}
            </div>
            {product.price >= 999 ? (
              <span className="text-[10px] font-semibold text-emerald-700 block">
                {t('freeDeliveryBadge')}
              </span>
            ) : (
              <span className="text-[10px] text-gray-400 block">
                Standard delivery ₹40
              </span>
            )}
          </div>

          {/* Add to Cart button */}
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-xs cursor-pointer ${
              isOutOfStock
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : added
                ? 'bg-emerald-700 text-white'
                : 'bg-emerald-800 hover:bg-emerald-900 text-white'
            }`}
            title={isOutOfStock ? t('outOfStock') : t('addToCart')}
          >
            {added ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Added</span>
              </>
            ) : isOutOfStock ? (
              <span>Out of Stock</span>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t('addToCart')}</span>
              </>
            )}
          </button>
        </div>

      </div>

    </div>
  );
};
