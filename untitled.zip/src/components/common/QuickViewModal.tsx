import React, { useState } from 'react';
import { X, Star, ShoppingBag, Heart, Check, ShieldCheck, MessageCircle } from 'lucide-react';
import { Product, ProductVariant } from '../../types';
import { useCart } from '../../contexts/CartContext';
import { useWishlist } from '../../contexts/WishlistContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(
    product?.variants?.[0]
  );
  const [selectedImage, setSelectedImage] = useState<string>(product?.images[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) return null;

  const currentPrice = selectedVariant ? selectedVariant.price : product.price;
  const currentOriginalPrice = selectedVariant ? selectedVariant.originalPrice : product.originalPrice;
  const currentStock = selectedVariant ? selectedVariant.stock : product.stock;
  const isWishlisted = isInWishlist(product.id);

  const handleAddToCart = () => {
    if (currentStock <= 0) return;
    addToCart(product, selectedVariant, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  const handleBuyNow = () => {
    if (currentStock <= 0) return;
    addToCart(product, selectedVariant, quantity);
    onClose();
    navigate('/checkout');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-100 max-h-[90vh] flex flex-col md:flex-row">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-white/80 hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Images Gallery */}
        <div className="w-full md:w-1/2 p-6 bg-gray-50 flex flex-col justify-between">
          <div className="aspect-square bg-white rounded-xl overflow-hidden border border-gray-200/80 mb-3 shadow-inner">
            <img
              src={selectedImage || product.images[0]}
              alt={product.title}
              className="w-full h-full object-contain p-2"
            />
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(img)}
                  className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition shrink-0 ${
                    (selectedImage || product.images[0]) === img ? 'border-emerald-700' : 'border-transparent opacity-70'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details & Actions */}
        <div className="w-full md:w-1/2 p-6 flex flex-col justify-between overflow-y-auto">
          <div>
            <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider block mb-1">
              {product.categoryName || 'Islamic Goods'}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-gray-900 leading-snug">
              {product.title}
            </h2>

            {/* Rating */}
            {product.rating > 0 && (
              <div className="flex items-center gap-1.5 mt-2">
                <div className="flex items-center gap-0.5 px-2 py-0.5 bg-emerald-800 text-white rounded text-xs font-bold">
                  <span>{product.rating.toFixed(1)}</span>
                  <Star className="w-3 h-3 fill-white" />
                </div>
                <span className="text-xs text-gray-500">({product.reviewCount} verified customer reviews)</span>
              </div>
            )}

            {/* Price */}
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-extrabold text-gray-900">₹{currentPrice}</span>
              {currentOriginalPrice && currentOriginalPrice > currentPrice && (
                <span className="text-sm text-gray-400 line-through">₹{currentOriginalPrice}</span>
              )}
            </div>

            {/* Description */}
            <p className="mt-3 text-xs text-gray-600 line-clamp-3 leading-relaxed">
              {product.description}
            </p>

            {/* Variants */}
            {product.variants && product.variants.length > 0 && (
              <div className="mt-4">
                <label className="block text-xs font-bold text-gray-700 mb-1.5">
                  Select Size / Option:
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.variants.map((variant) => (
                    <button
                      key={variant.id}
                      onClick={() => setSelectedVariant(variant)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                        selectedVariant?.id === variant.id
                          ? 'border-emerald-800 bg-emerald-50 text-emerald-950 font-bold'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {variant.name} - ₹{variant.price}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Stock status */}
            <div className="mt-3">
              {currentStock > 0 ? (
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4" />
                  In Stock ({currentStock} units available)
                </span>
              ) : (
                <span className="text-xs font-bold text-red-600">
                  Currently Out of Stock
                </span>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="mt-6 pt-4 border-t border-gray-100 flex flex-col gap-2">
            <div className="flex gap-2">
              <button
                onClick={handleAddToCart}
                disabled={currentStock <= 0}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                  added
                    ? 'bg-emerald-700 text-white'
                    : 'bg-emerald-800 hover:bg-emerald-900 text-white shadow-md'
                }`}
              >
                {added ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
                <span>{added ? 'Added to Cart' : t('addToCart')}</span>
              </button>

              <button
                onClick={handleBuyNow}
                disabled={currentStock <= 0}
                className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-emerald-950 text-xs font-bold flex items-center justify-center transition shadow-md cursor-pointer"
              >
                {t('buyNow')}
              </button>

              <button
                onClick={() => toggleWishlist(product)}
                className={`p-2.5 rounded-xl border border-gray-200 flex items-center justify-center transition cursor-pointer ${
                  isWishlisted ? 'text-red-500 bg-red-50 border-red-200' : 'text-gray-400 hover:text-red-500'
                }`}
                title="Wishlist"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500' : ''}`} />
              </button>
            </div>

            <a
              href={`https://wa.me/917003735250?text=${encodeURIComponent(`Assalamualaikum, I am inquiring about product: ${product.title} (₹${currentPrice})`)}`}
              target="_blank"
              rel="noreferrer"
              className="w-full py-2 px-3 rounded-xl border border-emerald-700/30 text-emerald-900 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-emerald-50 transition"
            >
              <MessageCircle className="w-4 h-4 text-emerald-700" />
              <span>{t('enquireWhatsApp')}</span>
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};
