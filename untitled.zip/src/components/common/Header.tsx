import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, ShoppingBag, Heart, User, ChevronDown, 
  Sparkles, Globe, MapPin, X, ArrowRight, ShieldCheck, 
  LogOut, Package, MapPin as LocationIcon, Settings
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { useWishlist } from '../../contexts/WishlistContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { api } from '../../services/api';
import { Category, Product, LanguageCode, StoreSettings } from '../../types';
import { AuthModal } from './AuthModal';

export const Header: React.FC = () => {
  const { currentUser, isAuthenticated, isAdmin, isOwner, logout } = useAuth();
  const { itemCount, subtotal } = useCart();
  const { wishlistCount } = useWishlist();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchSuggestions, setSearchSuggestions] = useState<Product[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [pincode, setPincode] = useState('700073');
  const [showPincodeModal, setShowPincodeModal] = useState(false);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const accountMenuRef = useRef<HTMLDivElement>(null);
  const langMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.getCategories().then(setCategories).catch(console.error);
    api.getSettings().then(setSettings).catch(console.error);
  }, []);

  // Debounced search suggestions
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setSearchSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    const timer = setTimeout(() => {
      api.getProducts({ search: searchQuery }).then((prods) => {
        setSearchSuggestions(prods.slice(0, 5));
        setShowSuggestions(true);
      }).catch(console.error);
    }, 200);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside listeners
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
      if (accountMenuRef.current && !accountMenuRef.current.contains(e.target as Node)) {
        setIsAccountMenuOpen(false);
      }
      if (langMenuRef.current && !langMenuRef.current.contains(e.target as Node)) {
        setIsLangMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowSuggestions(false);
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleSelectSuggestion = (product: Product) => {
    setShowSuggestions(false);
    setSearchQuery('');
    navigate(`/product/${product.id}`);
  };

  const languages: { code: LanguageCode; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'bn', label: 'Bengali', native: 'বাংলা' },
    { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
    { code: 'ur', label: 'Urdu', native: 'اردو' },
  ];

  const currentLangLabel = languages.find(l => l.code === language)?.native || 'English';

  return (
    <>
      <header className="sticky top-0 z-40 bg-white border-b border-emerald-900/10 shadow-xs">
        
        {/* Top Announcement Strip */}
        {settings?.announcementActive && (
          <div className="bg-emerald-950 text-emerald-100 text-[11px] sm:text-xs py-1.5 px-3 overflow-hidden">
            <div className="max-w-7xl mx-auto flex items-center justify-between overflow-hidden">
              <div className="flex items-center gap-1.5 truncate">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{settings.announcementText}</span>
              </div>
              <div className="hidden md:flex items-center gap-4 shrink-0 font-medium">
                <a 
                  href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`} 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-amber-300 transition flex items-center gap-1"
                >
                  <span>WhatsApp: {settings.whatsappNumber}</span>
                </a>
                <span className="text-emerald-700">|</span>
                <button 
                  onClick={() => setShowPincodeModal(true)}
                  className="flex items-center gap-1 hover:text-amber-300 cursor-pointer"
                >
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>Deliver to: <strong className="text-white">{pincode}</strong></span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Header Bar */}
        <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 sm:py-3 flex items-center justify-between gap-2 sm:gap-6 relative">
          
          {/* Brand Logo & Name */}
          <Link to="/" className="flex items-center gap-2 sm:gap-2.5 min-w-0 flex-1 sm:flex-initial group">
            {settings?.logoUrl ? (
              <img 
                src={settings.logoUrl} 
                alt={settings?.storeName || 'Store Logo'} 
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl object-contain shadow-xs border border-gray-200 group-hover:scale-105 transition bg-white shrink-0"
              />
            ) : (
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-950 flex items-center justify-center text-amber-300 shadow-md border border-amber-400/30 group-hover:scale-105 transition shrink-0">
                <span className="font-serif text-base sm:text-lg font-bold">ن</span>
              </div>
            )}
            <div className="min-w-0">
              <span className="text-sm sm:text-base md:text-lg font-extrabold tracking-tight text-emerald-950 block leading-tight truncate">
                {settings?.storeName || 'NOOR AL HUDA'}
              </span>
              <span className="hidden sm:block text-[10px] font-semibold text-amber-700 tracking-wider uppercase truncate">
                {settings?.tagline || 'ISLAMIC SHOP'}
              </span>
            </div>
          </Link>

          {/* Search Bar - Desktop & Tablet */}
          <div ref={searchContainerRef} className="hidden md:flex flex-1 max-w-xl relative">
            <form onSubmit={handleSearchSubmit} className="w-full relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => { if (searchSuggestions.length > 0) setShowSuggestions(true); }}
                placeholder={t('searchPlaceholder')}
                className="w-full pl-4 pr-24 py-2 text-sm bg-gray-50 hover:bg-gray-100/80 focus:bg-white border border-gray-200 focus:border-emerald-700 rounded-full outline-none transition shadow-2xs focus:shadow-md"
              />
              <button
                type="submit"
                className="absolute right-1 top-1 bottom-1 px-4 bg-emerald-800 hover:bg-emerald-900 text-white rounded-full text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              >
                <Search className="w-3.5 h-3.5" />
                <span>{t('searchButton')}</span>
              </button>
            </form>

            {/* Live Search Suggestions Dropdown */}
            {showSuggestions && searchSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50">
                <div className="p-2 border-b border-gray-50 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                  Matching Products
                </div>
                {searchSuggestions.map((prod) => (
                  <button
                    key={prod.id}
                    onClick={() => handleSelectSuggestion(prod)}
                    className="w-full p-2.5 flex items-center gap-3 hover:bg-emerald-50/70 transition text-left cursor-pointer border-b border-gray-50 last:border-none"
                  >
                    <img 
                      src={prod.images[0]} 
                      alt={prod.title} 
                      className="w-10 h-10 object-cover rounded-md border border-gray-100 shrink-0" 
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-900 truncate">{prod.title}</p>
                      <p className="text-[11px] text-gray-500">{prod.categoryName || 'Islamic Goods'}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-xs font-bold text-emerald-800">₹{prod.price}</span>
                      {prod.originalPrice && (
                        <span className="block text-[10px] text-gray-400 line-through">₹{prod.originalPrice}</span>
                      )}
                    </div>
                  </button>
                ))}
                <div className="p-2 bg-gray-50 text-center">
                  <button
                    onClick={handleSearchSubmit}
                    className="text-xs text-emerald-800 font-semibold hover:underline flex items-center justify-center gap-1 mx-auto"
                  >
                    <span>View all matching results</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Header Navigation & Actions */}
          <div className="flex items-center gap-1 sm:gap-2.5 shrink-0">
            
            {/* Language Switcher */}
            <div ref={langMenuRef} className="relative shrink-0">
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className="flex items-center gap-0.5 sm:gap-1 p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg hover:bg-gray-100 text-gray-700 text-xs font-medium transition cursor-pointer shrink-0"
                title="Change Language"
              >
                <Globe className="w-4 h-4 text-emerald-800 shrink-0" />
                <span className="hidden sm:inline">{currentLangLabel}</span>
                <ChevronDown className="w-3 h-3 text-gray-400 shrink-0" />
              </button>

              {isLangMenuOpen && (
                <div className="absolute right-0 mt-1 w-36 bg-white rounded-xl shadow-lg border border-gray-100 py-1.5 z-50 animate-fade-in">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setIsLangMenuOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left text-xs font-medium flex items-center justify-between hover:bg-emerald-50 transition cursor-pointer ${
                        language === lang.code ? 'text-emerald-800 bg-emerald-50/50 font-bold' : 'text-gray-700'
                      }`}
                    >
                      <span>{lang.native}</span>
                      <span className="text-[10px] text-gray-400">{lang.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Wishlist Shortcut - visible on sm+ screens (pinned on mobile BottomNav) */}
            <Link
              to="/wishlist"
              className="hidden sm:flex relative p-1.5 sm:p-2 rounded-lg text-gray-700 hover:text-emerald-800 hover:bg-gray-100 transition shrink-0"
              title={t('wishlist')}
            >
              <Heart className="w-5 h-5 shrink-0" />
              {wishlistCount > 0 && (
                <span className="absolute top-0.5 right-0.5 sm:top-1 sm:right-1 w-4 h-4 bg-amber-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Cart Shortcut with Floating Count */}
            <Link
              to="/cart"
              className="relative flex items-center gap-1.5 sm:gap-2 p-1.5 sm:p-2 rounded-lg text-gray-700 hover:text-emerald-800 hover:bg-gray-100 transition group shrink-0"
              title={t('cart')}
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-emerald-900 shrink-0" />
                {itemCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-emerald-700 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full min-w-4 text-center shadow-xs">
                    {itemCount}
                  </span>
                )}
              </div>
              <div className="hidden lg:block text-left text-xs leading-none">
                <span className="text-[10px] text-gray-400 block">{t('cart')}</span>
                <span className="font-bold text-gray-800">₹{subtotal}</span>
              </div>
            </Link>

            {/* Account / Profile Button */}
            <div ref={accountMenuRef} className="relative shrink-0">
              {isAuthenticated ? (
                <button
                  onClick={() => setIsAccountMenuOpen(!isAccountMenuOpen)}
                  className="shrink-0 flex items-center gap-1 sm:gap-1.5 px-2 py-1.5 sm:px-2.5 sm:py-1.5 rounded-lg border border-gray-200 hover:border-emerald-600 bg-emerald-50/30 text-emerald-950 text-xs font-semibold transition cursor-pointer whitespace-nowrap"
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-800 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0">
                    {currentUser?.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <span className="hidden sm:inline max-w-24 truncate">
                    {currentUser?.displayName || 'My Account'}
                  </span>
                  <ChevronDown className="w-3 h-3 text-gray-400 shrink-0" />
                </button>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="shrink-0 whitespace-nowrap px-2.5 sm:px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold transition shadow-xs cursor-pointer flex items-center gap-1 sm:gap-1.5 leading-none"
                >
                  <User className="w-3.5 h-3.5 shrink-0" />
                  <span className="whitespace-nowrap inline-block">{t('signIn')}</span>
                </button>
              )}

              {/* Account Dropdown */}
              {isAccountMenuOpen && isAuthenticated && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 animate-fade-in">
                  <div className="px-3 py-2 border-b border-gray-100">
                    <p className="text-xs font-bold text-gray-900">{currentUser?.displayName}</p>
                    <p className="text-[11px] text-gray-500 truncate">{currentUser?.email}</p>
                    {isAdmin && (
                      <span className="inline-block mt-1 px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded-full">
                        {isOwner ? 'Store Owner' : 'Administrator'}
                      </span>
                    )}
                  </div>

                  {/* Switch to Admin Dashboard if owner/admin */}
                  {isAdmin && (
                    <div className="px-2 py-1.5 border-b border-gray-100 bg-amber-50/60">
                      <Link
                        to="/admin"
                        onClick={() => setIsAccountMenuOpen(false)}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-emerald-900 text-white text-xs font-semibold hover:bg-emerald-950 transition"
                      >
                        <Settings className="w-3.5 h-3.5 text-amber-400" />
                        <span>Go to Admin Dashboard</span>
                      </Link>
                    </div>
                  )}

                  <Link
                    to="/account"
                    onClick={() => setIsAccountMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition"
                  >
                    <User className="w-3.5 h-3.5 text-gray-400" />
                    <span>{t('profile')}</span>
                  </Link>

                  <Link
                    to="/orders"
                    onClick={() => setIsAccountMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition"
                  >
                    <Package className="w-3.5 h-3.5 text-gray-400" />
                    <span>{t('myOrders')}</span>
                  </Link>

                  <Link
                    to="/wishlist"
                    onClick={() => setIsAccountMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition"
                  >
                    <Heart className="w-3.5 h-3.5 text-gray-400" />
                    <span>{t('wishlist')}</span>
                  </Link>

                  <div className="border-t border-gray-100 my-1" />

                  <button
                    onClick={() => {
                      logout();
                      setIsAccountMenuOpen(false);
                      navigate('/');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-600 hover:bg-red-50 transition cursor-pointer text-left"
                  >
                    <LogOut className="w-3.5 h-3.5 text-red-500" />
                    <span>{t('signOut')}</span>
                  </button>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Mobile Search Bar */}
        <div className="md:hidden px-4 pb-2.5">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className="w-full pl-3 pr-20 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-emerald-700"
            />
            <button
              type="submit"
              className="absolute right-1 top-0.5 bottom-0.5 px-3 bg-emerald-800 text-white rounded-full text-xs font-medium flex items-center gap-1"
            >
              <Search className="w-3 h-3" />
              <span>{t('searchButton')}</span>
            </button>
          </form>
        </div>

      </header>

      {/* Pincode Selector Modal */}
      {showPincodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-sm w-full p-5 shadow-2xl border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <LocationIcon className="w-4 h-4 text-emerald-700" />
                Select Delivery Location
              </h4>
              <button onClick={() => setShowPincodeModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mb-3">
              Enter your Indian PIN code to check delivery availability and speed.
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={pincode}
                onChange={(e) => setPincode(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="e.g. 700073"
                className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-600 outline-none"
              />
              <button
                onClick={() => setShowPincodeModal(false)}
                className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold hover:bg-emerald-900 transition"
              >
                Apply
              </button>
            </div>
            <p className="text-[11px] text-emerald-700 mt-2 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Standard delivery ₹40 or FREE on orders ₹999+
            </p>
          </div>
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </>
  );
};
