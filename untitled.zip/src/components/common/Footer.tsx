import React, { useState, useEffect } from 'react';
import { Sparkles, MessageCircle, Mail, MapPin, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { api } from '../../services/api';
import { StoreSettings } from '../../types';

export const Footer: React.FC = () => {
  const { t } = useLanguage();
  const [settings, setSettings] = useState<StoreSettings | null>(null);

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
  }, []);

  return (
    <footer className="bg-emerald-950 text-gray-300 border-t border-emerald-900/60 pb-16 md:pb-8">
      {/* Trust & Guarantee Strip */}
      <div className="border-b border-emerald-900/40 bg-emerald-900/30 py-6">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 text-center sm:text-left">
          
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/80 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-white text-xs sm:text-sm font-bold">{t('trustTitle1')}</h5>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">{t('trustDesc1')}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/80 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/20">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-white text-xs sm:text-sm font-bold">{t('trustTitle2')}</h5>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">{t('trustDesc2')}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/80 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-white text-xs sm:text-sm font-bold">{t('trustTitle3')}</h5>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">{t('trustDesc3')}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800/80 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-white text-xs sm:text-sm font-bold">{t('trustTitle4')}</h5>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">{t('trustDesc4')}</p>
            </div>
          </div>

        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* Brand Information */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-2.5 mb-3">
            {settings?.logoUrl ? (
              <img 
                src={settings.logoUrl} 
                alt={settings?.storeName || 'Logo'} 
                className="w-8 h-8 rounded-lg object-contain bg-white p-0.5 border border-amber-400/30"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-300 font-serif font-bold text-base border border-amber-400/30">
                ن
              </div>
            )}
            <span className="text-base font-extrabold text-white tracking-wide">
              {settings?.storeName || 'NOOR AL HUDA'}
            </span>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed mb-4">
            {settings?.aboutUsText || 'Dedicated to providing authentic, 100% alcohol-free traditional attars, orthopedic padded janamaz, handcrafted tasbeeh, and premium Islamic essentials across India.'}
          </p>
          <div className="space-y-1.5 text-xs text-emerald-200">
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{settings?.supportEmail || settings?.ownerEmail || 'uskshayeem@gmail.com'}</span>
            </div>
            <div className="flex items-center gap-2">
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>WhatsApp: {settings?.whatsappNumber || '+91 7003735250'}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{settings?.storeAddress || 'Zakaria Street, Near Nakhoda Mosque, Kolkata, West Bengal - 700073'}</span>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3.5">
            {t('categories')}
          </h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li><Link to="/category/cat-attars" className="hover:text-white transition">Pure Attars & Oudh</Link></li>
            <li><Link to="/category/cat-janamaz" className="hover:text-white transition">Janamaz & Prayer Mats</Link></li>
            <li><Link to="/category/cat-tasbeeh" className="hover:text-white transition">Tasbeeh & Misbaha</Link></li>
            <li><Link to="/category/cat-books" className="hover:text-white transition">The Holy Quran & Books</Link></li>
            <li><Link to="/category/cat-modest" className="hover:text-white transition">Modest Wear & Abayas</Link></li>
            <li><Link to="/category/cat-decor" className="hover:text-white transition">Islamic Home Decor</Link></li>
          </ul>
        </div>

        {/* Customer Service & Policies */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3.5">
            {t('customerSupport')}
          </h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li><Link to="/orders" className="hover:text-white transition">{t('myOrders')}</Link></li>
            <li><Link to="/orders" className="hover:text-white transition">{t('trackOrder')}</Link></li>
            <li><Link to="/support#faqs" className="hover:text-white transition">{t('faqs')}</Link></li>
            <li><Link to="/support#shipping" className="hover:text-white transition">{t('shippingPolicy')}</Link></li>
            <li><Link to="/support#returns" className="hover:text-white transition">{t('returnPolicy')}</Link></li>
            <li><Link to="/support#privacy" className="hover:text-white transition">{t('privacyPolicy')}</Link></li>
          </ul>
        </div>

        {/* WhatsApp Support Box */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3.5">
            Direct Shop Communication
          </h4>
          <p className="text-xs text-gray-400 mb-3">
            Have questions about attar notes, bulk orders, or Islamic gifts? Talk directly to the shop owner on WhatsApp.
          </p>
          <a
            href={`https://wa.me/917003735250?text=${encodeURIComponent('Assalamualaikum, I have an enquiry regarding Noor Al Huda products.')}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md hover:shadow-lg transition cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Chat on WhatsApp (+91 7003735250)</span>
          </a>
          <p className="text-[10px] text-gray-500 mt-2">
            Available 7 days a week, 9:00 AM – 10:00 PM IST
          </p>
        </div>

      </div>

      {/* Bottom Copyright */}
      <div className="max-w-7xl mx-auto px-4 pt-6 border-t border-emerald-900/50 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 gap-2">
        <p>© 2026 Noor Al Huda Islamic Shop. {t('rightsReserved')}</p>
        <div className="flex items-center gap-3 text-emerald-300">
          <span>COD Available</span>
          <span>•</span>
          <span>UPI Accepted</span>
          <span>•</span>
          <span>Free Shipping &gt; ₹999</span>
        </div>
      </div>
    </footer>
  );
};
