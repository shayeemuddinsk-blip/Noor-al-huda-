import { LanguageCode } from '../types';

export interface Translations {
  appName: string;
  tagline: string;
  searchPlaceholder: string;
  searchButton: string;
  allCategories: string;
  allProducts: string;
  categories: string;
  home: string;
  cart: string;
  wishlist: string;
  account: string;
  orders: string;
  myOrders: string;
  trackOrder: string;
  savedAddresses: string;
  notifications: string;
  profile: string;
  signIn: string;
  signUp: string;
  signOut: string;
  switchPreview: string;
  backToAdmin: string;
  adminDashboard: string;
  
  // Product actions & badges
  addToCart: string;
  buyNow: string;
  addedToCart: string;
  inStock: string;
  limitedStock: string;
  outOfStock: string;
  freeDeliveryBadge: string;
  off: string;
  quickView: string;
  share: string;
  enquireWhatsApp: string;
  ratingsAndReviews: string;
  verifiedPurchase: string;
  writeReview: string;
  specifications: string;
  selectVariant: string;
  quantity: string;
  
  // Cart & Checkout
  shoppingCart: string;
  cartEmpty: string;
  cartEmptyPrompt: string;
  continueShopping: string;
  proceedToCheckout: string;
  orderSummary: string;
  subtotal: string;
  deliveryCharge: string;
  freeDelivery: string;
  freeDeliveryUnlock: string; // "Add ₹{amount} more to get Free Delivery"
  couponCode: string;
  applyCoupon: string;
  couponApplied: string;
  discount: string;
  totalPayable: string;
  deliveryAddress: string;
  addAddress: string;
  paymentMethod: string;
  confirmOrder: string;
  placingOrder: string;
  
  // Payment methods
  whatsappAssistedPayment: string;
  whatsappAssistedDesc: string;
  cashOnDelivery: string;
  cashOnDeliveryDesc: string;
  upiPayment: string;
  upiPaymentDesc: string;
  
  // Order Confirmation
  orderConfirmedTitle: string;
  orderConfirmedSub: string;
  orderIdLabel: string;
  confirmViaWhatsAppBtn: string;
  confirmViaWhatsAppSub: string;
  viewOrderDetails: string;
  
  // Order states
  statusOrderPlaced: string;
  statusOrderConfirmed: string;
  statusProcessing: string;
  statusPacked: string;
  statusShipped: string;
  statusOutForDelivery: string;
  statusDelivered: string;
  statusCancelled: string;
  
  // Sections
  featuredProducts: string;
  bestSellers: string;
  newArrivals: string;
  todaysDeals: string;
  shopByCategory: string;
  trustTitle1: string;
  trustDesc1: string;
  trustTitle2: string;
  trustDesc2: string;
  trustTitle3: string;
  trustDesc3: string;
  trustTitle4: string;
  trustDesc4: string;
  
  // Footer & Support
  aboutStore: string;
  contactUs: string;
  customerSupport: string;
  whatsappSupport: string;
  faqs: string;
  shippingPolicy: string;
  returnPolicy: string;
  privacyPolicy: string;
  termsConditions: string;
  rightsReserved: string;
}

export const translations: Record<LanguageCode, Translations> = {
  en: {
    appName: 'NOOR AL HUDA',
    tagline: 'Premium Islamic E-Commerce',
    searchPlaceholder: 'Search for Attar, Janamaz, Tasbeeh, Books, Abayas...',
    searchButton: 'Search',
    allCategories: 'All Categories',
    allProducts: 'All Products',
    categories: 'Categories',
    home: 'Home',
    cart: 'Cart',
    wishlist: 'Wishlist',
    account: 'Account',
    orders: 'Orders',
    myOrders: 'My Orders',
    trackOrder: 'Track Order',
    savedAddresses: 'Saved Addresses',
    notifications: 'Notifications',
    profile: 'Profile',
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    switchPreview: 'Customer Store Preview',
    backToAdmin: 'Return to Admin Dashboard',
    adminDashboard: 'Admin Control Panel',
    
    addToCart: 'Add to Cart',
    buyNow: 'Buy Now',
    addedToCart: 'Added to Cart',
    inStock: 'In Stock',
    limitedStock: 'Limited Stock',
    outOfStock: 'Out of Stock',
    freeDeliveryBadge: 'Free Delivery',
    off: 'OFF',
    quickView: 'Quick View',
    share: 'Share',
    enquireWhatsApp: 'Enquire on WhatsApp',
    ratingsAndReviews: 'Ratings & Reviews',
    verifiedPurchase: 'Verified Purchase',
    writeReview: 'Write a Review',
    specifications: 'Specifications',
    selectVariant: 'Select Variant',
    quantity: 'Quantity',
    
    shoppingCart: 'Shopping Cart',
    cartEmpty: 'Your shopping cart is empty',
    cartEmptyPrompt: 'Explore our collection of authentic Islamic essentials and halal fragrances.',
    continueShopping: 'Continue Shopping',
    proceedToCheckout: 'Proceed to Checkout',
    orderSummary: 'Order Summary',
    subtotal: 'Items Subtotal',
    deliveryCharge: 'Delivery Charge',
    freeDelivery: 'FREE',
    freeDeliveryUnlock: 'Add ₹{amount} more for FREE delivery!',
    couponCode: 'Enter Promo/Coupon Code',
    applyCoupon: 'Apply',
    couponApplied: 'Coupon Applied Successfully',
    discount: 'Discount',
    totalPayable: 'Total Payable',
    deliveryAddress: 'Delivery Address',
    addAddress: 'Add New Address',
    paymentMethod: 'Payment Method',
    confirmOrder: 'Place & Confirm Order',
    placingOrder: 'Placing your order safely...',
    
    whatsappAssistedPayment: 'WhatsApp Confirmation & Payment',
    whatsappAssistedDesc: 'Place order instantly, confirm via official WhatsApp chat with owner and pay via UPI/COD smoothly.',
    cashOnDelivery: 'Cash on Delivery (COD)',
    cashOnDeliveryDesc: 'Pay in cash when order is delivered to your doorstep.',
    upiPayment: 'Direct UPI Payment',
    upiPaymentDesc: 'Scan UPI QR code or pay using Google Pay, PhonePe, Paytm.',
    
    orderConfirmedTitle: 'Alhamdulillah! Order Placed Successfully',
    orderConfirmedSub: 'Thank you for shopping with Noor Al Huda Islamic Shop. Please confirm your order directly on WhatsApp for swift dispatch.',
    orderIdLabel: 'Order ID',
    confirmViaWhatsAppBtn: 'Confirm Order on WhatsApp (+91 7003735250)',
    confirmViaWhatsAppSub: 'Click here to send prefilled order details to the shop owner.',
    viewOrderDetails: 'View Order Details',
    
    statusOrderPlaced: 'Order Placed',
    statusOrderConfirmed: 'Order Confirmed',
    statusProcessing: 'Processing',
    statusPacked: 'Packed',
    statusShipped: 'Shipped',
    statusOutForDelivery: 'Out for Delivery',
    statusDelivered: 'Delivered',
    statusCancelled: 'Cancelled',
    
    featuredProducts: 'Featured Products',
    bestSellers: 'Best Sellers',
    newArrivals: 'New Arrivals',
    todaysDeals: "Today's Special Deals",
    shopByCategory: 'Shop by Category',
    trustTitle1: '100% Authentic Halal',
    trustDesc1: 'All attars are alcohol-free, genuine and purest ingredients.',
    trustTitle2: 'Verified WhatsApp Support',
    trustDesc2: 'Direct communication with the owner (+91 7003735250).',
    trustTitle3: 'Fast Delivery in India',
    trustDesc3: 'Reliable doorstep delivery across all Indian pin codes.',
    trustTitle4: 'Secure & Trustworthy',
    trustDesc4: 'Safe packing with bubble wrap and sealed boxes.',
    
    aboutStore: 'About Noor Al Huda',
    contactUs: 'Contact Us',
    customerSupport: 'Customer Support',
    whatsappSupport: 'WhatsApp Support',
    faqs: 'Frequently Asked Questions',
    shippingPolicy: 'Shipping Policy',
    returnPolicy: 'Return & Refund Policy',
    privacyPolicy: 'Privacy Policy',
    termsConditions: 'Terms & Conditions',
    rightsReserved: 'All rights reserved. Noor Al Huda Islamic Shop, India.'
  },
  
  bn: {
    appName: 'নূর আল হুদা',
    tagline: 'প্রিমিয়াম ইসলামিক ই-কমার্স',
    searchPlaceholder: 'আতর, জায়নামাজ, তসবিহ, ইসলামিক বই, বোরকা খুঁজুন...',
    searchButton: 'অনুসন্ধান',
    allCategories: 'সকল বিভাগ',
    allProducts: 'সমস্ত প্রোডাক্ট',
    categories: 'বিভাগসমূহ',
    home: 'হোম',
    cart: 'কার্ট',
    wishlist: 'পছন্দের তালিকা',
    account: 'অ্যাকাউন্ট',
    orders: 'অর্ডার',
    myOrders: 'আমার অর্ডারসমূহ',
    trackOrder: 'অর্ডার ট্র্যাক করুন',
    savedAddresses: 'সংরক্ষিত ঠিকানা',
    notifications: 'বিজ্ঞপ্তি',
    profile: 'প্রোফাইল',
    signIn: 'লগইন করুন',
    signUp: 'নিবন্ধন করুন',
    signOut: 'লগআউট',
    switchPreview: 'কাস্টমার স্টোর প্রিভিউ',
    backToAdmin: 'অ্যাডমিন ড্যাশবোর্ডে ফিরুন',
    adminDashboard: 'অ্যাডমিন কন্ট্রোল প্যানেল',
    
    addToCart: 'কার্টে যোগ করুন',
    buyNow: 'এখনই কিনুন',
    addedToCart: 'কার্টে যোগ হয়েছে',
    inStock: 'স্টকে আছে',
    limitedStock: 'সীমিত স্টক',
    outOfStock: 'স্টক শেষ',
    freeDeliveryBadge: 'ফ্রি ডেলিভারি',
    off: 'ছাড়',
    quickView: 'একনজরে দেখুন',
    share: 'শেয়ার করুন',
    enquireWhatsApp: 'হোয়াটসঅ্যাপে জানুন',
    ratingsAndReviews: 'রেটিং ও পর্যালোচনা',
    verifiedPurchase: 'যাচাইকৃত ক্রেতা',
    writeReview: 'রিভিউ লিখুন',
    specifications: 'বৈশিষ্ট্যসমূহ',
    selectVariant: 'ধরন নির্বাচন করুন',
    quantity: 'পরিমাণ',
    
    shoppingCart: 'শপিং কার্ট',
    cartEmpty: 'আপনার কার্ট খালি',
    cartEmptyPrompt: 'আমাদের খাঁটি ইসলামিক পণ্য ও অ্যালকোহলমুক্ত সুগন্ধি সংগ্রহ দেখুন।',
    continueShopping: 'কেনাকাটা চালিয়ে যান',
    proceedToCheckout: 'চেকআউট করুন',
    orderSummary: 'অর্ডারের বিবরণ',
    subtotal: 'পণ্যের মূল্য',
    deliveryCharge: 'ডেলিভারি চার্জ',
    freeDelivery: 'বিনামূল্যে',
    freeDeliveryUnlock: 'ফ্রি ডেলিভারির জন্য আরও ₹{amount} যোগ করুন!',
    couponCode: 'কুপন কোড লিখুন',
    applyCoupon: 'প্রয়োগ করুন',
    couponApplied: 'কুপন সফলভাবে প্রয়োগ করা হয়েছে',
    discount: 'ছাড়',
    totalPayable: 'মোট প্রদেয় টাকা',
    deliveryAddress: 'ডেলিভারি ঠিকানা',
    addAddress: 'নতুন ঠিকানা যোগ করুন',
    paymentMethod: 'পেমেন্ট পদ্ধতি',
    confirmOrder: 'অর্ডার নিশ্চিত করুন',
    placingOrder: 'অর্ডার প্রক্রিয়া করা হচ্ছে...',
    
    whatsappAssistedPayment: 'হোয়াটসঅ্যাপ কনফার্মেশন ও পেমেন্ট',
    whatsappAssistedDesc: 'সহজে অর্ডার দিন এবং হোয়াটসঅ্যাপে স্বত্বাধিকারীর সাথে যোগাযোগ করে নিশ্চিত করুন।',
    cashOnDelivery: 'ক্যাশ অন ডেলিভারি (COD)',
    cashOnDeliveryDesc: 'পণ্য হাতে পেয়ে মূল্য পরিশোধ করুন।',
    upiPayment: 'সরাসরি ইউপিআই (UPI) পেমেন্ট',
    upiPaymentDesc: 'Google Pay, PhonePe বা Paytm এর মাধ্যমে QR কোড স্ক্যান করে পেমেন্ট করুন।',
    
    orderConfirmedTitle: 'আলহামদুলিল্লাহ! অর্ডার সফল হয়েছে',
    orderConfirmedSub: 'নূর আল হুদা ইসলামিক শপে কেনাকাটার জন্য ধন্যবাদ। দ্রুত ডেলিভারির জন্য অনুগ্রহ করে হোয়াটসঅ্যাপে কনফার্ম করুন।',
    orderIdLabel: 'অর্ডার নম্বর',
    confirmViaWhatsAppBtn: 'হোয়াটসঅ্যাপে অর্ডার নিশ্চিত করুন (+91 7003735250)',
    confirmViaWhatsAppSub: 'এখানে ক্লিক করে মালিককে সরাসরি অর্ডারের বিবরণ পাঠান।',
    viewOrderDetails: 'অর্ডারের বিস্তারিত দেখুন',
    
    statusOrderPlaced: 'অর্ডার গৃহীত হয়েছে',
    statusOrderConfirmed: 'অর্ডার নিশ্চিত হয়েছে',
    statusProcessing: 'প্রক্রিয়াকরণ চলছে',
    statusPacked: 'প্যাকেট সম্পন্ন',
    statusShipped: 'পাঠানো হয়েছে',
    statusOutForDelivery: 'ডেলিভারির জন্য বের হয়েছে',
    statusDelivered: 'পৌঁছে দেওয়া হয়েছে',
    statusCancelled: 'বাতিল করা হয়েছে',
    
    featuredProducts: 'বিশেষ পণ্যসমূহ',
    bestSellers: 'জনপ্রিয় পণ্যসমূহ',
    newArrivals: 'নতুন কালেকশন',
    todaysDeals: 'আজকের সেরা অফার',
    shopByCategory: 'ক্যাটাগরি অনুযায়ী কেনাকাটা',
    trustTitle1: '১০০% খাঁটি ও হালাল',
    trustDesc1: 'আমাদের সকল আতর সম্পূর্ণ অ্যালকোহলমুক্ত এবং খাঁটি উপাদানে তৈরি।',
    trustTitle2: 'সরাসরি হোয়াটসঅ্যাপ সহায়তা',
    trustDesc2: 'স্বত্বাধিকারীর সাথে সরাসরি কথা বলুন (+91 7003735250)।',
    trustTitle3: 'সমগ্র ভারতে দ্রুত ডেলিভারি',
    trustDesc3: 'ভারতের যেকোনো পিন কোডে নিরাপদে হোম ডেলিভারি।',
    trustTitle4: 'বিশ্বস্ত ও নিরাপদ প্যাকেজিং',
    trustDesc4: 'নিখুঁত বাবল র‍্যাপ এবং সিল করা বাক্সে সুরক্ষিত ডেলিভারি।',
    
    aboutStore: 'নূর আল হুদা সম্পর্কে',
    contactUs: 'যোগাযোগ',
    customerSupport: 'গ্রাহক সেবা',
    whatsappSupport: 'হোয়াটসঅ্যাপ সাপোর্ট',
    faqs: 'সাধারণ জিজ্ঞাসা',
    shippingPolicy: 'ডেলিভারি নীতিমালা',
    returnPolicy: 'রিটার্ন ও রিফান্ড নীতি',
    privacyPolicy: 'গোপনীয়তা নীতি',
    termsConditions: 'শর্তাবলী',
    rightsReserved: 'সর্বস্বত্ব সংরক্ষিত। নূর আল হুদা ইসলামিক শপ, ভারত।'
  },
  
  hi: {
    appName: 'नूर अल हुदा',
    tagline: 'प्रीमियम इस्लामिक ई-कॉमर्स',
    searchPlaceholder: 'इत्र, जा-नमाज़, तस्बीह, इस्लामिक किताबें, अबाया खोजें...',
    searchButton: 'खोजें',
    allCategories: 'सभी श्रेणियां',
    allProducts: 'सभी उत्पाद',
    categories: 'श्रेणियां',
    home: 'होम',
    cart: 'कार्ट',
    wishlist: 'विशलिस्ट',
    account: 'खाता',
    orders: 'ऑर्डर्स',
    myOrders: 'मेरे ऑर्डर्स',
    trackOrder: 'ऑर्डर ट्रैक करें',
    savedAddresses: 'सहेजे गए पते',
    notifications: 'सूचनाएं',
    profile: 'प्रोफाइल',
    signIn: 'लॉग इन करें',
    signUp: 'साइन अप करें',
    signOut: 'लॉग आउट',
    switchPreview: 'कस्टमर स्टोर प्रीव्यू',
    backToAdmin: 'एडमिन डैशबोर्ड पर लौटें',
    adminDashboard: 'एडमिन कंट्रोल पैनल',
    
    addToCart: 'कार्ट में जोड़ें',
    buyNow: 'अभी खरीदें',
    addedToCart: 'कार्ट में जोड़ा गया',
    inStock: 'स्टॉक में उपलब्ध',
    limitedStock: 'सीमित स्टॉक',
    outOfStock: 'स्टॉक समाप्त',
    freeDeliveryBadge: 'फ्री डिलीवरी',
    off: 'छूट',
    quickView: 'त्वरित झलक',
    share: 'शेयर करें',
    enquireWhatsApp: 'व्हाट्सएप पर जानकारी लें',
    ratingsAndReviews: 'रेटिंग और समीक्षाएं',
    verifiedPurchase: 'प्रमाणित खरीदार',
    writeReview: 'समीक्षा लिखें',
    specifications: 'विशेषताएं',
    selectVariant: 'विकल्प चुनें',
    quantity: 'मात्रा',
    
    shoppingCart: 'शॉपिंग कार्ट',
    cartEmpty: 'आपकी कार्ट खाली है',
    cartEmptyPrompt: 'हमारे प्रीमियम इस्लामिक उत्पाद एवं खुशबूदार इत्र संग्रह का अन्वेषण करें।',
    continueShopping: 'खरीदारी जारी रखें',
    proceedToCheckout: 'चेकआउट के लिए आगे बढ़ें',
    orderSummary: 'ऑर्डर का विवरण',
    subtotal: 'वस्तुओं का उप-योग',
    deliveryCharge: 'डिलीवरी शुल्क',
    freeDelivery: 'मुफ्त',
    freeDeliveryUnlock: 'फ्री डिलीवरी पाने के लिए ₹{amount} का सामान और जोड़ें!',
    couponCode: 'कूपन कोड दर्ज करें',
    applyCoupon: 'लागू करें',
    couponApplied: 'कूपन सफलतापूर्वक लागू किया गया',
    discount: 'छूट',
    totalPayable: 'कुल देय राशि',
    deliveryAddress: 'डिलीवरी का पता',
    addAddress: 'नया पता जोड़ें',
    paymentMethod: 'भुगतान का तरीका',
    confirmOrder: 'ऑर्डर पक्का करें',
    placingOrder: 'ऑर्डर दर्ज किया जा रहा है...',
    
    whatsappAssistedPayment: 'व्हाट्सएप पुष्टिकरण और भुगतान',
    whatsappAssistedDesc: 'ऑर्डर दें और आधिकारिक व्हाट्सएप चैट पर मालिक के साथ आसानी से पुष्टि और भुगतान करें।',
    cashOnDelivery: 'कैश ऑन डिलीवरी (COD)',
    cashOnDeliveryDesc: 'ऑर्डर मिलने पर नकद भुगतान करें।',
    upiPayment: 'सीधा यूपीआई (UPI) भुगतान',
    upiPaymentDesc: 'Google Pay, PhonePe, Paytm द्वारा QR कोड स्कैन करके भुगतान करें।',
    
    orderConfirmedTitle: 'अल्हम्दुलिल्लाह! ऑर्डर सफलतापूर्वक दर्ज हुआ',
    orderConfirmedSub: 'नूर अल हुदा इस्लामिक शॉप से खरीदारी के लिए धन्यवाद। तुरंत डिस्पैच के लिए कृपया व्हाट्सएप पर पुष्टि करें।',
    orderIdLabel: 'ऑर्डर आईडी',
    confirmViaWhatsAppBtn: 'व्हाट्सएप पर ऑर्डर की पुष्टि करें (+91 7003735250)',
    confirmViaWhatsAppSub: 'दुकानदार को तैयार ऑर्डर विवरण भेजने के लिए यहां क्लिक करें।',
    viewOrderDetails: 'ऑर्डर विवरण देखें',
    
    statusOrderPlaced: 'ऑर्डर प्राप्त हुआ',
    statusOrderConfirmed: 'ऑर्डर कन्फर्म हुआ',
    statusProcessing: 'प्रोसेसिंग जारी',
    statusPacked: 'पैक हो गया',
    statusShipped: 'डिस्पैच हो गया',
    statusOutForDelivery: 'डिलीवरी के लिए निकला',
    statusDelivered: 'डिलीवर हो गया',
    statusCancelled: 'रद्द किया गया',
    
    featuredProducts: 'प्रमुख उत्पाद',
    bestSellers: 'सबसे लोकप्रिय',
    newArrivals: 'नवीनतम संग्रह',
    todaysDeals: 'आज के विशेष ऑफर',
    shopByCategory: 'श्रेणी अनुसार खरीदारी',
    trustTitle1: '100% प्रामाणिक हलाल',
    trustDesc1: 'सभी इत्र अल्कोहल-मुक्त और शुद्धतम गुणवत्ता के हैं।',
    trustTitle2: 'सीधा व्हाट्सएप सपोर्ट',
    trustDesc2: 'दुकान मालिक से सीधे बातचीत (+91 7003735250)।',
    trustTitle3: 'भारत भर में त्वरित डिलीवरी',
    trustDesc3: 'सभी भारतीय पिन कोड पर सुरक्षित होम डिलीवरी।',
    trustTitle4: 'सुरक्षित व भरोसेमंद पैकिंग',
    trustDesc4: 'मजबूत बबल रैप और सीलबंद बॉक्स में डिलीवरी।',
    
    aboutStore: 'नूर अल हुदा के बारे में',
    contactUs: 'संपर्क करें',
    customerSupport: 'ग्राहक सेवा',
    whatsappSupport: 'व्हाट्सएप सहायता',
    faqs: 'अक्सर पूछे जाने वाले प्रश्न',
    shippingPolicy: 'शिपिंग नीति',
    returnPolicy: 'वापसी एवं रिफंड नीति',
    privacyPolicy: 'गोपनीयता नीति',
    termsConditions: 'नियम एवं शर्तें',
    rightsReserved: 'सर्वाधिकार सुरक्षित। नूर अल हुदा इस्लामिक शॉप, भारत।'
  },
  
  ur: {
    appName: 'نور الہدیٰ',
    tagline: 'پریمیم اسلامک ای کامرس',
    searchPlaceholder: 'عطر، جائے نماز، تسبیح، اسلامی کتب، عبایہ تلاش کریں...',
    searchButton: 'تلاش کریں',
    allCategories: 'تمام زمرہ جات',
    allProducts: 'تمام مصنوعات',
    categories: 'زمرہ جات',
    home: 'ہوم',
    cart: 'ٹوکری',
    wishlist: 'پسندیدہ اشیاء',
    account: 'اکاؤنٹ',
    orders: 'آرڈرز',
    myOrders: 'میرے آرڈرز',
    trackOrder: 'آرڈر ٹریک کریں',
    savedAddresses: 'محفوظ پتے',
    notifications: 'اطلاعات',
    profile: 'پروفائل',
    signIn: 'لاگ ان کریں',
    signUp: 'اکاؤنٹ بنائیں',
    signOut: 'لاگ آؤٹ',
    switchPreview: 'کسٹمر اسٹور پریویو',
    backToAdmin: 'ایڈمن ڈیش بورڈ پر واپس جائیں',
    adminDashboard: 'ایڈمن کنٹرول پینل',
    
    addToCart: 'ٹوکری میں ڈالیں',
    buyNow: 'ابھی خریدیں',
    addedToCart: 'ٹوکری میں شامل کر دیا گیا',
    inStock: 'دستیاب ہے',
    limitedStock: 'محدود اسٹاک',
    outOfStock: 'اسٹاک ختم',
    freeDeliveryBadge: 'مفت ڈیلیوری',
    off: 'رعایت',
    quickView: 'فوری جائزہ',
    share: 'شیئر کریں',
    enquireWhatsApp: 'واٹس ایپ پر رابطہ کریں',
    ratingsAndReviews: 'درجہ بندی اور آراء',
    verifiedPurchase: 'تصدیق شدہ خریدار',
    writeReview: 'رائے تحریر کریں',
    specifications: 'تفصیلات و خصوصیات',
    selectVariant: 'سائز یا قسم منتخب کریں',
    quantity: 'تعداد',
    
    shoppingCart: 'شاپنگ کارٹ',
    cartEmpty: 'آپ کی ٹوکری خالی ہے',
    cartEmptyPrompt: 'ہماری خالص اسلامی اشیاء اور الکحل سے پاک خوشبویات ملاحظہ فرمائیں۔',
    continueShopping: 'خریداری جاری رکھیں',
    proceedToCheckout: 'چیک آؤٹ کے لیے آگے بڑھیں',
    orderSummary: 'آرڈر کا خلاصہ',
    subtotal: 'اشیاء کی کل قیمت',
    deliveryCharge: 'ڈیلیوری چارجز',
    freeDelivery: 'مفت',
    freeDeliveryUnlock: 'مفت ڈیلیوری کے لیے مزید ₹{amount} کی اشیاء شامل کریں!',
    couponCode: 'کوپن کوڈ درج کریں',
    applyCoupon: 'لاگو کریں',
    couponApplied: 'کوپن کامیابی سے لاگو ہو گیا',
    discount: 'رعایت',
    totalPayable: 'کل قابل ادائیگی رقم',
    deliveryAddress: 'ڈیلیوری کا پتہ',
    addAddress: 'نیا پتہ شامل کریں',
    paymentMethod: 'طریقہ ادائیگی',
    confirmOrder: 'آرڈر مکمل کریں',
    placingOrder: 'آرڈر درج کیا جا رہا ہے...',
    
    whatsappAssistedPayment: 'واٹس ایپ تصدیق اور ادائیگی',
    whatsappAssistedDesc: 'آرڈر دیں اور باضابطہ واٹس ایپ پر مالک کے ساتھ رابطہ کر کے تصدیق و ادائیگی فرمائیں۔',
    cashOnDelivery: 'کیش آن ڈیلیوری (COD)',
    cashOnDeliveryDesc: 'سامان ملنے پر نقد رقم ادا کریں۔',
    upiPayment: 'براہ راست یو پی آئی (UPI) ادائیگی',
    upiPaymentDesc: 'گوگل پے، فون پے یا پی ٹی ایم کے ذریعے کیو آر کوڈ اسکین کر کے ادائیگی کریں۔',
    
    orderConfirmedTitle: 'الحمد للہ! آرڈر کامیابی کے ساتھ موصول ہوا',
    orderConfirmedSub: 'نور الہدیٰ اسلامک شاپ سے خریداری کا شکریہ۔ فوری ترسیل کے لیے براہ کرم واٹس ایپ پر آرڈر کی تصدیق کریں۔',
    orderIdLabel: 'آرڈر نمبر',
    confirmViaWhatsAppBtn: 'واٹس ایپ پر آرڈر کی تصدیق کریں (+91 7003735250)',
    confirmViaWhatsAppSub: 'دکاندار کو آرڈر کی تفصیلات بھیجنے کے لیے یہاں کلک کریں۔',
    viewOrderDetails: 'آرڈر کی تفصیلات دیکھیں',
    
    statusOrderPlaced: 'آرڈر موصول ہوا',
    statusOrderConfirmed: 'آرڈر تصدیق شدہ',
    statusProcessing: 'تیاری جاری ہے',
    statusPacked: 'پیک کر دیا گیا',
    statusShipped: 'روانہ کر دیا گیا',
    statusOutForDelivery: 'ڈیلیوری کے لیے روانہ',
    statusDelivered: 'پہنچا دیا گیا',
    statusCancelled: 'منسوخ شدہ',
    
    featuredProducts: 'نمایاں مصنوعات',
    bestSellers: 'سب سے زیادہ فروخت ہونے والی',
    newArrivals: 'نئی آمد',
    todaysDeals: 'آج کی خصوصی پیشکش',
    shopByCategory: 'زمرہ کے لحاظ سے خریداری',
    trustTitle1: '100% خالص اور حلال',
    trustDesc1: 'تمام عطور الکحل سے پاک اور خالص ترین اجزاء سے تیار کردہ ہیں۔',
    trustTitle2: 'براہ راست واٹس ایپ سپورٹ',
    trustDesc2: 'دکان کے مالک سے براہ راست گفتگو (+91 7003735250)۔',
    trustTitle3: 'پوورے ہندوستان میں تیز ترسیل',
    trustDesc3: 'ہندوستان کے تمام پن کوڈز پر محفوظ ہوم ڈیلیوری۔',
    trustTitle4: 'محفوظ اور تسلی بخش پیکنگ',
    trustDesc4: 'مضبوط ببل ریپ اور سیل شدہ ڈبوں میں ترسیل۔',
    
    aboutStore: 'نور الہدیٰ کے بارے میں',
    contactUs: 'رابطہ کریں',
    customerSupport: 'کسٹمر سپورٹ',
    whatsappSupport: 'واٹس ایپ سپورٹ',
    faqs: 'اکثر پوچھے جانے والے سوالات',
    shippingPolicy: 'ترسیل کی پالیسی',
    returnPolicy: 'واپسی اور رقم کی واپسی کی پالیسی',
    privacyPolicy: 'پرائیویسی پالیسی',
    termsConditions: 'شرائط و ضوابط',
    rightsReserved: 'جملہ حقوق محفوظ ہیں۔ نور الہدیٰ اسلامک شاپ، بھارت۔'
  }
};
