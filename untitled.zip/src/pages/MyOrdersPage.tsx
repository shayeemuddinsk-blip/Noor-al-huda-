import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Package, ChevronRight, Clock, MessageCircle, 
  CheckCircle, Truck, AlertCircle, ShoppingBag, ArrowRight 
} from 'lucide-react';
import { api } from '../services/api';
import { Order, OrderStatus } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

export const MyOrdersPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser?.email) {
      setOrders([]);
      setLoading(false);
      return;
    }
    // Fetch orders strictly for the logged-in customer email
    api.getOrders(currentUser.email).then((res) => {
      setOrders(res);
      setLoading(false);
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  }, [currentUser]);

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Order Placed':
        return <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold">Placed</span>;
      case 'Order Confirmed':
        return <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">Confirmed</span>;
      case 'Processing':
      case 'Packed':
        return <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold">{status}</span>;
      case 'Shipped':
      case 'Out for Delivery':
        return <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">{status}</span>;
      case 'Delivered':
        return <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 text-[10px] font-bold">Delivered</span>;
      case 'Cancelled':
        return <span className="px-2.5 py-0.5 rounded-full bg-red-50 text-red-800 border border-red-200 text-[10px] font-bold">Cancelled</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-800 text-[10px] font-bold">{status}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
            {t('myOrders')}
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            View real-time tracking, order receipts, and WhatsApp assistance for all your purchases.
          </p>
        </div>

        {/* Orders list */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2].map((n) => (
              <div key={n} className="bg-white rounded-2xl h-40 border border-gray-100 animate-pulse" />
            ))}
          </div>
        ) : !currentUser ? (
          <div className="bg-white rounded-2xl p-10 text-center border border-gray-200 shadow-xs">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-800 mx-auto flex items-center justify-center mb-3">
              <Package className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-gray-900 mb-1">Please Sign In to View Your Orders</h3>
            <p className="text-xs text-gray-500 mb-4 max-w-sm mx-auto">
              Sign in to your account to view your past purchases, track active shipments, and download invoices.
            </p>
            <Link to="/account" className="inline-block px-5 py-2.5 bg-emerald-800 text-white rounded-xl text-xs font-semibold hover:bg-emerald-900 transition">
              Sign In to Your Account
            </Link>
          </div>
        ) : orders.length > 0 ? (
          <div className="space-y-4">
            {orders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl p-5 border border-gray-200/80 shadow-xs hover:border-emerald-800/40 transition flex flex-col justify-between"
              >
                {/* Top line: Order ID, Date & Status */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
                  <div>
                    <span className="text-xs font-mono font-bold text-emerald-900 block">
                      {order.id}
                    </span>
                    <span className="text-[11px] text-gray-400">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(order.status)}
                    <span className="text-sm font-extrabold text-gray-900">
                      ₹{order.totalAmount}
                    </span>
                  </div>
                </div>

                {/* Items List */}
                <div className="py-3 space-y-2">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <img
                        src={item.image}
                        alt={item.productTitle}
                        className="w-12 h-12 rounded-lg object-cover border border-gray-100 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-gray-900 truncate">
                          {item.productTitle}
                        </p>
                        <p className="text-[11px] text-gray-400">
                          {item.variantName ? `${item.variantName} • ` : ''}Qty: {item.quantity} • ₹{item.price} each
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Bottom Actions */}
                <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="text-[11px] text-gray-500">
                    Payment: <strong className="capitalize">{order.paymentMethod.replace('_', ' ')}</strong> ({order.paymentStatus})
                  </span>

                  <div className="flex items-center gap-2">
                    <a
                      href={`https://wa.me/917003735250?text=${encodeURIComponent(`Assalamualaikum, I am checking on the status of my order ${order.id}.`)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg border border-emerald-700/40 text-emerald-800 font-bold hover:bg-emerald-50 transition flex items-center gap-1.5"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp Help</span>
                    </a>

                    <Link
                      to={`/orders/${order.id}`}
                      className="px-3.5 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold transition flex items-center gap-1 shadow-xs"
                    >
                      <span>Track Order</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>

              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-10 text-center border border-gray-200">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-800 mx-auto flex items-center justify-center mb-3">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-gray-900 mb-1">No orders found</h3>
            <p className="text-xs text-gray-500 mb-4">When you place an order, it will appear here for live tracking.</p>
            <Link to="/search" className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold">
              Explore Products
            </Link>
          </div>
        )}

      </div>
    </div>
  );
};
