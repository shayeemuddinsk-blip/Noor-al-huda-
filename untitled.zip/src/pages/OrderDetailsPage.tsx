import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, CheckCircle2, Clock, Truck, Package, 
  MapPin, MessageCircle, FileText, ShieldCheck, AlertCircle, Printer 
} from 'lucide-react';
import { api } from '../services/api';
import { Order, OrderStatus } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

export const OrderDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api.getOrderById(id).then((ord) => {
      setOrder(ord);
      setLoading(false);
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] flex items-center justify-center p-6">
        <div className="w-8 h-8 border-4 border-emerald-800 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] py-16 flex items-center justify-center px-4">
        <div className="bg-white p-8 rounded-2xl text-center max-w-sm border border-gray-200">
          <p className="text-sm text-gray-700 mb-4">Order #{id} not found.</p>
          <Link to="/orders" className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold">
            View All Orders
          </Link>
        </div>
      </div>
    );
  }

  const trackingSteps: { status: OrderStatus; label: string; desc: string }[] = [
    { status: 'Order Placed', label: 'Order Placed', desc: 'Received & logged in database' },
    { status: 'Order Confirmed', label: 'Confirmed', desc: 'Verified on WhatsApp with owner' },
    { status: 'Packed', label: 'Packed', desc: 'Quality checked & bubble wrapped' },
    { status: 'Shipped', label: 'Shipped', desc: 'Dispatched with Indian courier partner' },
    { status: 'Delivered', label: 'Delivered', desc: 'Package handed over safely' },
  ];

  const getStepState = (stepStatus: OrderStatus) => {
    const statusOrder: OrderStatus[] = [
      'Order Placed', 'Order Confirmed', 'Processing', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'
    ];
    const currentIndex = statusOrder.indexOf(order.status);
    const stepIndex = statusOrder.indexOf(stepStatus);

    if (order.status === 'Cancelled') return 'cancelled';
    if (currentIndex >= stepIndex) return 'completed';
    return 'pending';
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        
        {/* Breadcrumb */}
        <Link to="/orders" className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-emerald-800 transition print:hidden">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to All Orders</span>
        </Link>

        {/* Order Header Card */}
        <div className="bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-gray-900 font-mono">
                {order.id}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
                {order.status}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Placed on {new Date(order.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
            </p>
          </div>

          <div className="flex items-center gap-2 print:hidden">
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-gray-50 text-gray-800 font-bold text-xs border border-gray-300 shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              title="Print official invoice or save as PDF"
            >
              <Printer className="w-4 h-4 text-emerald-800" />
              <span>Print Invoice / PDF</span>
            </button>

            <a
              href={`https://wa.me/917003735250?text=${encodeURIComponent(`Assalamualaikum, I am inquiring regarding my order ${order.id}. Total amount: ₹${order.totalAmount}.`)}`}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Store Owner</span>
            </a>
          </div>
        </div>

        {/* Real-time Order Tracking Timeline */}
        <div className="bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs">
          <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-6 flex items-center gap-1.5">
            <Truck className="w-4 h-4 text-emerald-800" />
            Order Fulfillment Progress
          </h3>

          <div className="relative flex flex-col md:flex-row justify-between gap-6 md:gap-2">
            {trackingSteps.map((step, idx) => {
              const state = getStepState(step.status);
              return (
                <div key={idx} className="flex-1 flex md:flex-col items-center md:text-center gap-3 md:gap-2 relative">
                  
                  {/* Step Icon */}
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 border-2 transition z-10 ${
                    state === 'completed'
                      ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                      : 'bg-white text-gray-300 border-gray-200'
                  }`}>
                    {state === 'completed' ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <Clock className="w-4 h-4" />
                    )}
                  </div>

                  <div>
                    <h4 className={`text-xs font-bold ${
                      state === 'completed' ? 'text-gray-900' : 'text-gray-400'
                    }`}>
                      {step.label}
                    </h4>
                    <p className="text-[10px] text-gray-500 mt-0.5 max-w-[140px] leading-tight">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Items & Price Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Items (col 7) */}
          <div className="md:col-span-7 bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs space-y-4">
            <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider border-b border-gray-100 pb-3 flex items-center gap-1.5">
              <Package className="w-4 h-4 text-emerald-800" />
              Purchased Items ({order.items.length})
            </h3>

            <div className="space-y-3 divide-y divide-gray-50">
              {order.items.map((it, idx) => (
                <div key={idx} className="pt-2 first:pt-0 flex items-center justify-between text-xs gap-3">
                  <div className="flex items-center gap-3">
                    <img src={it.image} alt="" className="w-12 h-12 rounded-xl object-cover border border-gray-100" />
                    <div>
                      <p className="font-bold text-gray-900">{it.productTitle}</p>
                      <p className="text-[11px] text-gray-500">
                        {it.variantName ? `${it.variantName} • ` : ''}Qty: {it.quantity} (₹{it.price} each)
                      </p>
                    </div>
                  </div>
                  <span className="font-extrabold text-gray-900">₹{it.lineTotal}</span>
                </div>
              ))}
            </div>

            {/* Address */}
            <div className="pt-4 border-t border-gray-100 flex items-start gap-2.5 text-xs text-gray-600">
              <MapPin className="w-4 h-4 text-emerald-800 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-gray-900 mb-0.5">Shipping Address:</p>
                <p>{order.shippingAddress.fullName}</p>
                <p>{order.shippingAddress.houseFlat}, {order.shippingAddress.street}</p>
                <p>{order.shippingAddress.locality ? `${order.shippingAddress.locality}, ` : ''}{order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pinCode}</p>
                <p className="text-gray-400 mt-1">Phone: {order.shippingAddress.phone}</p>
              </div>
            </div>
          </div>

          {/* Pricing breakdown (col 5) */}
          <div className="md:col-span-5 bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs space-y-3.5 text-xs">
            <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider border-b border-gray-100 pb-3 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-emerald-800" />
              Invoice Summary
            </h3>

            <div className="space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Items Subtotal:</span>
                <span className="font-bold text-gray-900">₹{order.subtotal}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Coupon Discount ({order.couponCode}):</span>
                  <span>-₹{order.discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-600">
                <span>Delivery Charge:</span>
                <span className="font-semibold text-gray-900">
                  {order.deliveryCharge === 0 ? 'FREE' : `₹${order.deliveryCharge}`}
                </span>
              </div>
            </div>

            <div className="border-t border-gray-100 pt-3 flex justify-between items-baseline">
              <span className="font-bold text-gray-900 text-sm">Total Paid / Payable:</span>
              <span className="text-xl font-extrabold text-emerald-950">₹{order.totalAmount}</span>
            </div>

            <div className="p-3 bg-gray-50 rounded-xl space-y-1 text-[11px] text-gray-500">
              <p>Payment Method: <strong className="text-gray-800 capitalize">{order.paymentMethod.replace('_', ' ')}</strong></p>
              <p>Payment Status: <strong className="text-gray-800 capitalize">{order.paymentStatus}</strong></p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
