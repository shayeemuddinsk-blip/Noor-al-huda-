import React, { useState, useEffect } from 'react';
import { 
  Sparkles, ArrowRight, ShieldCheck, Truck, MessageCircle, 
  ChevronLeft, ChevronRight, Star, Heart, ShoppingBag, Eye, Layers 
} from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../services/api';
import { Product, Category, Banner } from '../types';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';
import { useLanguage } from '../contexts/LanguageContext';

export const HomePage: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [banners, setBanners] = useState<Banner[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  // Category selection on home page: defaults to 'all' whenever simply opening or returning to Home
  const categoryParam = searchParams.get('category');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    if (categoryParam) {
      setSelectedCategory(categoryParam);
    } else {
      setSelectedCategory('all');
    }
  }, [categoryParam]);

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    if (catId === 'all') {
      searchParams.delete('category');
      setSearchParams(searchParams, { replace: true });
    } else {
      setSearchParams({ category: catId }, { replace: true });
    }
  };

  useEffect(() => {
    Promise.all([
      api.getBanners(),
      api.getCategories(),
      api.getProducts(),
    ]).then(([b, c, p]) => {
      setBanners(b.filter(banner => banner.isActive));
      setCategories(c.filter(cat => cat.isActive));
      setProducts(p.filter(prod => prod.isActive));
      setLoading(false);
    }).catch((err) => {
      console.error('Failed to load homepage data:', err);
      setLoading(false);
    });
  }, []);

  // Banner auto-play
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [banners.length]);

  const featuredAttars = products.filter((p) => p.categoryId === 'cat-attars');
  const prayerEssentials = products.filter((p) => p.categoryId === 'cat-janamaz' || p.categoryId === 'cat-tasbeeh');
  const bestSellers = products.filter((p) => p.isBestSeller);

  const currentCategory = categories.find((c) => c.id === selectedCategory);
  const filteredProducts = selectedCategory === 'all'
    ? products
    : products.filter((p) => p.categoryId === selectedCategory);

  return (
    <div className="min-h-screen bg-[#fdfbf7]">
      
      {/* Hero Banner Slider */}
      {banners.length > 0 && (
        <section className="relative overflow-hidden bg-emerald-950">
          <div className="relative h-[240px] sm:h-[340px] md:h-[420px] lg:h-[480px] w-full">
            {banners.map((banner, index) => (
              <div
                key={banner.id}
                className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                  index === currentBannerIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
                }`}
              >
                {/* Background Image with Gradient Overlay */}
                <img
                  src={banner.imageUrl}
                  alt={banner.title}
                  className="w-full h-full object-cover object-center brightness-60"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/90 via-emerald-950/60 to-transparent" />

                {/* Banner Content */}
                <div className="absolute inset-0 max-w-7xl mx-auto px-6 sm:px-10 flex flex-col justify-center items-start text-white">
                  {banner.eyebrow && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-[10px] sm:text-xs font-bold uppercase tracking-widest mb-2 sm:mb-3">
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      {banner.eyebrow}
                    </span>
                  )}
                  <h1 className="text-xl sm:text-3xl md:text-5xl font-extrabold tracking-tight max-w-2xl text-balance leading-tight">
                    {banner.title}
                  </h1>
                  <p className="text-xs sm:text-base text-gray-200 mt-2 sm:mt-3 max-w-xl line-clamp-2 sm:line-clamp-none font-medium">
                    {banner.subtitle}
                  </p>
                  <div className="mt-4 sm:mt-6 flex flex-wrap gap-3">
                    <Link
                      to={banner.buttonLink || '/search'}
                      className="px-5 py-2.5 sm:px-6 sm:py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-emerald-950 font-bold text-xs sm:text-sm shadow-lg hover:shadow-xl transition flex items-center gap-2 group"
                    >
                      <span>{banner.buttonText || 'Shop Collection'}</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
                    </Link>
                    <a
                      href={`https://wa.me/917003735250?text=${encodeURIComponent('Assalamualaikum, I am interested in your products.')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="hidden sm:inline-flex px-4 py-3 rounded-xl bg-emerald-900/80 hover:bg-emerald-900 text-white font-semibold text-sm border border-emerald-700/60 transition items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-400" />
                      <span>WhatsApp Support</span>
                    </a>
                  </div>
                </div>
              </div>
            ))}

            {/* Slider Navigation Arrows */}
            {banners.length > 1 && (
              <>
                <button
                  onClick={() => setCurrentBannerIndex((prev) => (prev - 1 + banners.length) % banners.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition backdrop-blur-xs cursor-pointer"
                  title="Previous"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setCurrentBannerIndex((prev) => (prev + 1) % banners.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition backdrop-blur-xs cursor-pointer"
                  title="Next"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                {/* Slider Dots */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex gap-2">
                  {banners.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentBannerIndex(i)}
                      className={`h-1.5 rounded-full transition-all cursor-pointer ${
                        i === currentBannerIndex ? 'w-6 bg-amber-400' : 'w-2 bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        </section>
      )}

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-12 sm:space-y-16">
        
        {/* Interactive Category Hub & Navigation */}
        <section className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-widest block mb-1">
                AUTHENTIC ISLAMIC ESSENTIALS
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight flex items-center gap-2">
                <span>{selectedCategory === 'all' ? t('allProducts') : currentCategory?.name || 'Category'}</span>
                <span className="text-xs font-bold text-emerald-900 bg-amber-400/20 px-2.5 py-0.5 rounded-full border border-amber-400/40">
                  {filteredProducts.length} Products
                </span>
              </h2>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              {selectedCategory !== 'all' ? (
                <button
                  onClick={() => handleSelectCategory('all')}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 px-3.5 py-1.5 rounded-xl border border-emerald-200 transition cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>← {t('allProducts')}</span>
                </button>
              ) : (
                <Link
                  to="/search"
                  className="text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 group"
                >
                  <span>Browse Full Catalog</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
                </Link>
              )}
            </div>
          </div>

          {/* Professional Category Tabs Strip */}
          <div className="bg-white rounded-2xl p-2 sm:p-2.5 border border-emerald-900/10 shadow-xs">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
              {/* Primary 'All Products' Button (Default) */}
              <button
                onClick={() => handleSelectCategory('all')}
                className={`flex items-center gap-1.5 sm:gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition shrink-0 cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-gradient-to-r from-emerald-900 via-emerald-950 to-emerald-900 text-amber-300 shadow-md border border-amber-400/40'
                    : 'bg-emerald-50/60 hover:bg-emerald-100/70 text-emerald-950 border border-emerald-900/10'
                }`}
              >
                <Sparkles className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${selectedCategory === 'all' ? 'text-amber-300' : 'text-amber-600'}`} />
                <span>{t('allProducts')}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  selectedCategory === 'all' ? 'bg-amber-400/20 text-amber-200' : 'bg-emerald-900/10 text-emerald-800'
                }`}>
                  {products.length}
                </span>
              </button>

              {/* Individual Category Filter Tabs */}
              {categories.map((cat) => {
                const isSelected = selectedCategory === cat.id;
                const catCount = products.filter((p) => p.categoryId === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleSelectCategory(cat.id)}
                    className={`flex items-center gap-1.5 sm:gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition shrink-0 cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-emerald-900 via-emerald-950 to-emerald-900 text-amber-300 shadow-md border border-amber-400/40 font-bold'
                        : 'bg-white hover:bg-emerald-50 text-gray-700 hover:text-emerald-900 border border-gray-200 hover:border-emerald-300'
                    }`}
                  >
                    {cat.imageUrl && (
                      <img src={cat.imageUrl} alt="" className="w-4 h-4 rounded-full object-cover shrink-0" />
                    )}
                    <span>{cat.name}</span>
                    {catCount > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        isSelected ? 'bg-amber-400/20 text-amber-200' : 'bg-gray-100 text-gray-500'
                      }`}>
                        {catCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Conditional Product Display */}
          {selectedCategory !== 'all' ? (
            /* Category Filtered View */
            <div className="space-y-6 pt-2">
              <div className="bg-gradient-to-r from-emerald-950 to-emerald-900 text-white rounded-2xl p-5 sm:p-7 shadow-md border border-amber-400/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest block mb-1">
                    CATEGORY SHOWCASE
                  </span>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-white">
                    {currentCategory?.name}
                  </h3>
                  <p className="text-xs text-emerald-200 mt-1 max-w-xl">
                    Explore our curated collection of authentic, 100% genuine {currentCategory?.name.toLowerCase()}.
                  </p>
                </div>
                <button
                  onClick={() => handleSelectCategory('all')}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold rounded-xl text-xs transition cursor-pointer self-start sm:self-auto shrink-0"
                >
                  ← Return to All Products
                </button>
              </div>

              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onQuickView={setQuickViewProduct}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-2xl p-12 text-center border border-gray-100 shadow-xs">
                  <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-800 mx-auto flex items-center justify-center mb-3">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-gray-900 mb-1">No products found in this category</h4>
                  <p className="text-xs text-gray-500 mb-4">We are restocking authentic items soon.</p>
                  <button
                    onClick={() => handleSelectCategory('all')}
                    className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-semibold hover:bg-emerald-900 transition cursor-pointer"
                  >
                    View All Products
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Default All Products View - Shows All Products directly */
            <div className="pt-1">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onQuickView={setQuickViewProduct}
                  />
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Featured Attars Section */}
        <section className="bg-gradient-to-br from-emerald-900/5 via-emerald-900/10 to-amber-500/5 rounded-3xl p-5 sm:p-8 border border-emerald-900/10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-800 text-amber-300 text-[10px] font-bold uppercase tracking-wider mb-1.5">
                <Sparkles className="w-3 h-3" />
                100% NON-ALCOHOLIC
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
                Pure Attars & Dehn Al Oudh
              </h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1">
                Authentic, long-lasting concentrated perfume oils formulated for daily prayers and Friday Jumuah.
              </p>
            </div>
            <Link
              to="/category/cat-attars"
              className="text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 shrink-0"
            >
              <span>Explore All Attars</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5">
            {featuredAttars.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setQuickViewProduct}
              />
            ))}
          </div>
        </section>

        {/* Best Sellers Section */}
        <section>
          <div className="flex items-end justify-between mb-6">
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-widest block mb-1">
                CUSTOMER FAVORITES
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
                {t('bestSellers')}
              </h2>
            </div>
            <Link
              to="/search?sort=popularity"
              className="text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 group"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5">
            {bestSellers.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setQuickViewProduct}
              />
            ))}
          </div>
        </section>

        {/* Janamaz & Prayer Essentials Section */}
        <section>
          <div className="flex items-end justify-between mb-6">
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-widest block mb-1">
                DAILY SALAH COMPANIONS
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
                Janamaz & Handcrafted Tasbeeh
              </h2>
            </div>
            <Link
              to="/category/cat-janamaz"
              className="text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 group"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5">
            {prayerEssentials.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setQuickViewProduct}
              />
            ))}
          </div>
        </section>

        {/* WhatsApp Direct Order & Assistance Callout */}
        <section className="bg-gradient-to-r from-emerald-950 to-emerald-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-xl border border-amber-400/20">
          <div className="relative z-10 max-w-2xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-800 text-amber-300 text-xs font-bold uppercase tracking-wider mb-3">
              <MessageCircle className="w-3.5 h-3.5" />
              DIRECT SHOP OWNER SUPPORT
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Order via WhatsApp or Online with Easy Confirmation
            </h3>
            <p className="text-xs sm:text-sm text-emerald-200 mt-2 leading-relaxed">
              Prefer speaking with the shop owner directly? We assist you with fragrance selections, prayer rug thickness advice, bulk gift packages, and fast order dispatches.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href={`https://wa.me/917003735250?text=${encodeURIComponent('Assalamualaikum, I would like assistance with an order from Noor Al Huda.')}`}
                target="_blank"
                rel="noreferrer"
                className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm shadow-lg transition flex items-center gap-2 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Chat on WhatsApp (+91 7003735250)</span>
              </a>
              <Link
                to="/support#faqs"
                className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition"
              >
                Read Common FAQs
              </Link>
            </div>
          </div>
          <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 text-emerald-800/40 font-serif text-[180px] select-none pointer-events-none">
            نور
          </div>
        </section>

      </main>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />

    </div>
  );
};
