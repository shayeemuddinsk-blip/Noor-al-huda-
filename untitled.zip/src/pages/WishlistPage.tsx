import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ShoppingBag, ArrowRight, Sparkles } from 'lucide-react';
import { useWishlist } from '../contexts/WishlistContext';
import { useCart } from '../contexts/CartContext';
import { useLanguage } from '../contexts/LanguageContext';

export const WishlistPage: React.FC = () => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { t } = useLanguage();

  if (wishlist.length === 0) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] py-16 flex items-center justify-center px-4">
        <div className="bg-white rounded-3xl p-8 sm:p-12 text-center max-w-md w-full border border-gray-200/80 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 mx-auto flex items-center justify-center mb-4 border border-amber-100">
            <Heart className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Your wishlist is empty</h2>
          <p className="text-xs text-gray-500 mb-6 leading-relaxed">
            Explore authentic pure attars, luxury janamaz, and Islamic essentials to save your favorite picks.
          </p>
          <Link
            to="/search"
            className="inline-flex items-center justify-center gap-2 w-full py-3 px-6 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl shadow-md transition"
          >
            <span>Browse Products</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
              {t('wishlist')} ({wishlist.length} {wishlist.length === 1 ? 'item' : 'items'})
            </h1>
            <p className="text-xs text-gray-500 mt-0.5">
              Items saved for future blessing and gifting.
            </p>
          </div>
          <button
            onClick={clearWishlist}
            className="text-xs text-gray-400 hover:text-red-600 transition font-medium cursor-pointer"
          >
            Clear Wishlist
          </button>
        </div>

        {/* Wishlist Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {wishlist.map((product) => {
            const isOutOfStock = product.stock <= 0;

            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl border border-gray-200/80 p-3.5 shadow-xs flex flex-col justify-between overflow-hidden relative group"
              >
                {/* Delete Shortcut */}
                <button
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-white/90 text-gray-400 hover:text-red-500 transition shadow-xs cursor-pointer"
                  title="Remove from wishlist"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>

                <div>
                  <Link to={`/product/${product.id}`} className="block aspect-square rounded-xl overflow-hidden bg-gray-50 mb-3 border border-gray-100">
                    <img
                      src={product.images[0]}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                  </Link>

                  <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block mb-1">
                    {product.categoryName || 'Islamic Goods'}
                  </span>
                  <Link to={`/product/${product.id}`}>
                    <h3 className="text-xs sm:text-sm font-bold text-gray-900 group-hover:text-emerald-800 transition line-clamp-2">
                      {product.title}
                    </h3>
                  </Link>
                </div>

                <div className="mt-4 pt-3 border-t border-gray-100">
                  <div className="flex items-baseline gap-1.5 mb-2.5">
                    <span className="text-sm sm:text-base font-extrabold text-gray-900">
                      ₹{product.price}
                    </span>
                    {product.originalPrice && product.originalPrice > product.price && (
                      <span className="text-xs text-gray-400 line-through">
                        ₹{product.originalPrice}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => {
                      if (!isOutOfStock) {
                        addToCart(product, product.variants?.[0], 1);
                        removeFromWishlist(product.id);
                      }
                    }}
                    disabled={isOutOfStock}
                    className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      isOutOfStock
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : 'bg-emerald-800 hover:bg-emerald-900 text-white shadow-xs'
                    }`}
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>{isOutOfStock ? 'Out of Stock' : 'Move to Cart'}</span>
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
