import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, Mail, MapPin, ChevronDown, 
  ChevronUp, ShieldCheck, Truck, RefreshCw, Send, Check, Phone 
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { api } from '../services/api';
import { StoreSettings } from '../types';

export const SupportPage: React.FC = () => {
  const { t } = useLanguage();
  const [settings, setSettings] = useState<StoreSettings | null>(null);

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
  }, []);

  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [formSent, setFormSent] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const waNum = settings?.whatsappNumber || '+91 7003735250';
  const supEmail = settings?.supportEmail || settings?.ownerEmail || 'uskshayeem@gmail.com';
  const cleanPhone = waNum.replace(/[^0-9]/g, '') || '917003735250';

  const faqs = [
    {
      q: 'How do I confirm my order on WhatsApp?',
      a: `After you place an order on the website, a unique Order ID (e.g. NAH-ORD-2026-1002) is generated and a green "Confirm Order on WhatsApp" button will appear. Clicking it opens our official business WhatsApp (${waNum}) with prefilled details. The owner will confirm dispatch and payment instructions.`
    },
    {
      q: 'Are your attars 100% alcohol-free and Halal?',
      a: 'Yes, absolutely. All Noor Al Huda perfumes and attars are 100% alcohol-free concentrated perfume oils distilled with traditional techniques. They are completely pure and permissible for daily Salah and Friday prayers.'
    },
    {
      q: 'What are the delivery charges and delivery times?',
      a: 'We offer standard delivery at ₹40 across India. Orders of ₹999 or above automatically unlock FREE Delivery! Delivery typically takes 3 to 5 business days depending on your PIN code.'
    },
    {
      q: 'Can I pay via Cash on Delivery (COD) or UPI?',
      a: 'Yes. We support Cash on Delivery, WhatsApp-assisted confirmation, and direct UPI payments (Google Pay, PhonePe, Paytm). You can scan our official UPI QR code or pay to 7003735250@upi.'
    },
    {
      q: 'What is your return and cancellation policy?',
      a: `You can cancel any order prior to dispatch free of charge. We offer a 7-day return policy for unused, sealed items in original packaging. Contact us on WhatsApp (${waNum}) with your Order ID for hassle-free assistance.`
    }
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSent(true);
    setName('');
    setEmail('');
    setMessage('');
    setTimeout(() => setFormSent(false), 4000);
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-8 sm:py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-10">
        
        {/* Header */}
        <div className="text-center max-w-xl mx-auto">
          <span className="text-xs font-bold text-amber-700 uppercase tracking-widest block mb-1">
            WE ARE HERE TO HELP
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-emerald-950 tracking-tight">
            Customer Support & Policies
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-2">
            Have questions about our authentic attars, prayer essentials, or your order status? Reach out to us directly.
          </p>
        </div>

        {/* WhatsApp & Email Quick Contacts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-2xl border border-emerald-900/10 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-3">
                <MessageCircle className="w-5 h-5 fill-emerald-100" />
              </div>
              <h3 className="text-sm font-bold text-gray-900">Direct WhatsApp Assistance</h3>
              <p className="text-xs text-gray-500 mt-1">
                Chat directly with the store owner for instant order confirmation, notes recommendation, and tracking updates.
              </p>
              <p className="text-xs font-bold text-emerald-800 mt-2">
                {waNum}
              </p>
            </div>
            <a
              href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent('Assalamualaikum, I need assistance regarding Noor Al Huda products.')}`}
              target="_blank"
              rel="noreferrer"
              className="mt-4 w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Open WhatsApp Chat</span>
            </a>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-emerald-900/10 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-3">
                <Mail className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-gray-900">Official Email Support</h3>
              <p className="text-xs text-gray-500 mt-1">
                For formal enquiries, bulk institutional orders, or business partnerships, email the store owner directly.
              </p>
              <p className="text-xs font-bold text-gray-800 mt-2">
                {supEmail}
              </p>
            </div>
            <a
              href={`mailto:${supEmail}?subject=Noor%20Al%20Huda%20Store%20Enquiry`}
              className="mt-4 w-full py-2.5 px-4 bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Mail className="w-4 h-4" />
              <span>Send an Email</span>
            </a>
          </div>
        </div>

        {/* FAQs Accordion */}
        <section id="faqs" className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200/80 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-800" />
            Frequently Asked Questions (FAQ)
          </h2>

          <div className="space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-gray-100 overflow-hidden transition"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : index)}
                    className="w-full p-4 text-left flex items-center justify-between gap-3 bg-gray-50/50 hover:bg-gray-50 transition cursor-pointer"
                  >
                    <span className="text-xs sm:text-sm font-bold text-gray-900">{faq.q}</span>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-emerald-800 shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />}
                  </button>
                  {isOpen && (
                    <div className="p-4 bg-white text-xs text-gray-600 leading-relaxed border-t border-gray-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Policies Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div id="shipping" className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-2.5">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
              <Truck className="w-4 h-4 text-emerald-800" />
              <span>Shipping Policy</span>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">
              We ship across all pin codes in India through trusted courier partners. Standard shipping is ₹40, and orders above ₹999 qualify for Free Delivery. Orders are carefully packaged in sealed boxes and bubble wrap.
            </p>
          </div>

          <div id="returns" className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-2.5">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
              <RefreshCw className="w-4 h-4 text-emerald-800" />
              <span>Return & Refund Policy</span>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">
              Customer satisfaction is our highest priority. If an item arrives damaged or incorrect, contact us on WhatsApp within 7 days. Refunds are handled transparently via UPI or original payment method upon safe return inspection.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
