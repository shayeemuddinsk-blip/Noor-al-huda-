import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Star, ShoppingBag, Heart, ShieldCheck, Truck, RefreshCw, 
  MessageCircle, Share2, MapPin, Check, ChevronRight, ChevronLeft, 
  Sparkles, AlertCircle, Maximize2, X 
} from 'lucide-react';
import { api } from '../services/api';
import { Product, ProductVariant, StoreSettings } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { useLanguage } from '../contexts/LanguageContext';
import { ProductCard } from '../components/common/ProductCard';

export const ProductDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { t } = useLanguage();

  const [product, setProduct] = useState<Product | null>(null);
  const [similarProducts, setSimilarProducts] = useState<Product[]>([]);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(undefined);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [pincode, setPincode] = useState('700073');
  const [pincodeChecked, setPincodeChecked] = useState(true);
  const [added, setAdded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [shareCopied, setShareCopied] = useState(false);

  const touchStartXRef = useRef<number | null>(null);

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
  }, []);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    api.getProductById(id).then((prod) => {
      setProduct(prod);
      setActiveImageIndex(0);
      setSelectedVariant(prod.variants?.[0]);
      setQuantity(1);
      setLoading(false);

      // Fetch similar products in same category
      api.getProducts({ category: prod.categoryId }).then((prods) => {
        setSimilarProducts(prods.filter((p) => p.id !== prod.id).slice(0, 4));
      });
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-emerald-800 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs text-gray-500 font-medium">Loading product details...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] flex items-center justify-center p-6">
        <div className="bg-white p-8 rounded-2xl text-center max-w-sm border border-gray-200">
          <h2 className="text-base font-bold text-gray-900 mb-2">Product Not Found</h2>
          <p className="text-xs text-gray-500 mb-4">This item might be unavailable or removed.</p>
          <Link to="/" className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold">
            Return to Store
          </Link>
        </div>
      </div>
    );
  }

  const currentPrice = selectedVariant ? selectedVariant.price : product.price;
  const currentOriginalPrice = selectedVariant ? selectedVariant.originalPrice : product.originalPrice;
  const currentStock = selectedVariant ? selectedVariant.stock : product.stock;
  const isWishlisted = isInWishlist(product.id);
  const isOutOfStock = currentStock <= 0;

  const discountPercent = currentOriginalPrice && currentOriginalPrice > currentPrice
    ? Math.round(((currentOriginalPrice - currentPrice) / currentOriginalPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addToCart(product, selectedVariant, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  const handleBuyNow = () => {
    if (isOutOfStock) return;
    addToCart(product, selectedVariant, quantity);
    navigate('/checkout');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.title,
        text: `Check out ${product.title} on Noor Al Huda Islamic Shop!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-1.5 text-xs text-gray-500 mb-6 flex-wrap">
          <Link to="/" className="hover:text-emerald-800 transition">{t('home')}</Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
          <Link to={`/category/${product.categoryId}`} className="hover:text-emerald-800 transition">
            {product.categoryName || 'Islamic Goods'}
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
          <span className="text-gray-900 font-bold truncate max-w-xs">{product.title}</span>
        </nav>

        {/* Main Product Layout */}
        <div className="bg-white rounded-3xl p-5 sm:p-8 border border-gray-200/80 shadow-xs mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Responsive Touch-Swipe Gallery & Lightbox Preview (col 5) */}
            <div className="lg:col-span-5 space-y-4">
              {(() => {
                const productImages = product.images && product.images.length > 0 
                  ? product.images 
                  : ['https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=800&auto=format&fit=crop&q=80'];
                const currentImage = productImages[activeImageIndex] || productImages[0];

                const handlePrevImage = () => {
                  setActiveImageIndex((prev) => (prev - 1 + productImages.length) % productImages.length);
                };

                const handleNextImage = () => {
                  setActiveImageIndex((prev) => (prev + 1) % productImages.length);
                };

                const handleTouchStart = (e: React.TouchEvent) => {
                  touchStartXRef.current = e.touches[0].clientX;
                };

                const handleTouchEnd = (e: React.TouchEvent) => {
                  if (touchStartXRef.current === null) return;
                  const diff = touchStartXRef.current - e.changedTouches[0].clientX;
                  touchStartXRef.current = null;
                  if (diff > 40) {
                    handleNextImage(); // Swiped left -> next photo
                  } else if (diff < -40) {
                    handlePrevImage(); // Swiped right -> prev photo
                  }
                };

                const waPhone = (settings?.whatsappNumber || '+91 7003735250').replace(/[^0-9]/g, '') || '917003735250';

                return (
                  <>
                    {/* Main Image Frame - Full natural aspect ratio without distortion or cropping */}
                    <div 
                      onTouchStart={handleTouchStart}
                      onTouchEnd={handleTouchEnd}
                      className="relative w-full h-80 sm:h-96 md:h-[460px] bg-gradient-to-b from-[#fcfbf9] to-[#f4f1ea]/30 rounded-3xl overflow-hidden border border-gray-200/90 flex items-center justify-center p-3 sm:p-5 select-none shadow-xs group"
                    >
                      <img
                        src={currentImage}
                        alt={product.title}
                        onClick={() => setLightboxOpen(true)}
                        className="max-h-full max-w-full w-auto h-auto object-contain drop-shadow-sm transition-transform duration-300 group-hover:scale-[1.02] cursor-zoom-in"
                      />

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 flex flex-col gap-1 items-start z-10 pointer-events-none">
                        {discountPercent > 0 && (
                          <span className="px-2.5 py-1 bg-amber-500 text-emerald-950 font-extrabold text-xs rounded-lg shadow-md">
                            {discountPercent}% {t('off')}
                          </span>
                        )}
                      </div>

                      {/* Top Right Counter & Zoom Button */}
                      <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10">
                        {productImages.length > 1 && (
                          <span className="px-2.5 py-1 bg-emerald-950/75 backdrop-blur-md text-white font-mono font-bold text-[11px] rounded-lg shadow-xs">
                            {activeImageIndex + 1} / {productImages.length}
                          </span>
                        )}
                        <button
                          onClick={() => setLightboxOpen(true)}
                          title="View Full-Size Photo"
                          className="p-1.5 bg-white/95 hover:bg-white text-gray-700 hover:text-emerald-900 rounded-lg shadow-sm border border-gray-200 backdrop-blur-xs transition cursor-pointer"
                        >
                          <Maximize2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Next / Prev Floating Arrow Controls */}
                      {productImages.length > 1 && (
                        <>
                          <button
                            onClick={handlePrevImage}
                            aria-label="Previous photo"
                            className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white/95 hover:bg-white text-emerald-950 shadow-md border border-gray-200 flex items-center justify-center transition opacity-90 sm:opacity-0 group-hover:opacity-100 cursor-pointer hover:scale-105 z-10"
                          >
                            <ChevronLeft className="w-5 h-5 text-emerald-950" />
                          </button>

                          <button
                            onClick={handleNextImage}
                            aria-label="Next photo"
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white/95 hover:bg-white text-emerald-950 shadow-md border border-gray-200 flex items-center justify-center transition opacity-90 sm:opacity-0 group-hover:opacity-100 cursor-pointer hover:scale-105 z-10"
                          >
                            <ChevronRight className="w-5 h-5 text-emerald-950" />
                          </button>

                          {/* Swipe Hint on Mobile */}
                          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 sm:hidden px-2.5 py-0.5 bg-black/50 backdrop-blur-xs text-white rounded-full text-[10px] font-medium pointer-events-none">
                            Swipe ‹ › to view photos
                          </div>
                        </>
                      )}
                    </div>

                    {/* Thumbnail Rail */}
                    {productImages.length > 1 && (
                      <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-thin">
                        {productImages.map((img, i) => (
                          <button
                            key={i}
                            onClick={() => setActiveImageIndex(i)}
                            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 transition shrink-0 cursor-pointer bg-white p-1 flex items-center justify-center shadow-xs ${
                              activeImageIndex === i ? 'border-emerald-800 ring-2 ring-emerald-800/20' : 'border-gray-200 opacity-60 hover:opacity-100'
                            }`}
                          >
                            <img src={img} alt="" className="w-full h-full object-contain" />
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Share & WhatsApp Enquiry Bar */}
                    <div className="pt-3 border-t border-gray-100 flex items-center justify-between gap-3 text-xs">
                      <button
                        onClick={handleShare}
                        className="flex items-center gap-1.5 text-gray-600 hover:text-emerald-800 transition cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>{shareCopied ? 'Link Copied!' : t('share')}</span>
                      </button>

                      <a
                        href={`https://wa.me/${waPhone}?text=${encodeURIComponent(`Assalamualaikum, I am inquiring about product: ${product.title} (₹${currentPrice})`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1.5 text-emerald-800 font-bold hover:underline"
                      >
                        <MessageCircle className="w-4 h-4 fill-emerald-100 text-emerald-700" />
                        <span>{t('enquireWhatsApp')}</span>
                      </a>
                    </div>

                    {/* Fullscreen Lightbox Modal */}
                    {lightboxOpen && (
                      <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4">
                        <button
                          onClick={() => setLightboxOpen(false)}
                          aria-label="Close Lightbox"
                          className="absolute top-4 right-4 p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-full transition cursor-pointer"
                        >
                          <X className="w-6 h-6" />
                        </button>

                        <div className="relative max-w-4xl max-h-[85vh] w-full flex items-center justify-center">
                          <img
                            src={currentImage}
                            alt={product.title}
                            className="max-h-[80vh] max-w-full object-contain rounded-xl drop-shadow-2xl"
                          />

                          {productImages.length > 1 && (
                            <>
                              <button
                                onClick={handlePrevImage}
                                aria-label="Previous image"
                                className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 p-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition cursor-pointer hover:scale-105"
                              >
                                <ChevronLeft className="w-6 h-6" />
                              </button>
                              <button
                                onClick={handleNextImage}
                                aria-label="Next image"
                                className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 p-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition cursor-pointer hover:scale-105"
                              >
                                <ChevronRight className="w-6 h-6" />
                              </button>
                            </>
                          )}
                        </div>

                        <div className="text-white text-xs mt-3 font-mono">
                          {activeImageIndex + 1} of {productImages.length}
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}
            </div>

            {/* Right: Info, Price, Variants, Delivery & Actions (col 7) */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
              
              <div>
                {/* Brand & SKU */}
                <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-emerald-800 uppercase tracking-wider">
                      {product.brand || 'Noor Al Huda'}
                    </span>
                    {product.sellerName && (
                      <span className="text-[11px] bg-blue-50 text-blue-800 px-2 py-0.5 rounded font-medium border border-blue-200">
                        Seller: {product.sellerName}
                      </span>
                    )}
                  </div>
                  <span className="font-mono">SKU: {selectedVariant ? selectedVariant.sku : product.sku}</span>
                </div>

                <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-gray-900 leading-tight">
                  {product.title}
                </h1>

                {/* Rating & Verified reviews */}
                <div className="flex items-center gap-2 mt-2.5">
                  <div className="flex items-center gap-1 px-2.5 py-0.5 bg-emerald-800 text-white rounded-md text-xs font-bold">
                    <span>{product.rating.toFixed(1)}</span>
                    <Star className="w-3 h-3 fill-white" />
                  </div>
                  <span className="text-xs text-gray-500 font-medium">
                    {product.reviewCount} Verified Customer Ratings
                  </span>
                  <span className="text-gray-300">•</span>
                  <span className="text-xs font-semibold text-emerald-800 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    100% Halal Assured
                  </span>
                </div>

                {/* Pricing Box */}
                <div className="mt-4 p-4 rounded-2xl bg-emerald-50/50 border border-emerald-900/10 flex items-baseline gap-3">
                  <span className="text-3xl font-extrabold text-gray-900">
                    ₹{currentPrice}
                  </span>
                  {currentOriginalPrice && currentOriginalPrice > currentPrice && (
                    <span className="text-base text-gray-400 line-through">
                      ₹{currentOriginalPrice}
                    </span>
                  )}
                  {discountPercent > 0 && (
                    <span className="text-xs font-extrabold text-amber-600 bg-amber-100 px-2 py-0.5 rounded">
                      Save ₹{currentOriginalPrice! - currentPrice} ({discountPercent}% OFF)
                    </span>
                  )}
                </div>

                {/* Variants Selection */}
                {product.variants && product.variants.length > 0 && (
                  <div className="mt-5">
                    <label className="block text-xs font-bold text-gray-800 uppercase tracking-wider mb-2">
                      Select Variant / Size / Volume:
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {product.variants.map((v) => (
                        <button
                          key={v.id}
                          onClick={() => setSelectedVariant(v)}
                          className={`px-4 py-2 rounded-xl text-xs font-semibold border-2 transition cursor-pointer flex items-center gap-2 ${
                            selectedVariant?.id === v.id
                              ? 'border-emerald-800 bg-emerald-50 text-emerald-950 font-bold shadow-xs'
                              : 'border-gray-200 text-gray-700 hover:border-gray-300'
                          }`}
                        >
                          <span>{v.name}</span>
                          <span className="text-emerald-800 font-bold">₹{v.price}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity & Stock Check */}
                <div className="mt-5 flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gray-700">Qty:</span>
                    <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden bg-white">
                      <button
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        disabled={quantity <= 1 || isOutOfStock}
                        className="px-3 py-1.5 hover:bg-gray-100 text-gray-700 font-bold transition disabled:opacity-30 cursor-pointer"
                      >
                        -
                      </button>
                      <span className="px-3 py-1.5 text-xs font-bold text-gray-900 min-w-8 text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((q) => Math.min(currentStock, q + 1))}
                        disabled={quantity >= currentStock || isOutOfStock}
                        className="px-3 py-1.5 hover:bg-gray-100 text-gray-700 font-bold transition disabled:opacity-30 cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Stock label */}
                  <div>
                    {isOutOfStock ? (
                      <span className="text-xs font-bold text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" />
                        Currently Out of Stock
                      </span>
                    ) : currentStock <= product.lowStockThreshold ? (
                      <span className="text-xs font-bold text-orange-600 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" />
                        Hurry, only {currentStock} units left in stock!
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                        <Check className="w-4 h-4" />
                        In Stock ({currentStock} available)
                      </span>
                    )}
                  </div>
                </div>

                {/* Delivery Pin Code Check */}
                <div className="mt-6 p-4 rounded-2xl bg-gray-50 border border-gray-200/80">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-emerald-800" />
                      Delivery Check & Speed
                    </span>
                    <span className="text-[11px] text-emerald-700 font-semibold">
                      {currentPrice >= 999 ? 'Eligible for FREE Delivery' : 'Standard Delivery ₹40'}
                    </span>
                  </div>

                  <div className="flex gap-2 max-w-sm">
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="Enter 6-digit Indian PIN code"
                      className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                    />
                    <button
                      onClick={() => setPincodeChecked(true)}
                      className="px-3 py-1.5 bg-emerald-800 text-white rounded-lg text-xs font-semibold hover:bg-emerald-900 transition"
                    >
                      Check
                    </button>
                  </div>

                  {pincodeChecked && (
                    <p className="text-[11px] text-gray-600 mt-2">
                      Delivering to PIN <strong>{pincode}</strong> within 3–5 business days. Safe doorstep delivery with live tracking updates.
                    </p>
                  )}
                </div>

              </div>

              {/* Action Buttons: Add to Cart & Buy Now */}
              <div className="pt-6 border-t border-gray-100 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className={`flex-1 py-3 px-6 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition shadow-md cursor-pointer ${
                    isOutOfStock
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : added
                      ? 'bg-emerald-700 text-white'
                      : 'bg-emerald-800 hover:bg-emerald-900 text-white'
                  }`}
                >
                  {added ? <Check className="w-5 h-5" /> : <ShoppingBag className="w-5 h-5" />}
                  <span>{added ? 'Added to Cart' : t('addToCart')}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  disabled={isOutOfStock}
                  className="flex-1 py-3 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-emerald-950 text-sm font-extrabold flex items-center justify-center transition shadow-md cursor-pointer disabled:opacity-40"
                >
                  {t('buyNow')}
                </button>

                <button
                  onClick={() => toggleWishlist(product)}
                  className={`p-3 rounded-xl border border-gray-300 flex items-center justify-center transition cursor-pointer ${
                    isWishlisted ? 'text-red-500 bg-red-50 border-red-200' : 'text-gray-400 hover:text-red-500'
                  }`}
                  title="Save to Wishlist"
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-red-500' : ''}`} />
                </button>
              </div>

            </div>

          </div>

          {/* Description & Specifications Tabs */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-3">Product Description</h3>
            <p className="text-sm text-gray-600 leading-relaxed mb-6">
              {product.description}
            </p>

            {product.specifications && Object.keys(product.specifications).length > 0 && (
              <div className="mb-8">
                <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">
                  Specifications & Details
                </h4>
                <div className="max-w-xl border border-gray-200 rounded-xl overflow-hidden text-xs">
                  {Object.entries(product.specifications).map(([key, val], idx) => (
                    <div
                      key={key}
                      className={`grid grid-cols-2 p-3 ${idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}`}
                    >
                      <span className="font-semibold text-gray-700">{key}</span>
                      <span className="text-gray-900">{val}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Similar / Related Products */}
        {similarProducts.length > 0 && (
          <section className="mt-12">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Similar Products You May Like</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {similarProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}

      </div>
    </div>
  );
};
