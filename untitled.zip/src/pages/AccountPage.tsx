import React, { useState } from 'react';
import { 
  User, Mail, Phone, Globe, Package, Heart, 
  MapPin, LogOut, Settings, ShieldCheck, Check, Sparkles 
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageCode } from '../types';

export const AccountPage: React.FC = () => {
  const { currentUser, isAuthenticated, isAdmin, isOwner, logout, updateProfile } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.displayName || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({ displayName: name, phone });
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const languages: { code: LanguageCode; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'bn', label: 'Bengali', native: 'বাংলা' },
    { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
    { code: 'ur', label: 'Urdu', native: 'اردو' },
  ];

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        
        {/* Title */}
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
            {t('account')} Center
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Manage your personal profile, addresses, language settings, and view past purchases.
          </p>
        </div>

        {savedSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>Profile details updated successfully!</span>
          </div>
        )}

        {/* Profile Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200/80 shadow-xs">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-gray-100 pb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-amber-300 font-extrabold text-2xl flex items-center justify-center border border-amber-400/30 shadow-md">
                {currentUser?.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'U'}
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-gray-900">
                  {currentUser?.displayName || 'My Account'}
                </h2>
                <p className="text-xs text-gray-500">{currentUser?.email || 'Registered User'}</p>
                {isAdmin && (
                  <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                    {isOwner ? 'Store Owner' : 'Administrator'}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isAdmin ? (
                <Link
                  to="/admin"
                  className="px-4 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-950 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                >
                  <Settings className="w-4 h-4 text-amber-400" />
                  <span>Admin Dashboard</span>
                </Link>
              ) : (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-4 py-2 rounded-xl border border-gray-300 hover:border-emerald-700 text-gray-700 text-xs font-semibold transition cursor-pointer"
                >
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                </button>
              )}
            </div>
          </div>

          {/* Edit form */}
          {isEditing ? (
            <form onSubmit={handleSaveProfile} className="pt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Display Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">WhatsApp Phone</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 Phone Number"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div className="sm:col-span-2 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 text-white rounded-lg text-xs font-bold hover:bg-emerald-900 transition"
                >
                  Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div className="pt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Email</span>
                <span className="font-semibold text-gray-800 truncate block mt-0.5">{currentUser?.email || 'Not provided'}</span>
              </div>
              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Phone</span>
                <span className="font-semibold text-gray-800 block mt-0.5">{currentUser?.phone || 'Not added'}</span>
              </div>
              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Member Since</span>
                <span className="font-semibold text-gray-800 block mt-0.5">2026</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick Nav Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link
            to="/orders"
            className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs hover:border-emerald-700/50 transition flex items-center gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center group-hover:scale-105 transition">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900">{t('myOrders')}</h3>
              <p className="text-[11px] text-gray-400">Track shipments & invoices</p>
            </div>
          </Link>

          <Link
            to="/wishlist"
            className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs hover:border-emerald-700/50 transition flex items-center gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-105 transition">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900">{t('wishlist')}</h3>
              <p className="text-[11px] text-gray-400">View saved products</p>
            </div>
          </Link>

          <Link
            to="/support"
            className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs hover:border-emerald-700/50 transition flex items-center gap-3.5 group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center group-hover:scale-105 transition">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900">{t('customerSupport')}</h3>
              <p className="text-[11px] text-gray-400">WhatsApp & FAQ policies</p>
            </div>
          </Link>
        </div>

        {/* Language Selection Setting */}
        <div className="bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
            <Globe className="w-4 h-4 text-emerald-800" />
            Language & Regional Localization
          </h3>
          <p className="text-xs text-gray-500">
            Select your preferred display language. All storefront navigation, checkout steps, and status text will adapt instantly.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
            {languages.map((l) => (
              <button
                key={l.code}
                onClick={() => setLanguage(l.code)}
                className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                  language === l.code
                    ? 'border-emerald-800 bg-emerald-50 text-emerald-950 font-bold shadow-xs'
                    : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span className="text-sm block">{l.native}</span>
                <span className="text-[10px] text-gray-400">{l.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sign Out Card */}
        <div className="bg-white rounded-2xl p-5 border border-gray-200/80 shadow-xs flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-gray-900">Sign Out of Account</h4>
            <p className="text-[11px] text-gray-400">Safely log out of this browser session.</p>
          </div>
          <button
            onClick={() => {
              logout();
              navigate('/');
            }}
            className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{t('signOut')}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
