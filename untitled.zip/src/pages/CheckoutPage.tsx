import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  ShieldCheck, MapPin, Truck, CreditCard, MessageCircle, 
  Check, ArrowRight, ArrowLeft, AlertCircle, Sparkles, QrCode 
} from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { api, OrderCreationPayload } from '../services/api';

export const CheckoutPage: React.FC = () => {
  const { items, subtotal, discountAmount, deliveryCharge, totalAmount, coupon, clearCart } = useCart();
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  // Address form fields
  const [fullName, setFullName] = useState(currentUser?.displayName || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [houseFlat, setHouseFlat] = useState('');
  const [street, setStreet] = useState('');
  const [locality, setLocality] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pinCode, setPinCode] = useState('700073');
  const [landmark, setLandmark] = useState('');
  const [addressType, setAddressType] = useState<'home' | 'work' | 'other'>('home');

  // Payment method
  const [paymentMethod, setPaymentMethod] = useState<'whatsapp_assisted' | 'cash_on_delivery' | 'upi_manual'>('whatsapp_assisted');
  const [orderNotes, setOrderNotes] = useState('');

  // Status & processing
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] py-16 flex items-center justify-center px-4">
        <div className="bg-white rounded-3xl p-8 text-center max-w-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-4">Your cart is empty. Add items to checkout.</p>
          <Link to="/" className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold">
            Return to Store
          </Link>
        </div>
      </div>
    );
  }

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!fullName.trim()) return setErrorMessage('Please enter recipient full name.');
    if (!phone.trim() || phone.length < 10) return setErrorMessage('Please enter a valid 10-digit mobile number.');
    if (!houseFlat.trim() || !street.trim()) return setErrorMessage('Please provide complete house/flat and street address.');
    if (!city.trim() || !state.trim()) return setErrorMessage('Please select city and state.');
    if (!pinCode.trim() || pinCode.length !== 6) return setErrorMessage('Please enter a valid 6-digit Indian PIN code.');

    setIsSubmitting(true);

    try {
      const payload: OrderCreationPayload = {
        customerName: fullName.trim(),
        customerEmail: email.trim(),
        customerPhone: phone.trim(),
        shippingAddress: {
          fullName: fullName.trim(),
          phone: phone.trim(),
          houseFlat: houseFlat.trim(),
          street: street.trim(),
          locality: locality.trim(),
          city: city.trim(),
          state: state.trim(),
          pinCode: pinCode.trim(),
          landmark: landmark.trim(),
          addressType,
        },
        items: items.map((it) => ({
          productId: it.productId,
          variantId: it.variantId,
          quantity: it.quantity,
        })),
        couponCode: coupon?.code,
        paymentMethod,
        notes: orderNotes.trim() || undefined,
      };

      const result = await api.createOrder(payload);
      clearCart();

      // Automatically sync order and order items directly to the user's Google Spreadsheet
      try {
        const { syncOrderToGoogleSheet } = await import('../services/googleWorkspace');
        syncOrderToGoogleSheet(result.order).catch((sErr) => console.warn('[Google Sheets] Order sync notice:', sErr));
      } catch (e) {
        console.warn('Could not trigger immediate Google Sheets sync:', e);
      }

      // Navigate to confirmation page passing the created order and prefilled WhatsApp URL
      navigate(`/order-confirmation/${result.order.id}`, {
        state: { order: result.order, whatsappUrl: result.whatsappUrl }
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to place order. Please review your cart.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header Breadcrumb */}
        <div className="mb-6">
          <Link to="/cart" className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-emerald-800 transition mb-2">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Shopping Cart</span>
          </Link>
          <h1 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
            Checkout & Order Confirmation
          </h1>
          <p className="text-xs text-gray-500">
            Safe order placement with verified WhatsApp confirmation directly with the store owner.
          </p>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Form: Delivery Address & Payment Method (col 7) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* 1. Delivery Address Card */}
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
                <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-bold">
                  1
                </div>
                <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider">
                  {t('deliveryAddress')}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Recipient's Name"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Mobile Number (WhatsApp) *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 9876543210"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="order-updates@example.com"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Flat / House No. / Building *</label>
                  <input
                    type="text"
                    required
                    value={houseFlat}
                    onChange={(e) => setHouseFlat(e.target.value)}
                    placeholder="e.g. Flat 402, Al-Barkah Apts"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Street / Colony / Area *</label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    placeholder="e.g. Zakaria Street, Near Nakhoda Mosque"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Locality</label>
                  <input
                    type="text"
                    value={locality}
                    onChange={(e) => setLocality(e.target.value)}
                    placeholder="e.g. Barabazar"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Nearby Landmark</label>
                  <input
                    type="text"
                    value={landmark}
                    onChange={(e) => setLandmark(e.target.value)}
                    placeholder="e.g. Opposite Royal Hotel"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Kolkata"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">State *</label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="e.g. West Bengal"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">PIN Code (6 Digits) *</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="e.g. 700073"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Address Type</label>
                  <div className="flex gap-2">
                    {(['home', 'work', 'other'] as const).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setAddressType(type)}
                        className={`flex-1 py-1.5 text-xs font-semibold capitalize rounded-lg border transition cursor-pointer ${
                          addressType === type
                            ? 'bg-emerald-800 text-white border-emerald-800'
                            : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

              </div>
            </div>

            {/* 2. Payment Method Card */}
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
                <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-bold">
                  2
                </div>
                <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider">
                  {t('paymentMethod')}
                </h3>
              </div>

              <div className="space-y-3">
                
                {/* Method 1: WhatsApp Assisted Payment (Recommended) */}
                <label className={`block p-4 rounded-xl border-2 transition cursor-pointer ${
                  paymentMethod === 'whatsapp_assisted'
                    ? 'border-emerald-800 bg-emerald-50/40 shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="whatsapp_assisted"
                      checked={paymentMethod === 'whatsapp_assisted'}
                      onChange={() => setPaymentMethod('whatsapp_assisted')}
                      className="mt-1 text-emerald-800 focus:ring-emerald-700"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-emerald-950">
                          {t('whatsappAssistedPayment')}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-amber-500 text-emerald-950 font-bold text-[9px] uppercase">
                          Recommended
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-600 mt-1">
                        {t('whatsappAssistedDesc')}
                      </p>
                      <div className="mt-2 text-[10px] text-emerald-800 flex items-center gap-1 font-semibold">
                        <MessageCircle className="w-3.5 h-3.5" />
                        Official WhatsApp Business: +91 7003735250
                      </div>
                    </div>
                  </div>
                </label>

                {/* Method 2: Cash on Delivery */}
                <label className={`block p-4 rounded-xl border-2 transition cursor-pointer ${
                  paymentMethod === 'cash_on_delivery'
                    ? 'border-emerald-800 bg-emerald-50/40 shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cash_on_delivery"
                      checked={paymentMethod === 'cash_on_delivery'}
                      onChange={() => setPaymentMethod('cash_on_delivery')}
                      className="mt-1 text-emerald-800 focus:ring-emerald-700"
                    />
                    <div>
                      <span className="text-xs font-bold text-gray-900 block">
                        {t('cashOnDelivery')}
                      </span>
                      <p className="text-[11px] text-gray-600 mt-1">
                        {t('cashOnDeliveryDesc')}
                      </p>
                    </div>
                  </div>
                </label>

                {/* Method 3: Direct UPI */}
                <label className={`block p-4 rounded-xl border-2 transition cursor-pointer ${
                  paymentMethod === 'upi_manual'
                    ? 'border-emerald-800 bg-emerald-50/40 shadow-xs'
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="upi_manual"
                      checked={paymentMethod === 'upi_manual'}
                      onChange={() => setPaymentMethod('upi_manual')}
                      className="mt-1 text-emerald-800 focus:ring-emerald-700"
                    />
                    <div>
                      <span className="text-xs font-bold text-gray-900 block">
                        {t('upiPayment')} (GPay, PhonePe, Paytm)
                      </span>
                      <p className="text-[11px] text-gray-600 mt-1">
                        Pay to UPI ID: <strong className="text-emerald-800">7003735250@upi</strong> and share transaction reference on WhatsApp.
                      </p>
                    </div>
                  </div>
                </label>

              </div>

              {/* Order Notes */}
              <div className="pt-2">
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Special Instructions or Gift Notes (Optional)
                </label>
                <textarea
                  rows={2}
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="e.g. Please pack in velvet gift pouch, or call before delivery"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-700 outline-none"
                />
              </div>

            </div>

          </div>

          {/* Right Summary Card (col 5) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-gray-900 border-b border-gray-100 pb-3 uppercase tracking-wider">
                {t('orderSummary')} ({items.length} items)
              </h3>

              {/* Item Mini Snapshots */}
              <div className="max-h-56 overflow-y-auto space-y-2.5 pr-1 divide-y divide-gray-50">
                {items.map((it) => (
                  <div key={`${it.productId}-${it.variantId || 'b'}`} className="pt-2 first:pt-0 flex items-center justify-between text-xs gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img src={it.image} alt="" className="w-9 h-9 object-cover rounded-md border border-gray-100 shrink-0" />
                      <div className="truncate">
                        <p className="font-semibold text-gray-900 truncate">{it.title}</p>
                        <p className="text-[10px] text-gray-400">
                          {it.variantName ? `${it.variantName} • ` : ''}Qty: {it.quantity}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-gray-900 shrink-0">
                      ₹{it.price * it.quantity}
                    </span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="border-t border-gray-100 pt-3 space-y-2 text-xs">
                <div className="flex justify-between text-gray-600">
                  <span>{t('subtotal')}</span>
                  <span className="font-semibold text-gray-900">₹{subtotal}</span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>{t('discount')} ({coupon?.code})</span>
                    <span>-₹{discountAmount}</span>
                  </div>
                )}

                <div className="flex justify-between text-gray-600">
                  <span>{t('deliveryCharge')}</span>
                  <span>
                    {deliveryCharge === 0 ? (
                      <span className="font-bold text-emerald-700">{t('freeDelivery')}</span>
                    ) : (
                      <span className="font-semibold text-gray-900">₹{deliveryCharge}</span>
                    )}
                  </span>
                </div>

                <div className="border-t border-gray-100 pt-3 flex justify-between items-baseline">
                  <div>
                    <span className="text-sm font-bold text-gray-900 block">{t('totalPayable')}</span>
                    <span className="text-[10px] text-gray-400">Verified server pricing</span>
                  </div>
                  <span className="text-2xl font-extrabold text-emerald-950">
                    ₹{totalAmount}
                  </span>
                </div>
              </div>

              {/* Place Order CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white font-extrabold text-sm shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-4"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>{t('placingOrder')}</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5 text-amber-300" />
                    <span>{t('confirmOrder')}</span>
                  </>
                )}
              </button>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 leading-snug">
                <p className="font-bold mb-0.5">Order Assurance:</p>
                After placing the order, you will receive a 1-click WhatsApp confirmation link with prefilled details to share with the owner for expedited processing.
              </div>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
