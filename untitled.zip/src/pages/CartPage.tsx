import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Trash2, ShoppingBag, ArrowRight, Sparkles, 
  ShieldCheck, AlertCircle, Tag, Check, ArrowLeft 
} from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useLanguage } from '../contexts/LanguageContext';

export const CartPage: React.FC = () => {
  const { 
    items, itemCount, subtotal, discountAmount, deliveryCharge, 
    freeDeliveryThreshold, freeDeliveryEligible, amountNeededForFreeDelivery, 
    totalAmount, coupon, couponError, updateQuantity, removeFromCart, 
    applyCoupon, removeCoupon, clearCart 
  } = useCart();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const [couponInput, setCouponInput] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setCouponLoading(true);
    await applyCoupon(couponInput.trim());
    setCouponLoading(false);
  };

  const freeDeliveryPercentage = Math.min(100, Math.round((subtotal / freeDeliveryThreshold) * 100));

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] py-12 sm:py-20 flex items-center justify-center px-4">
        <div className="bg-white rounded-3xl p-8 sm:p-12 text-center max-w-md w-full border border-gray-200/80 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-800 mx-auto flex items-center justify-center mb-4 border border-emerald-100">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">{t('cartEmpty')}</h2>
          <p className="text-xs text-gray-500 mb-6 leading-relaxed">
            {t('cartEmptyPrompt')}
          </p>
          <Link
            to="/search"
            className="inline-flex items-center justify-center gap-2 w-full py-3 px-6 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl shadow-md transition"
          >
            <span>{t('continueShopping')}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Title & Clear Action */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
              {t('shoppingCart')} ({itemCount} {itemCount === 1 ? 'item' : 'items'})
            </h1>
            <p className="text-xs text-gray-500 mt-0.5">
              Review your items before proceeding to safe delivery checkout.
            </p>
          </div>
          <button
            onClick={clearCart}
            className="text-xs text-gray-400 hover:text-red-600 transition font-medium cursor-pointer"
          >
            Clear Cart
          </button>
        </div>

        {/* Free Delivery Countdown Progress Bar */}
        <div className="bg-white p-4 rounded-2xl border border-emerald-900/10 shadow-xs mb-6">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="flex items-center gap-1.5 text-emerald-900">
              <Sparkles className="w-4 h-4 text-amber-500" />
              {freeDeliveryEligible ? (
                <strong className="text-emerald-700">Congratulations! You unlocked FREE Delivery!</strong>
              ) : (
                <span>
                  {t('freeDeliveryUnlock', { amount: amountNeededForFreeDelivery })}
                </span>
              )}
            </span>
            <span className="text-gray-400 font-mono text-[11px]">
              ₹{subtotal} / ₹{freeDeliveryThreshold}
            </span>
          </div>

          <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-600 to-amber-500 rounded-full transition-all duration-500"
              style={{ width: `${freeDeliveryPercentage}%` }}
            />
          </div>
        </div>

        {/* Main Cart Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Cart Items List (col 8) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs divide-y divide-gray-100 overflow-hidden">
              {items.map((item) => (
                <div key={`${item.productId}-${item.variantId || 'base'}`} className="p-4 sm:p-5 flex gap-4 sm:gap-5 items-start">
                  
                  {/* Thumbnail */}
                  <Link to={`/product/${item.productId}`} className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-gray-50 border border-gray-100 shrink-0">
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                  </Link>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <Link to={`/product/${item.productId}`}>
                        <h3 className="text-xs sm:text-sm font-bold text-gray-900 hover:text-emerald-800 transition line-clamp-2">
                          {item.title}
                        </h3>
                      </Link>
                      <button
                        onClick={() => removeFromCart(item.productId, item.variantId)}
                        className="text-gray-400 hover:text-red-500 p-1 transition cursor-pointer"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {item.variantName && (
                      <span className="inline-block mt-1 px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px] font-semibold">
                        Option: {item.variantName}
                      </span>
                    )}

                    <div className="mt-3 flex items-center justify-between flex-wrap gap-2">
                      {/* Price */}
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-sm sm:text-base font-extrabold text-gray-900">
                          ₹{item.price * item.quantity}
                        </span>
                        {item.quantity > 1 && (
                          <span className="text-[11px] text-gray-400">
                            (₹{item.price} each)
                          </span>
                        )}
                      </div>

                      {/* Quantity Controller */}
                      <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden bg-white">
                        <button
                          onClick={() => updateQuantity(item.productId, item.variantId, item.quantity - 1)}
                          className="px-2.5 py-1 text-gray-600 hover:bg-gray-100 text-xs font-bold transition cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-3 py-1 text-xs font-bold text-gray-900 min-w-8 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.variantId, item.quantity + 1)}
                          disabled={item.quantity >= item.maxStock}
                          className="px-2.5 py-1 text-gray-600 hover:bg-gray-100 text-xs font-bold transition disabled:opacity-30 cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-2">
              <Link
                to="/search"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800 hover:underline"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{t('continueShopping')}</span>
              </Link>
            </div>
          </div>

          {/* Right: Order Summary & Coupon (col 4) */}
          <div className="lg:col-span-4 space-y-4">
            
            {/* Coupon Box */}
            <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
              <label className="block text-xs font-bold text-gray-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-emerald-800" />
                Have a Promo / Coupon Code?
              </label>

              {coupon ? (
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-emerald-900 block">{coupon.code} Applied</span>
                    <span className="text-[11px] text-emerald-700">
                      You saved ₹{discountAmount}!
                    </span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-xs text-red-600 hover:underline font-semibold cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                      placeholder="e.g. WELCOME10 or NOOR100"
                      className="flex-1 px-3 py-2 text-xs border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-mono uppercase"
                    />
                    <button
                      type="submit"
                      disabled={couponLoading || !couponInput.trim()}
                      className="px-4 py-2 bg-emerald-800 text-white text-xs font-semibold rounded-xl hover:bg-emerald-900 transition disabled:opacity-50 cursor-pointer"
                    >
                      {couponLoading ? 'Checking...' : t('applyCoupon')}
                    </button>
                  </div>
                  {couponError && (
                    <p className="text-[11px] text-red-600 font-medium">{couponError}</p>
                  )}
                  <p className="text-[10px] text-gray-400">
                    Use code <strong className="text-emerald-700">WELCOME10</strong> (10% off &gt; ₹499) or <strong className="text-emerald-700">NOOR100</strong> (₹100 off &gt; ₹999).
                  </p>
                </form>
              )}
            </div>

            {/* Price Summary Breakdown */}
            <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs space-y-3.5">
              <h3 className="text-sm font-bold text-gray-900 border-b border-gray-100 pb-3 uppercase tracking-wider">
                {t('orderSummary')}
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-gray-600">
                  <span>{t('subtotal')}</span>
                  <span className="font-semibold text-gray-900">₹{subtotal}</span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>{t('discount')} ({coupon?.code})</span>
                    <span>-₹{discountAmount}</span>
                  </div>
                )}

                <div className="flex justify-between text-gray-600">
                  <span>{t('deliveryCharge')}</span>
                  <span>
                    {deliveryCharge === 0 ? (
                      <span className="font-bold text-emerald-700">{t('freeDelivery')}</span>
                    ) : (
                      <span className="font-semibold text-gray-900">₹{deliveryCharge}</span>
                    )}
                  </span>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-3 flex justify-between items-baseline">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">{t('totalPayable')}</span>
                  <span className="text-[10px] text-gray-400">Inclusive of all taxes</span>
                </div>
                <span className="text-xl font-extrabold text-emerald-900">
                  ₹{totalAmount}
                </span>
              </div>

              <button
                onClick={() => navigate('/checkout')}
                className="w-full py-3 px-6 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs shadow-md hover:shadow-lg transition flex items-center justify-center gap-2 cursor-pointer mt-4"
              >
                <span>{t('proceedToCheckout')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 flex items-center justify-center gap-2 text-[11px] text-gray-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>Safe & Encrypted Checkout</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
