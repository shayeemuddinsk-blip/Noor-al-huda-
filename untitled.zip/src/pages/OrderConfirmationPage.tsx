import React, { useEffect } from 'react';
import { useLocation, useParams, Link } from 'react-router-dom';
import { 
  CheckCircle, MessageCircle, Package, ArrowRight, 
  MapPin, Clock, ShieldCheck, Sparkles, PhoneCall 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useLanguage } from '../contexts/LanguageContext';
import { Order } from '../types';

export const OrderConfirmationPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const { t } = useLanguage();

  const stateOrder = location.state?.order as Order | undefined;
  const whatsappUrl = location.state?.whatsappUrl as string | undefined;

  useEffect(() => {
    // Fire celebratory confetti on mount
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#047857', '#d97706', '#10b981', '#f59e0b'],
      });
    } catch (e) {
      // safe fallback
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const orderId = id || stateOrder?.id || 'NAH-ORD-2026-PENDING';

  // Fallback official wa.me link if not passed from state
  const finalWhatsAppUrl = whatsappUrl || `https://wa.me/917003735250?text=${encodeURIComponent(`Assalamualaikum, I am confirming my order #${orderId} from Noor Al Huda Islamic Shop.`)}`;

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-10 sm:py-16 px-4">
      <div className="max-w-2xl mx-auto space-y-6">
        
        {/* Celebration Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 text-center border border-emerald-900/10 shadow-lg relative overflow-hidden">
          
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 mx-auto flex items-center justify-center mb-4 border border-emerald-200 shadow-inner">
            <CheckCircle className="w-10 h-10" />
          </div>

          <span className="inline-block px-3 py-1 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-200 text-xs font-bold uppercase tracking-wider mb-2">
            Alhamdulillah!
          </span>

          <h1 className="text-xl sm:text-3xl font-extrabold text-emerald-950 tracking-tight">
            {t('orderConfirmedTitle')}
          </h1>

          <p className="text-xs sm:text-sm text-gray-600 mt-2 max-w-lg mx-auto leading-relaxed">
            {t('orderConfirmedSub')}
          </p>

          <div className="mt-5 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-50 border border-gray-200 text-xs sm:text-sm font-mono font-bold text-gray-900">
            <span className="text-gray-400 font-sans text-xs">{t('orderIdLabel')}:</span>
            <span className="text-emerald-800">{orderId}</span>
          </div>

          {/* Primary Action: Confirm on WhatsApp */}
          <div className="mt-8 pt-6 border-t border-gray-100">
            <a
              href={finalWhatsAppUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2.5 w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-extrabold text-sm sm:text-base shadow-xl hover:shadow-2xl transition transform hover:-translate-y-0.5 cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>{t('confirmViaWhatsAppBtn')}</span>
            </a>
            <p className="text-[11px] text-gray-500 mt-2 font-medium">
              {t('confirmViaWhatsAppSub')}
            </p>
          </div>

        </div>

        {/* Order Details Summary Card (if available from state) */}
        {stateOrder && (
          <div className="bg-white rounded-2xl p-6 border border-gray-200/80 shadow-xs space-y-4 text-xs">
            <h3 className="text-sm font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center justify-between">
              <span>Order Summary</span>
              <span className="text-emerald-800 font-extrabold text-base">₹{stateOrder.totalAmount}</span>
            </h3>

            <div className="space-y-2 divide-y divide-gray-50">
              {stateOrder.items.map((it, idx) => (
                <div key={idx} className="pt-2 first:pt-0 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img src={it.image} alt="" className="w-8 h-8 rounded object-cover border border-gray-100" />
                    <div>
                      <p className="font-semibold text-gray-900">{it.productTitle}</p>
                      <p className="text-[10px] text-gray-400">
                        {it.variantName ? `${it.variantName} • ` : ''}Qty: {it.quantity}
                      </p>
                    </div>
                  </div>
                  <span className="font-bold text-gray-800">₹{it.lineTotal}</span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-gray-100 flex items-start gap-2 text-gray-600">
              <MapPin className="w-4 h-4 text-emerald-800 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-gray-900">Delivery Address:</p>
                <p>{stateOrder.shippingAddress.fullName}, {stateOrder.shippingAddress.houseFlat}, {stateOrder.shippingAddress.street}, {stateOrder.shippingAddress.city}, {stateOrder.shippingAddress.state} - {stateOrder.shippingAddress.pinCode}</p>
                <p className="text-gray-400">Phone: {stateOrder.shippingAddress.phone}</p>
              </div>
            </div>
          </div>
        )}

        {/* Action Shortcuts */}
        <div className="grid grid-cols-2 gap-3">
          <Link
            to="/orders"
            className="py-3 px-4 rounded-xl bg-white border border-gray-200 hover:border-emerald-800 text-gray-800 font-bold text-xs text-center shadow-xs transition"
          >
            {t('myOrders')}
          </Link>
          <Link
            to="/"
            className="py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs text-center shadow-xs transition"
          >
            {t('continueShopping')}
          </Link>
        </div>

      </div>
    </div>
  );
};
