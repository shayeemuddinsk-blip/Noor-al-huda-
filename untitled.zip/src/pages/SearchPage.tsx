import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, X, ArrowUpDown, Sparkles } from 'lucide-react';
import { api } from '../services/api';
import { Product, Category } from '../types';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';
import { useLanguage } from '../contexts/LanguageContext';

export const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { t } = useLanguage();

  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Filters state
  const queryParam = searchParams.get('q') || '';
  const categoryParam = searchParams.get('category') || '';
  const sortParam = searchParams.get('sort') || '';

  const [searchTerm, setSearchTerm] = useState(queryParam);
  const [selectedCategory, setSelectedCategory] = useState(categoryParam);
  const [sortBy, setSortBy] = useState(sortParam || 'newest');
  const [maxPrice, setMaxPrice] = useState<number>(3000);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  useEffect(() => {
    api.getCategories().then(setCategories).catch(console.error);
  }, []);

  useEffect(() => {
    setSearchTerm(queryParam);
    setSelectedCategory(categoryParam);
    setSortBy(sortParam || 'newest');
  }, [queryParam, categoryParam, sortParam]);

  useEffect(() => {
    setLoading(true);
    api.getProducts({
      search: searchTerm,
      category: selectedCategory || undefined,
      sort: sortBy,
      maxPrice: maxPrice,
      inStockOnly: inStockOnly,
    }).then((res) => {
      setProducts(res);
      setLoading(false);
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  }, [searchTerm, selectedCategory, sortBy, maxPrice, inStockOnly]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({
      q: searchTerm,
      category: selectedCategory,
      sort: sortBy,
    });
  };

  const handleCategoryClick = (catId: string) => {
    const next = selectedCategory === catId ? '' : catId;
    setSelectedCategory(next);
    setSearchParams({
      q: searchTerm,
      category: next,
      sort: sortBy,
    });
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('');
    setSortBy('newest');
    setMaxPrice(3000);
    setInStockOnly(false);
    setSearchParams({});
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Top Header & Search Bar */}
        <div className="mb-6">
          <form onSubmit={handleSearchSubmit} className="max-w-2xl flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search products, attars, janamaz, books..."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-700 outline-none shadow-xs"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs rounded-xl shadow-xs transition"
            >
              Search
            </button>
            <button
              type="button"
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              className="md:hidden px-3 py-2.5 bg-white border border-gray-300 rounded-xl text-gray-700 flex items-center gap-1.5 text-xs font-semibold"
            >
              <Filter className="w-4 h-4 text-emerald-800" />
              <span>Filters</span>
            </button>
          </form>

          {/* Active filters pill list */}
          {(searchTerm || selectedCategory || inStockOnly || maxPrice < 3000) && (
            <div className="flex flex-wrap items-center gap-2 mt-3 text-xs">
              <span className="text-gray-500 font-medium">Active filters:</span>
              {searchTerm && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-200">
                  Search: "{searchTerm}"
                  <button onClick={() => setSearchTerm('')}><X className="w-3 h-3" /></button>
                </span>
              )}
              {selectedCategory && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-200">
                  Category: {categories.find(c => c.id === selectedCategory)?.name || selectedCategory}
                  <button onClick={() => setSelectedCategory('')}><X className="w-3 h-3" /></button>
                </span>
              )}
              {inStockOnly && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-200">
                  In Stock Only
                  <button onClick={() => setInStockOnly(false)}><X className="w-3 h-3" /></button>
                </span>
              )}
              <button
                onClick={handleClearFilters}
                className="text-xs text-red-600 hover:underline font-semibold ml-2 cursor-pointer"
              >
                Clear All
              </button>
            </div>
          )}
        </div>

        {/* Content Layout */}
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Filter Sidebar */}
          <aside className={`w-full md:w-64 shrink-0 space-y-6 ${mobileFilterOpen ? 'block' : 'hidden md:block'}`}>
            <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs space-y-5">
              
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                  <Filter className="w-4 h-4 text-emerald-800" />
                  Filter Products
                </h3>
                <button
                  onClick={handleClearFilters}
                  className="text-[11px] text-emerald-800 font-semibold hover:underline cursor-pointer"
                >
                  Reset
                </button>
              </div>

              {/* Categories */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                  Category
                </label>
                <div className="space-y-1">
                  <button
                    onClick={() => handleCategoryClick('')}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      selectedCategory === '' ? 'bg-emerald-800 text-white font-bold' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    All Categories
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                        selectedCategory === cat.id ? 'bg-emerald-800 text-white font-bold' : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Filter */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                    Max Price
                  </label>
                  <span className="text-xs font-bold text-emerald-800">₹{maxPrice}</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="3000"
                  step="100"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(parseInt(e.target.value, 10))}
                  className="w-full accent-emerald-800 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                  <span>₹200</span>
                  <span>₹3,000+</span>
                </div>
              </div>

              {/* In Stock Toggle */}
              <div className="pt-2 border-t border-gray-100 flex items-center justify-between">
                <label htmlFor="stockOnly" className="text-xs font-medium text-gray-700 cursor-pointer">
                  In Stock Only
                </label>
                <input
                  type="checkbox"
                  id="stockOnly"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-800 focus:ring-emerald-700 border-gray-300 cursor-pointer"
                />
              </div>

            </div>
          </aside>

          {/* Right Product Grid Area */}
          <div className="flex-1">
            
            {/* Top Toolbar */}
            <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 mb-5 flex items-center justify-between gap-3 text-xs">
              <span className="text-gray-500 font-medium">
                Showing <strong className="text-gray-900">{products.length}</strong> products
              </span>

              {/* Sort By */}
              <div className="flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
                <span className="text-gray-500 hidden sm:inline">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-transparent border-none text-xs font-bold text-gray-800 focus:ring-0 cursor-pointer outline-none"
                >
                  <option value="newest">Newest Arrivals</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rating">Highest Customer Rating</option>
                </select>
              </div>
            </div>

            {/* Products Grid or Empty State */}
            {loading ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <div key={n} className="bg-white rounded-xl h-72 border border-gray-100 animate-pulse" />
                ))}
              </div>
            ) : products.length > 0 ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onQuickView={setQuickViewProduct}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-10 text-center border border-gray-200 max-w-lg mx-auto">
                <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-800 mx-auto flex items-center justify-center mb-3">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-gray-900 mb-1">
                  No products matched your criteria
                </h3>
                <p className="text-xs text-gray-500 mb-5">
                  Try adjusting your search terms, raising the maximum price, or clearing your category filters.
                </p>
                <button
                  onClick={handleClearFilters}
                  className="px-5 py-2.5 bg-emerald-800 text-white text-xs font-semibold rounded-xl hover:bg-emerald-900 transition"
                >
                  Reset All Filters
                </button>
              </div>
            )}

          </div>

        </div>

      </div>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />

    </div>
  );
};
