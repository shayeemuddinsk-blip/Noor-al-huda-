import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronRight, Sparkles, Filter, ArrowUpDown } from 'lucide-react';
import { api } from '../services/api';
import { Product, Category } from '../types';
import { ProductCard } from '../components/common/ProductCard';
import { QuickViewModal } from '../components/common/QuickViewModal';
import { useLanguage } from '../contexts/LanguageContext';

export const CategoryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();

  const [category, setCategory] = useState<Category | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('newest');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);

    Promise.all([
      api.getCategories(),
      api.getProducts({ category: id, sort: sortBy }),
    ]).then(([cats, prods]) => {
      const current = cats.find((c) => c.id === id);
      setCategory(current || null);
      setProducts(prods);
      setLoading(false);
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  }, [id, sortBy]);

  return (
    <div className="min-h-screen bg-[#fdfbf7] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-1.5 text-xs text-gray-500 mb-6">
          <Link to="/" className="hover:text-emerald-800 transition">{t('home')}</Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
          <Link to="/search" className="hover:text-emerald-800 transition">{t('categories')}</Link>
          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
          <span className="text-gray-900 font-bold">{category?.name || 'Category'}</span>
        </nav>

        {/* Category Header Banner */}
        {category && (
          <div className="relative rounded-3xl overflow-hidden bg-emerald-950 text-white mb-8 p-6 sm:p-10 shadow-lg border border-amber-400/20">
            <div className="relative z-10 max-w-xl">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-800 text-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                OFFICIAL DEPARTMENT
              </span>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
                {category.name}
              </h1>
              <p className="text-xs sm:text-sm text-emerald-100 mt-2 leading-relaxed">
                {category.description}
              </p>
            </div>
            <div className="hidden sm:block absolute right-0 top-0 bottom-0 w-1/3 opacity-30 pointer-events-none">
              <img src={category.imageUrl} alt="" className="w-full h-full object-cover" />
            </div>
          </div>
        )}

        {/* Toolbar */}
        <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 mb-6 flex items-center justify-between text-xs">
          <span className="text-gray-500 font-medium">
            Showing <strong className="text-gray-900">{products.length}</strong> items in this category
          </span>

          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-gray-500 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-gray-800 focus:ring-0 cursor-pointer outline-none"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating">Highest Customer Rating</option>
            </select>
          </div>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="bg-white rounded-xl h-72 border border-gray-100 animate-pulse" />
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 sm:gap-5">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setQuickViewProduct}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-12 text-center border border-gray-200">
            <h3 className="text-base font-bold text-gray-900 mb-2">No products currently listed in this category</h3>
            <p className="text-xs text-gray-500 mb-4">Check back soon or explore our other collections.</p>
            <Link to="/search" className="px-4 py-2 bg-emerald-800 text-white rounded-lg text-xs font-semibold">
              Browse All Products
            </Link>
          </div>
        )}

      </div>

      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />
    </div>
  );
};
