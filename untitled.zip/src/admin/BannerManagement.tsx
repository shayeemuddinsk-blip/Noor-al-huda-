import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Image as ImageIcon, X, Check, Eye } from 'lucide-react';
import { api } from '../services/api';
import { Banner } from '../types';

export const BannerManagement: React.FC = () => {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [eyebrow, setEyebrow] = useState('SPECIAL RAMADAN & JUMUAH OFFERS');
  const [imageUrl, setImageUrl] = useState('');
  const [buttonText, setButtonText] = useState('Explore Collection');
  const [buttonLink, setButtonLink] = useState('/search');
  const [sortOrder, setSortOrder] = useState<number>(1);
  const [isActive, setIsActive] = useState(true);

  const loadBanners = () => {
    api.getBanners().then(setBanners).catch(console.error);
  };

  useEffect(() => {
    loadBanners();
  }, []);

  const handleOpenAdd = () => {
    setEditingBanner(null);
    setTitle('Pure Alcohol-Free Attars & Oudh');
    setSubtitle('Experience long-lasting oriental fragrances formulated for daily prayer.');
    setEyebrow('SPECIAL ISLAMIC ESSENTIALS');
    setImageUrl('https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=1600&auto=format&fit=crop&q=80');
    setButtonText('Shop Now');
    setButtonLink('/search');
    setSortOrder((banners.length || 0) + 1);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (b: Banner) => {
    setEditingBanner(b);
    setTitle(b.title);
    setSubtitle(b.subtitle);
    setEyebrow(b.eyebrow || '');
    setImageUrl(b.imageUrl);
    setButtonText(b.buttonText);
    setButtonLink(b.buttonLink);
    setSortOrder(b.sortOrder);
    setIsActive(b.isActive);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !imageUrl.trim()) return;

    const payload: Partial<Banner> = {
      title: title.trim(),
      subtitle: subtitle.trim(),
      eyebrow: eyebrow.trim() || undefined,
      imageUrl: imageUrl.trim(),
      buttonText: buttonText.trim(),
      buttonLink: buttonLink.trim(),
      sortOrder: Number(sortOrder),
      isActive,
    };

    try {
      if (editingBanner) {
        await api.updateBanner(editingBanner.id, payload);
      } else {
        await api.createBanner(payload);
      }
      setIsModalOpen(false);
      loadBanners();
    } catch (err: any) {
      alert(err.message || 'Operation failed');
    }
  };

  const [bannerToDelete, setBannerToDelete] = useState<Banner | null>(null);
  const [deleting, setDeleting] = useState(false);

  const executeDeleteBanner = async () => {
    if (!bannerToDelete) return;
    setDeleting(true);
    try {
      await api.deleteBanner(bannerToDelete.id);
      setBannerToDelete(null);
      loadBanners();
    } catch (err: any) {
      alert(err.message || 'Failed to delete banner');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Homepage Hero Banners & Promotional Posters
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Configure the prominent slider banners featured on your customer homepage.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Banner</span>
        </button>
      </div>

      {/* Banners List */}
      <div className="space-y-4">
        {banners.map((banner) => (
          <div
            key={banner.id}
            className="bg-white rounded-2xl border border-gray-200/80 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-5"
          >
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-28 h-18 rounded-xl overflow-hidden bg-gray-100 shrink-0 border border-gray-200">
                <img src={banner.imageUrl} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="min-w-0">
                {banner.eyebrow && (
                  <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block">
                    {banner.eyebrow}
                  </span>
                )}
                <h3 className="text-sm font-bold text-gray-900 truncate">{banner.title}</h3>
                <p className="text-xs text-gray-500 truncate max-w-md">{banner.subtitle}</p>
                <div className="mt-1 flex items-center gap-2 text-[10px] text-gray-400 font-mono">
                  <span>Button: "{banner.buttonText}"</span>
                  <span>•</span>
                  <span>Route: {banner.buttonLink}</span>
                  <span>•</span>
                  <span>Sort #{banner.sortOrder}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                banner.isActive ? 'bg-emerald-50 text-emerald-800' : 'bg-gray-100 text-gray-500'
              }`}>
                {banner.isActive ? 'Active on Homepage' : 'Disabled'}
              </span>

              <button
                onClick={() => handleOpenEdit(banner)}
                className="p-1.5 rounded-lg bg-gray-100 hover:bg-emerald-800 hover:text-white transition text-gray-600"
                title="Edit Banner"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setBannerToDelete(banner)}
                className="p-1.5 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white transition text-red-600 cursor-pointer"
                title="Remove Banner"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-gray-100">
            <div className="flex justify-between items-center mb-5 border-b border-gray-100 pb-3">
              <h3 className="text-sm font-bold text-gray-900">
                {editingBanner ? 'Edit Promotional Banner' : 'Create Hero Banner'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Eyebrow Tag (Optional)</label>
                <input
                  type="text"
                  value={eyebrow}
                  onChange={(e) => setEyebrow(e.target.value)}
                  placeholder="e.g. 100% NON-ALCOHOLIC"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Banner Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Sacred Fragrances of the East"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Subtitle / Promo Offer</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="e.g. Free Delivery on orders above ₹999 across India"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Image URL (Google Drive / CDN) *</label>
                <input
                  type="url"
                  required
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">CTA Button Text</label>
                  <input
                    type="text"
                    value={buttonText}
                    onChange={(e) => setButtonText(e.target.value)}
                    placeholder="Shop Now"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Button Link</label>
                  <input
                    type="text"
                    value={buttonLink}
                    onChange={(e) => setButtonLink(e.target.value)}
                    placeholder="/search or /category/cat-attars"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-gray-700">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-800"
                  />
                  <span>Active & Shown on Homepage</span>
                </label>
              </div>

              <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-xl text-gray-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 text-white font-bold rounded-xl hover:bg-emerald-900 shadow-sm"
                >
                  Save Banner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {bannerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-gray-100 animate-scale-up">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-extrabold text-gray-900 mb-2">Delete Banner?</h3>
            <p className="text-xs text-gray-500 mb-5 leading-relaxed">
              Are you sure you want to remove <strong className="text-gray-900">"{bannerToDelete.title}"</strong> from the homepage slider? It will be removed immediately.
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setBannerToDelete(null)}
                disabled={deleting}
                className="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-50 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeDeleteBanner}
                disabled={deleting}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
              >
                {deleting ? 'Deleting...' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
