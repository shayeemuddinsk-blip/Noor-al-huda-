import React, { useState, useEffect } from 'react';
import { Plus, Tag, X, Check, Trash2 } from 'lucide-react';
import { api } from '../services/api';
import { Coupon } from '../types';

export const CouponManagement: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [discountValue, setDiscountValue] = useState<number>(10);
  const [minOrderValue, setMinOrderValue] = useState<number>(499);
  const [maxDiscount, setMaxDiscount] = useState<number>(200);

  const loadCoupons = () => {
    api.getCoupons().then(setCoupons).catch(console.error);
  };

  useEffect(() => {
    loadCoupons();
  }, []);

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    try {
      await api.createCoupon({
        code: code.trim().toUpperCase(),
        discountType,
        discountValue: Number(discountValue),
        minOrderValue: Number(minOrderValue),
        maxDiscount: discountType === 'percentage' ? Number(maxDiscount) : undefined,
        startDate: '2026-01-01',
        endDate: '2026-12-31',
        usageLimit: 1000,
        isActive: true,
      });
      setIsModalOpen(false);
      loadCoupons();
    } catch (err: any) {
      alert(err.message || 'Failed to create coupon');
    }
  };

  const handleDeleteCoupon = async (id: string, cCode: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete coupon "${cCode}"?`)) return;
    try {
      await api.deleteCoupon(id);
      loadCoupons();
    } catch (err: any) {
      alert(err.message || 'Failed to delete coupon');
    }
  };

  const handleToggleCouponStatus = async (c: Coupon) => {
    try {
      await api.updateCoupon(c.id, { isActive: !c.isActive });
      loadCoupons();
    } catch (err: any) {
      alert(err.message || 'Failed to update coupon status');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Promotional Coupons & Discount Codes
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Configure percentage or flat discounts with minimum spend conditions.
          </p>
        </div>

        <button
          onClick={() => {
            setCode(`EID${Math.floor(10 + Math.random() * 90)}`);
            setIsModalOpen(true);
          }}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Coupon Code</span>
        </button>
      </div>

      {/* Coupons Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map((c) => (
          <div
            key={c.id}
            className={`bg-white rounded-2xl p-5 border shadow-xs flex flex-col justify-between transition ${
              c.isActive ? 'border-gray-200/80' : 'border-gray-200 opacity-75 bg-gray-50/50'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="px-3 py-1 rounded-lg bg-emerald-50 text-emerald-900 font-mono font-bold text-sm border border-emerald-200">
                  {c.code}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  c.isActive ? 'text-emerald-800 bg-emerald-100/60' : 'text-gray-500 bg-gray-200'
                }`}>
                  {c.discountType === 'percentage' ? `${c.discountValue}% OFF` : `₹${c.discountValue} FLAT OFF`}
                </span>
              </div>

              <div className="space-y-1 text-xs text-gray-600 mt-3">
                <p>Min. Spend: <strong>₹{c.minOrderValue}</strong></p>
                {c.maxDiscount && <p>Max Discount Cap: <strong>₹{c.maxDiscount}</strong></p>}
                <p>Times Used: <strong>{c.timesUsed || 0} orders</strong></p>
              </div>
            </div>

            <div className="pt-3 border-t border-gray-100 mt-4 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => handleToggleCouponStatus(c)}
                className={`px-2 py-0.5 rounded-full font-bold text-[10px] transition cursor-pointer ${
                  c.isActive
                    ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                }`}
                title="Click to toggle active status"
              >
                {c.isActive ? '● Active' : '○ Inactive'}
              </button>
              
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-gray-400">Valid 2026</span>
                <button
                  type="button"
                  onClick={() => handleDeleteCoupon(c.id, c.code)}
                  className="p-1 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                  title="Delete Coupon"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-gray-100">
            <div className="flex justify-between items-center mb-4 border-b border-gray-100 pb-3">
              <h3 className="text-sm font-bold text-gray-900">Create New Promo Code</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Coupon Code *</label>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="e.g. WELCOME10"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none font-mono uppercase font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Discount Type</label>
                  <select
                    value={discountType}
                    onChange={(e) => setDiscountType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none bg-white"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount (₹)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">
                    Value {discountType === 'percentage' ? '(%)' : '(₹)'}
                  </label>
                  <input
                    type="number"
                    required
                    value={discountValue}
                    onChange={(e) => setDiscountValue(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Min Order Value (₹)</label>
                  <input
                    type="number"
                    value={minOrderValue}
                    onChange={(e) => setMinOrderValue(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none"
                  />
                </div>
                {discountType === 'percentage' && (
                  <div>
                    <label className="block font-bold text-gray-700 mb-1">Max Discount Cap (₹)</label>
                    <input
                      type="number"
                      value={maxDiscount}
                      onChange={(e) => setMaxDiscount(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none"
                    />
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-xl text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 text-white font-bold rounded-xl hover:bg-emerald-900 shadow-sm"
                >
                  Create Code
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
