import React, { useState, useEffect } from 'react';
import { 
  Settings, Check, MessageCircle, Mail, Phone, Bell, 
  Image, Upload, Trash2, MapPin, Store, Sparkles, AlertCircle 
} from 'lucide-react';
import { api } from '../services/api';
import { StoreSettings } from '../types';

export const WebsiteSettings: React.FC = () => {
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [storeName, setStoreName] = useState('NOOR AL HUDA ISLAMIC SHOP');
  const [tagline, setTagline] = useState('Authentic Sunnah Fragrances & Islamic Essentials');
  const [logoUrl, setLogoUrl] = useState('');
  const [aboutUsText, setAboutUsText] = useState('Dedicated to providing authentic, 100% alcohol-free traditional attars, orthopedic padded janamaz, handcrafted tasbeeh, and premium Islamic essentials across India.');
  const [ownerEmail, setOwnerEmail] = useState('uskshayeem@gmail.com');
  const [supportEmail, setSupportEmail] = useState('uskshayeem@gmail.com');
  const [whatsappNumber, setWhatsappNumber] = useState('+91 7003735250');
  const [supportPhone, setSupportPhone] = useState('+91 7003735250');
  const [storeAddress, setStoreAddress] = useState('Zakaria Street, Near Nakhoda Mosque, Kolkata, West Bengal - 700073');
  const [announcementText, setAnnouncementText] = useState('✨ Welcome to Noor Al Huda! 100% Pure Alcohol-Free Attars & Prayer Essentials. Free Delivery on orders above ₹999. WhatsApp: +91 7003735250');
  const [announcementActive, setAnnouncementActive] = useState(true);
  const [upiId, setUpiId] = useState('7003735250@upi');
  
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.getSettings().then((s) => {
      setSettings(s);
      setStoreName(s.storeName || 'NOOR AL HUDA ISLAMIC SHOP');
      setTagline(s.tagline || 'Authentic Sunnah Fragrances & Islamic Essentials');
      setLogoUrl(s.logoUrl || '');
      setAboutUsText(s.aboutUsText || 'Dedicated to providing authentic, 100% alcohol-free traditional attars, orthopedic padded janamaz, handcrafted tasbeeh, and premium Islamic essentials across India.');
      setOwnerEmail(s.ownerEmail || 'uskshayeem@gmail.com');
      setSupportEmail(s.supportEmail || s.ownerEmail || 'uskshayeem@gmail.com');
      setWhatsappNumber(s.whatsappNumber || '+91 7003735250');
      setSupportPhone(s.supportPhone || s.whatsappNumber || '+91 7003735250');
      setStoreAddress(s.storeAddress || 'Zakaria Street, Near Nakhoda Mosque, Kolkata, West Bengal - 700073');
      setAnnouncementText(s.announcementText || '');
      setAnnouncementActive(s.announcementActive ?? true);
      setUpiId(s.upiId || '7003735250@upi');
    }).catch(console.error);
  }, []);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);
    try {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: base64Data,
          fileName: `logo_${file.name}`,
        }),
      });

      const data = await res.json();
      if (data.url) {
        setLogoUrl(data.url);
        // Persist immediately to server storage
        const updated = await api.updateSettings({ logoUrl: data.url });
        setSettings(updated);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Logo upload error:', err);
      alert('Failed to upload logo image');
    } finally {
      setUploadingLogo(false);
      e.target.value = '';
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await api.updateSettings({
        storeName: storeName.trim(),
        tagline: tagline.trim(),
        logoUrl: logoUrl.trim(),
        aboutUsText: aboutUsText.trim(),
        ownerEmail: ownerEmail.trim(),
        supportEmail: supportEmail.trim(),
        whatsappNumber: whatsappNumber.trim(),
        supportPhone: supportPhone.trim(),
        storeAddress: storeAddress.trim(),
        announcementText: announcementText.trim(),
        announcementActive,
        upiId: upiId.trim(),
      });
      setSettings(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      alert('Failed to save settings: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
          <Store className="w-6 h-6 text-emerald-800" />
          Store Appearance & Contact Configuration
        </h1>
        <p className="text-xs text-gray-500 mt-0.5">
          Customize your store branding, official logo, about story, contact email, phone numbers, and address across the website.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs flex items-center gap-2.5 shadow-xs">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">Store settings and branding updated successfully! All changes are live on the storefront.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        
        {/* Section 1: Store Branding & Logo */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200/80 shadow-xs space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">1. Brand Identity & Official Logo</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Store / Brand Name *</label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                placeholder="e.g. NOOR AL HUDA ISLAMIC SHOP"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-bold text-gray-900"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Brand Tagline / Subtitle</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. Authentic Sunnah Fragrances & Islamic Essentials"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 text-gray-700"
              />
            </div>
          </div>

          {/* Logo Upload & Preview */}
          <div>
            <label className="block font-bold text-gray-700 mb-1.5">Official Store Logo</label>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
              {/* Logo Preview */}
              <div className="w-16 h-16 rounded-xl bg-white border border-gray-300 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                {logoUrl ? (
                  <img src={logoUrl} alt="Store Logo" className="w-full h-full object-contain p-1" />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-emerald-950 flex items-center justify-center text-amber-300 font-serif font-bold text-xl">
                    ن
                  </div>
                )}
              </div>

              {/* Upload Controls */}
              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <label className="px-3.5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingLogo ? 'Uploading...' : 'Upload Logo Image'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleLogoUpload}
                      disabled={uploadingLogo}
                    />
                  </label>

                  {logoUrl && (
                    <button
                      type="button"
                      onClick={() => setLogoUrl('')}
                      className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-semibold border border-red-200 flex items-center gap-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove Logo</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-gray-400 shrink-0">Or Image URL:</span>
                  <input
                    type="url"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="https://example.com/logo.png"
                    className="flex-1 px-2.5 py-1.5 text-[11px] border border-gray-300 rounded-lg bg-white outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: About Us & Brand Story */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
            <Store className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">2. About Us & Brand Story Section</h2>
          </div>
          <div>
            <label className="block font-bold text-gray-700 mb-1">About Noor Al Huda Description (Displayed in Footer & About section)</label>
            <textarea
              rows={3}
              value={aboutUsText}
              onChange={(e) => setAboutUsText(e.target.value)}
              placeholder="Describe your store history, authenticity pledge, and Islamic values..."
              className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 leading-relaxed text-xs text-gray-800"
            />
            <span className="text-[11px] text-gray-400 mt-1 block">
              This text is automatically presented in the footer and about cards across desktop and mobile.
            </span>
          </div>
        </div>

        {/* Section 3: Official Contact & Address Details */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200/80 shadow-xs space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
            <Phone className="w-4 h-4 text-amber-600" />
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">3. Contact Details & Dispatch Location</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-gray-400" />
                Customer Support Email *
              </label>
              <input
                type="email"
                required
                value={supportEmail}
                onChange={(e) => setSupportEmail(e.target.value)}
                placeholder="e.g. uskshayeem@gmail.com"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                Official WhatsApp Business Number *
              </label>
              <input
                type="text"
                required
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                placeholder="+91 7003735250"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-mono font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-gray-400" />
                Calling / Telephone Contact Number
              </label>
              <input
                type="text"
                value={supportPhone}
                onChange={(e) => setSupportPhone(e.target.value)}
                placeholder="+91 7003735250"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-amber-500" />
                Store Owner Administrative Email
              </label>
              <input
                type="email"
                value={ownerEmail}
                onChange={(e) => setOwnerEmail(e.target.value)}
                placeholder="uskshayeem@gmail.com"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-red-500" />
                Store / Warehouse Physical Dispatch Address
              </label>
              <input
                type="text"
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                placeholder="e.g. Zakaria Street, Near Nakhoda Mosque, Kolkata, West Bengal - 700073"
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Announcement Strip & UPI */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
            <Bell className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">4. Notice Strip & UPI Payments</h2>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-bold text-gray-700">Top Header Announcement Strip</label>
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-emerald-950">
                <input
                  type="checkbox"
                  checked={announcementActive}
                  onChange={(e) => setAnnouncementActive(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-800"
                />
                <span>Active on Homepage</span>
              </label>
            </div>

            <textarea
              rows={2}
              value={announcementText}
              onChange={(e) => setAnnouncementText(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 leading-relaxed text-xs"
            />
          </div>

          <div className="pt-3 border-t border-gray-100">
            <label className="block font-bold text-gray-700 mb-1">Official UPI ID for Manual UPI Orders</label>
            <input
              type="text"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              placeholder="7003735250@upi"
              className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl outline-none font-mono"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs rounded-2xl shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Check className="w-4 h-4" />
            <span>{saving ? 'Saving Settings...' : 'Save All Website Settings'}</span>
          </button>
        </div>

      </form>

    </div>
  );
};
