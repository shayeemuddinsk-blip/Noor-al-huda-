import React, { useState, useEffect } from 'react';
import { 
  Boxes, AlertTriangle, ArrowUpRight, ArrowDownRight, 
  Search, RefreshCw, Plus, Minus, Download, Check 
} from 'lucide-react';
import { api } from '../services/api';
import { Product } from '../types';

export const InventoryManagement: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const loadData = () => {
    setLoading(true);
    api.getProducts().then((res) => {
      setProducts(res);
      setLoading(false);
    }).catch(console.error);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAdjustStock = async (productId: string, adjustment: number) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;

    const newStock = Math.max(0, prod.stock + adjustment);
    try {
      await api.updateProduct(productId, { stock: newStock });
      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, stock: newStock } : p))
      );
      setSuccessMsg(`Updated stock for "${prod.title}" to ${newStock} units`);
      setTimeout(() => setSuccessMsg(null), 2500);
    } catch (err: any) {
      alert('Failed to update stock: ' + err.message);
    }
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Title', 'SKU', 'Category', 'Price', 'Stock', 'LowStockThreshold'];
    const rows = products.map((p) => [
      p.id,
      `"${p.title.replace(/"/g, '""')}"`,
      p.sku,
      `"${p.categoryName || ''}"`,
      p.price,
      p.stock,
      p.lowStockThreshold || 10,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `noor_al_huda_inventory_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const lowStockItems = products.filter((p) => p.stock > 0 && p.stock <= (p.lowStockThreshold || 10));
  const outOfStockItems = products.filter((p) => p.stock <= 0);

  const filteredProducts = products.filter((p) => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Inventory & Stock Control
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Concurrency-safe stock adjustments, threshold alerts, and CSV exports for Google Sheets.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-4 py-2 bg-white border border-gray-200 text-gray-700 hover:text-emerald-800 text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <Download className="w-4 h-4 text-emerald-800" />
          <span>Export Inventory CSV</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Critical Stock Alerts Bar */}
      {(lowStockItems.length > 0 || outOfStockItems.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-amber-900">
                Low Stock Threshold Alerts ({lowStockItems.length})
              </h4>
              <p className="text-[11px] text-amber-800 mt-0.5">
                {lowStockItems.map((p) => `${p.title} (${p.stock} left)`).join(', ') || 'No low stock items.'}
              </p>
            </div>
          </div>

          <div className="p-4 bg-red-50 rounded-2xl border border-red-200 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-red-900">
                Out of Stock Items ({outOfStockItems.length})
              </h4>
              <p className="text-[11px] text-red-800 mt-0.5">
                {outOfStockItems.map((p) => p.title).join(', ') || 'All products in stock!'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs">
        <div className="relative">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by title or SKU to adjust stock..."
            className="w-full pl-10 pr-4 py-2 text-xs border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-400 uppercase font-semibold text-[10px] tracking-wider border-b border-gray-100">
              <tr>
                <th className="px-5 py-3.5">Product & SKU</th>
                <th className="px-5 py-3.5">Selling Price</th>
                <th className="px-5 py-3.5">Threshold</th>
                <th className="px-5 py-3.5">Current Stock</th>
                <th className="px-5 py-3.5 text-right">Quick Restock / Adjust</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
              {filteredProducts.map((p) => {
                const isOutOfStock = p.stock <= 0;
                const isLowStock = p.stock > 0 && p.stock <= (p.lowStockThreshold || 10);

                return (
                  <tr key={p.id} className="hover:bg-gray-50/70 transition">
                    <td className="px-5 py-3.5 flex items-center gap-3">
                      <img src={p.images[0]} alt="" className="w-9 h-9 rounded-lg object-cover border border-gray-100 shrink-0" />
                      <div className="truncate max-w-sm">
                        <span className="font-bold text-gray-900 block truncate">{p.title}</span>
                        <span className="text-[10px] text-gray-400 font-mono">SKU: {p.sku}</span>
                      </div>
                    </td>

                    <td className="px-5 py-3.5 font-bold text-gray-900">
                      ₹{p.price}
                    </td>

                    <td className="px-5 py-3.5 text-gray-500 font-mono">
                      {p.lowStockThreshold || 10} units
                    </td>

                    <td className="px-5 py-3.5">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-xs ${
                        isOutOfStock ? 'bg-red-50 text-red-700' : isLowStock ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {p.stock} units
                      </span>
                    </td>

                    <td className="px-5 py-3.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => handleAdjustStock(p.id, -5)}
                          className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-bold cursor-pointer"
                          title="Reduce by 5"
                        >
                          -5
                        </button>
                        <button
                          onClick={() => handleAdjustStock(p.id, -1)}
                          className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-bold cursor-pointer"
                          title="Reduce by 1"
                        >
                          -1
                        </button>
                        <button
                          onClick={() => handleAdjustStock(p.id, 1)}
                          className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold cursor-pointer"
                          title="Add 1"
                        >
                          +1
                        </button>
                        <button
                          onClick={() => handleAdjustStock(p.id, 10)}
                          className="px-2 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold cursor-pointer"
                          title="Restock +10"
                        >
                          +10
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
