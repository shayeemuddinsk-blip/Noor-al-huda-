import React, { useState, useEffect } from 'react';
import { 
  Search, Filter, ShoppingBag, MessageCircle, FileText, 
  CheckCircle, Clock, Truck, X, Printer, Phone, MapPin 
} from 'lucide-react';
import { api } from '../services/api';
import { Order, OrderStatus, PaymentStatus } from '../types';

export const OrderManagement: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  // Selected Order for Detail / Invoice Modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const loadOrders = () => {
    setLoading(true);
    api.getOrders().then((res) => {
      setOrders(res);
      setLoading(false);
    }).catch(console.error);
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const updated = await api.updateOrderStatus(orderId, newStatus, `Status updated by Admin to ${newStatus}`);
      setOrders((prev) => prev.map((o) => (o.id === orderId ? updated : o)));
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(updated);
      }
    } catch (err: any) {
      alert('Failed to update order status: ' + err.message);
    }
  };

  const handleUpdatePaymentStatus = async (orderId: string, newPaymentStatus: PaymentStatus) => {
    try {
      const updated = await api.updatePaymentStatus(orderId, newPaymentStatus);
      setOrders((prev) => prev.map((o) => (o.id === orderId ? updated : o)));
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(updated);
      }
    } catch (err: any) {
      alert('Failed to update payment status: ' + err.message);
    }
  };

  const filteredOrders = orders.filter((o) => {
    const matchSearch = 
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.customerPhone.includes(searchTerm) ||
      o.shippingAddress.pinCode.includes(searchTerm);
    
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const allStatuses: OrderStatus[] = [
    'Order Placed', 'Order Confirmed', 'Processing', 'Packed', 
    'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'
  ];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Order Fulfillment & Customer Invoicing
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Process incoming orders, confirm WhatsApp payments, and advance dispatch milestones.
          </p>
        </div>

        <button
          onClick={loadOrders}
          className="px-4 py-2 bg-white border border-gray-200 text-gray-700 text-xs font-semibold rounded-xl hover:bg-gray-50 transition shadow-xs cursor-pointer"
        >
          Refresh Orders
        </button>
      </div>

      {/* Filter toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Order ID, customer name, mobile, or PIN code..."
            className="w-full pl-10 pr-4 py-2 text-xs border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs border border-gray-300 rounded-xl outline-none bg-white font-medium text-gray-700"
        >
          <option value="all">All Order Statuses</option>
          {allStatuses.map((st) => (
            <option key={st} value={st}>{st}</option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-400 uppercase font-semibold text-[10px] tracking-wider border-b border-gray-100">
              <tr>
                <th className="px-5 py-3.5">Order ID</th>
                <th className="px-5 py-3.5">Customer & Contact</th>
                <th className="px-5 py-3.5">Location</th>
                <th className="px-5 py-3.5">Total</th>
                <th className="px-5 py-3.5">Payment</th>
                <th className="px-5 py-3.5">Order Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50/70 transition">
                  <td className="px-5 py-3.5 font-mono font-bold text-emerald-950">
                    {order.id}
                  </td>

                  <td className="px-5 py-3.5">
                    <div className="font-bold text-gray-900">{order.customerName}</div>
                    <div className="text-[10px] text-gray-400 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      <span>{order.customerPhone}</span>
                    </div>
                  </td>

                  <td className="px-5 py-3.5">
                    <span className="block">{order.shippingAddress.city}, {order.shippingAddress.state}</span>
                    <span className="text-[10px] text-gray-400 font-mono">PIN: {order.shippingAddress.pinCode}</span>
                  </td>

                  <td className="px-5 py-3.5 font-bold text-gray-900">
                    ₹{order.totalAmount}
                  </td>

                  <td className="px-5 py-3.5">
                    <div className="space-y-1">
                      <span className="block text-[10px] capitalize text-gray-600">
                        {order.paymentMethod.replace('_', ' ')}
                      </span>
                      <select
                        value={order.paymentStatus}
                        onChange={(e) => handleUpdatePaymentStatus(order.id, e.target.value as PaymentStatus)}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer outline-none ${
                          order.paymentStatus === 'confirmed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        <option value="pending">Pending Payment</option>
                        <option value="confirmed">Confirmed / Paid</option>
                        <option value="failed">Failed</option>
                        <option value="refunded">Refunded</option>
                      </select>
                    </div>
                  </td>

                  <td className="px-5 py-3.5">
                    <select
                      value={order.status}
                      onChange={(e) => handleUpdateStatus(order.id, e.target.value as OrderStatus)}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg border border-gray-300 bg-white text-gray-800 cursor-pointer outline-none focus:ring-2 focus:ring-emerald-700"
                    >
                      {allStatuses.map((st) => (
                        <option key={st} value={st}>{st}</option>
                      ))}
                    </select>
                  </td>

                  <td className="px-5 py-3.5 text-right space-x-2">
                    <a
                      href={`https://wa.me/${order.customerPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Assalamualaikum ${order.customerName}, this is regarding your Noor Al Huda order ${order.id}.`)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition inline-flex items-center"
                      title="Open WhatsApp with Customer"
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-emerald-100" />
                    </a>

                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="px-3 py-1 bg-gray-100 hover:bg-emerald-800 hover:text-white rounded-lg transition text-xs font-semibold cursor-pointer"
                    >
                      Invoice
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice & Order Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-gray-100 p-6 sm:p-8 my-8 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold font-serif">
                  ن
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-gray-900">
                    NOOR AL HUDA ISLAMIC SHOP
                  </h3>
                  <p className="text-[10px] text-gray-400">Order Tax Receipt & Delivery Note</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition"
                  title="Print Invoice"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Invoice Metadata */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-2xl mb-6 text-xs">
              <div>
                <span className="text-[10px] text-gray-400 uppercase font-semibold block">Order ID</span>
                <span className="font-mono font-bold text-emerald-950 block mt-0.5">{selectedOrder.id}</span>
              </div>
              <div>
                <span className="text-[10px] text-gray-400 uppercase font-semibold block">Order Date</span>
                <span className="font-semibold text-gray-800 block mt-0.5">
                  {new Date(selectedOrder.createdAt).toLocaleDateString('en-IN')}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-gray-400 uppercase font-semibold block">Payment Method</span>
                <span className="font-semibold text-gray-800 capitalize block mt-0.5">
                  {selectedOrder.paymentMethod.replace('_', ' ')}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-gray-400 uppercase font-semibold block">Payment Status</span>
                <span className="font-bold text-emerald-800 uppercase block mt-0.5">
                  {selectedOrder.paymentStatus}
                </span>
              </div>
            </div>

            {/* Recipient & Address */}
            <div className="p-4 border border-gray-200 rounded-2xl mb-6 text-xs space-y-1">
              <span className="text-[10px] text-gray-400 uppercase font-bold block mb-1">Deliver To:</span>
              <p className="font-bold text-gray-900">{selectedOrder.customerName} ({selectedOrder.customerPhone})</p>
              <p className="text-gray-600">{selectedOrder.shippingAddress.houseFlat}, {selectedOrder.shippingAddress.street}</p>
              <p className="text-gray-600">{selectedOrder.shippingAddress.locality ? `${selectedOrder.shippingAddress.locality}, ` : ''}{selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} - <strong>{selectedOrder.shippingAddress.pinCode}</strong></p>
            </div>

            {/* Line items */}
            <div className="border border-gray-200 rounded-2xl overflow-hidden mb-6 text-xs">
              <table className="w-full text-left">
                <thead className="bg-gray-50 text-gray-400 uppercase text-[10px] font-semibold border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-2.5">Item Description</th>
                    <th className="px-4 py-2.5">SKU</th>
                    <th className="px-4 py-2.5 text-center">Qty</th>
                    <th className="px-4 py-2.5 text-right">Price</th>
                    <th className="px-4 py-2.5 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {selectedOrder.items.map((it, idx) => (
                    <tr key={idx}>
                      <td className="px-4 py-2.5 font-semibold text-gray-900">
                        {it.productTitle} {it.variantName ? `(${it.variantName})` : ''}
                      </td>
                      <td className="px-4 py-2.5 font-mono text-gray-500">{it.sku}</td>
                      <td className="px-4 py-2.5 text-center">{it.quantity}</td>
                      <td className="px-4 py-2.5 text-right font-medium">₹{it.price}</td>
                      <td className="px-4 py-2.5 text-right font-bold text-gray-900">₹{it.lineTotal}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="space-y-1.5 text-xs text-right mb-6">
              <div className="flex justify-between max-w-xs ml-auto text-gray-600">
                <span>Subtotal:</span>
                <span className="font-semibold text-gray-900">₹{selectedOrder.subtotal}</span>
              </div>
              {selectedOrder.discountAmount > 0 && (
                <div className="flex justify-between max-w-xs ml-auto text-emerald-700 font-semibold">
                  <span>Coupon Discount:</span>
                  <span>-₹{selectedOrder.discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between max-w-xs ml-auto text-gray-600">
                <span>Delivery:</span>
                <span className="font-semibold text-gray-900">
                  {selectedOrder.deliveryCharge === 0 ? 'FREE' : `₹${selectedOrder.deliveryCharge}`}
                </span>
              </div>
              <div className="flex justify-between max-w-xs ml-auto text-sm font-extrabold text-emerald-950 pt-2 border-t border-gray-200">
                <span>Total Amount:</span>
                <span>₹{selectedOrder.totalAmount}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100 flex justify-end">
              <button
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2 bg-emerald-800 text-white font-bold text-xs rounded-xl hover:bg-emerald-900"
              >
                Close Receipt
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
