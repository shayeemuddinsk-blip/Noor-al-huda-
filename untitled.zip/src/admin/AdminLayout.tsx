import React, { useState } from 'react';
import { 
  LayoutDashboard, Package, FolderTree, Image, ShoppingBag, 
  Boxes, Tag, Settings, Database, History, Eye, LogOut, 
  Menu, X, Sparkles, ChevronRight, Truck, Users 
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface AdminLayoutProps {
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const { currentUser, isOwner, logout, setAdminPreviewMode } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
    { label: 'Products', icon: Package, path: '/admin/products' },
    { label: 'Categories', icon: FolderTree, path: '/admin/categories' },
    { label: 'Promotional Banners', icon: Image, path: '/admin/banners' },
    { label: 'Orders & Fulfillment', icon: ShoppingBag, path: '/admin/orders' },
    { label: 'Inventory & Stock', icon: Boxes, path: '/admin/inventory' },
    { label: 'Coupons & Promos', icon: Tag, path: '/admin/coupons' },
    { label: 'Delivery Rules', icon: Truck, path: '/admin/delivery' },
    { label: 'Admins & Users', icon: Users, path: '/admin/users' },
    { label: 'Google Sheets & Drive Hub', icon: Database, path: '/admin/google-sheets' },
    { label: 'Store Settings', icon: Settings, path: '/admin/settings' },
    { label: 'Audit Logs', icon: History, path: '/admin/audit-logs' },
  ];

  const handlePreviewCustomerStore = () => {
    setAdminPreviewMode(true);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      
      {/* Sidebar for Desktop */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-emerald-950 text-white flex flex-col justify-between transition-transform duration-300 md:static md:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div>
          {/* Brand header */}
          <div className="p-5 border-b border-emerald-900/60 flex items-center justify-between">
            <Link to="/admin" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-300 font-serif font-bold text-base border border-amber-400/30">
                ن
              </div>
              <div>
                <span className="text-sm font-extrabold tracking-wide text-white block leading-tight">
                  NOOR AL HUDA
                </span>
                <span className="text-[9px] font-semibold text-amber-400 uppercase tracking-widest block">
                  ADMIN CONTROL PANEL
                </span>
              </div>
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="md:hidden text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Nav List */}
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setSidebarOpen(false)}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition ${
                    isActive
                      ? 'bg-emerald-800 text-amber-300 shadow-xs font-bold'
                      : 'text-emerald-100/70 hover:bg-emerald-900/60 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* User profile & Store Preview toggle */}
        <div className="p-4 border-t border-emerald-900/60 space-y-3">
          {/* Preview customer store button */}
          <button
            onClick={handlePreviewCustomerStore}
            className="w-full py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <Eye className="w-4 h-4" />
            <span>Preview Customer Store</span>
          </button>

          <div className="flex items-center justify-between text-xs pt-1">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-full bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">
                {currentUser?.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'A'}
              </div>
              <div className="truncate">
                <span className="font-bold text-white block truncate leading-tight">
                  {currentUser?.displayName || (isOwner ? 'Store Owner' : 'Administrator')}
                </span>
                <span className="text-[10px] text-emerald-300 font-mono truncate block">
                  {currentUser?.email || 'Admin'}
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                logout();
                navigate('/');
              }}
              className="text-gray-400 hover:text-red-400 p-1.5 transition cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Navbar */}
        <header className="h-14 bg-white border-b border-gray-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-1.5 rounded-lg text-gray-600 hover:bg-gray-100"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider hidden sm:inline">
              Store Control & Management
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePreviewCustomerStore}
              className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-emerald-200"
            >
              <Eye className="w-3.5 h-3.5 text-emerald-700" />
              <span>Customer Store Preview</span>
            </button>
          </div>
        </header>

        {/* Content Body */}
        <main className="p-4 sm:p-6 lg:p-8 flex-1 overflow-y-auto">
          {children}
        </main>

      </div>

    </div>
  );
};
