import React, { useState, useEffect } from 'react';
import { 
  Users, Shield, ShieldCheck, UserCheck, UserX, Search, 
  Crown, Mail, Phone, Check, AlertCircle, Plus, Sparkles, Filter 
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

interface UserRecord {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: 'owner' | 'admin' | 'super_admin' | 'seller' | 'reseller' | 'customer';
  isOwner?: boolean;
  isAdmin?: boolean;
  totalOrders?: number;
  totalSpent?: number;
  createdAt: string;
}

export const UserManagement: React.FC = () => {
  const { isOwner, currentUser } = useAuth();
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admins' | 'sellers' | 'resellers' | 'customers'>('all');
  
  // Quick Add / Promote User State
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminPhone, setNewAdminPhone] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'admin' | 'seller' | 'reseller'>('admin');
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await api.getAllUsers();
      setUsers(data);
    } catch (err: any) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handlePromote = async (email: string, name?: string, phone?: string, role: string = newAdminRole) => {
    try {
      setSubmitting(true);
      setFeedback(null);
      const res = await api.promoteUserToAdmin({ email, name, phone, role });
      setFeedback({ type: 'success', message: res.message || `Set role for ${email} to ${role.toUpperCase()}!` });
      await loadUsers();
      setNewAdminEmail('');
      setNewAdminName('');
      setNewAdminPhone('');
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to update user' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleSetUserRole = async (email: string, newRole: string) => {
    try {
      setSubmitting(true);
      setFeedback(null);
      const res = await api.updateUserRole(email, newRole);
      setFeedback({ type: 'success', message: res.message || `Updated role for ${email} to ${newRole.toUpperCase()}!` });
      await loadUsers();
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to change role' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemote = async (email: string) => {
    if (!confirm(`Are you sure you want to revoke elevated role from ${email}? They will return to Customer status.`)) {
      return;
    }
    try {
      setSubmitting(true);
      setFeedback(null);
      const res = await api.demoteUserFromAdmin(email);
      setFeedback({ type: 'success', message: res.message || `Revoked role from ${email}` });
      await loadUsers();
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to revoke role' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;
    handlePromote(newAdminEmail.trim(), newAdminName.trim() || undefined, newAdminPhone.trim() || undefined, newAdminRole);
  };

  const totalAdmins = users.filter((u) => u.role === 'owner' || u.role === 'admin' || u.role === 'super_admin').length;
  const totalSellers = users.filter((u) => u.role === 'seller').length;
  const totalResellers = users.filter((u) => u.role === 'reseller').length;
  const totalCustomers = users.filter((u) => u.role === 'customer' || (!u.role && !u.isAdmin && !u.isOwner)).length;

  const filteredUsers = users.filter((u) => {
    const query = search.toLowerCase().trim();
    const matchesSearch = !query || 
      u.email.toLowerCase().includes(query) || 
      (u.name && u.name.toLowerCase().includes(query)) ||
      (u.phone && u.phone.includes(query));

    if (!matchesSearch) return false;

    if (roleFilter === 'admins') {
      return u.role === 'owner' || u.role === 'admin' || u.role === 'super_admin';
    }
    if (roleFilter === 'sellers') {
      return u.role === 'seller';
    }
    if (roleFilter === 'resellers') {
      return u.role === 'reseller';
    }
    if (roleFilter === 'customers') {
      return u.role === 'customer' || (!u.role && !u.isAdmin && !u.isOwner);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Page Title & Intro */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-emerald-800" />
            Administrator & User Management
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Grant or revoke Administrator access to any user email. Admins can manage products, orders, inventory and settings.
          </p>
        </div>
      </div>

      {/* Feedback banner */}
      {feedback && (
        <div className={`p-4 rounded-2xl border text-xs flex items-center gap-2.5 shadow-xs transition ${
          feedback.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          {feedback.type === 'success' ? (
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span className="font-medium">{feedback.message}</span>
        </div>
      )}

      {/* Top Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center font-bold shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Total Accounts</span>
            <span className="text-lg font-extrabold text-gray-900">{users.length}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center font-bold shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Administrators</span>
            <span className="text-lg font-extrabold text-gray-900">{totalAdmins}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center font-bold shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Sellers & Resellers</span>
            <span className="text-lg font-extrabold text-gray-900">{totalSellers + totalResellers}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gray-50 text-gray-700 flex items-center justify-center font-bold shrink-0">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Retail Customers</span>
            <span className="text-lg font-extrabold text-gray-900">{totalCustomers}</span>
          </div>
        </div>
      </div>

      {/* Add / Promote New Administrator Quick Box */}
      {/* Add / Assign New Role Quick Box */}
      <div className="bg-gradient-to-br from-emerald-950 to-emerald-900 text-white rounded-3xl p-6 shadow-md border border-emerald-800">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-white">Assign Role (Admin, Seller, Reseller)</h2>
        </div>
        <p className="text-xs text-emerald-200/80 mb-4">
          Enter any email address and choose the desired role. Customizing sellers, reseller partners, and administrators takes effect immediately.
        </p>

        <form onSubmit={handleAddAdminSubmit} className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-medium text-emerald-200 mb-1">Email Address *</label>
            <input
              type="email"
              required
              placeholder="e.g. partner@gmail.com"
              value={newAdminEmail}
              onChange={(e) => setNewAdminEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-emerald-300/50 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>

          <div className="sm:col-span-3">
            <label className="block text-[11px] font-medium text-emerald-200 mb-1">Full Name (Optional)</label>
            <input
              type="text"
              placeholder="e.g. Vendor Name"
              value={newAdminName}
              onChange={(e) => setNewAdminName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-emerald-300/50 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>

          <div className="sm:col-span-3">
            <label className="block text-[11px] font-medium text-emerald-200 mb-1">Role To Assign</label>
            <select
              value={newAdminRole}
              onChange={(e) => setNewAdminRole(e.target.value as any)}
              className="w-full px-3 py-2.5 rounded-xl bg-emerald-900 border border-white/20 text-white text-xs focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              <option value="admin">Administrator</option>
              <option value="seller">Authorized Seller</option>
              <option value="reseller">Reseller Partner</option>
            </select>
          </div>

          <div className="sm:col-span-2 flex items-end">
            <button
              type="submit"
              disabled={submitting || !newAdminEmail.trim()}
              className="w-full py-2.5 px-3 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Plus className="w-4 h-4" />
              <span>Assign Role</span>
            </button>
          </div>
        </form>
      </div>

      {/* User Roster Table with Search & Filter */}
      <div className="bg-white rounded-3xl border border-gray-200/80 shadow-xs overflow-hidden">
        
        {/* Table Filter Bar */}
        <div className="p-4 sm:p-5 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Search box */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, email, or phone..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto">
            <button
              onClick={() => setRoleFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                roleFilter === 'all' 
                  ? 'bg-emerald-800 text-white shadow-xs' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All ({users.length})
            </button>
            <button
              onClick={() => setRoleFilter('admins')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1 ${
                roleFilter === 'admins' 
                  ? 'bg-emerald-800 text-white shadow-xs' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Admins ({totalAdmins})
            </button>
            <button
              onClick={() => setRoleFilter('sellers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1 ${
                roleFilter === 'sellers' 
                  ? 'bg-blue-800 text-white shadow-xs' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Sellers ({totalSellers})
            </button>
            <button
              onClick={() => setRoleFilter('resellers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1 ${
                roleFilter === 'resellers' 
                  ? 'bg-purple-800 text-white shadow-xs' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Resellers ({totalResellers})
            </button>
            <button
              onClick={() => setRoleFilter('customers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                roleFilter === 'customers' 
                  ? 'bg-emerald-800 text-white shadow-xs' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Customers ({totalCustomers})
            </button>
          </div>

        </div>

        {/* Table Content */}
        {loading ? (
          <div className="p-12 text-center text-xs text-gray-500">
            <div className="w-8 h-8 border-3 border-emerald-800 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            Loading accounts and permissions...
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="p-12 text-center text-xs text-gray-500">
            No matching accounts found for the current query.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-gray-50/75 border-b border-gray-100 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                  <th className="py-3 px-4">User / Account</th>
                  <th className="py-3 px-4">Contact Info</th>
                  <th className="py-3 px-4">Current Role</th>
                  <th className="py-3 px-4 text-center">Orders Placed</th>
                  <th className="py-3 px-4 text-right">Role Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredUsers.map((u) => {
                  const isUserOwner = u.role === 'owner' || u.isOwner;
                  const isUserAdmin = u.role === 'admin' || u.role === 'super_admin' || isUserOwner;
                  const isSelf = currentUser?.email?.toLowerCase() === u.email.toLowerCase();

                  return (
                    <tr key={u.id || u.email} className="hover:bg-gray-50/50 transition">
                      {/* Name & Avatar */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase ${
                            isUserOwner 
                              ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                              : isUserAdmin 
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                                : 'bg-gray-100 text-gray-700'
                          }`}>
                            {u.name ? u.name.charAt(0) : u.email.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-gray-900 flex items-center gap-1.5">
                              <span>{u.name || 'Store Customer'}</span>
                              {isUserOwner && <Crown className="w-3.5 h-3.5 text-amber-600 inline" />}
                              {isSelf && (
                                <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.2 rounded font-semibold border border-emerald-200">
                                  You
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-gray-400 font-mono block">{u.email}</span>
                          </div>
                        </div>
                      </td>

                      {/* Contact Info */}
                      <td className="py-3.5 px-4 text-gray-600">
                        {u.phone ? (
                          <span className="font-mono">{u.phone}</span>
                        ) : (
                          <span className="text-gray-400 italic">No phone attached</span>
                        )}
                      </td>

                      {/* Role Badge */}
                      <td className="py-3.5 px-4">
                        {isUserOwner ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            <Crown className="w-3 h-3 text-amber-700" />
                            Primary Owner
                          </span>
                        ) : isUserAdmin ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                            <ShieldCheck className="w-3 h-3 text-emerald-700" />
                            Administrator
                          </span>
                        ) : u.role === 'seller' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-100 text-blue-900 border border-blue-300">
                            <Sparkles className="w-3 h-3 text-blue-700" />
                            Authorized Seller
                          </span>
                        ) : u.role === 'reseller' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-100 text-purple-900 border border-purple-300">
                            <UserCheck className="w-3 h-3 text-purple-700" />
                            Reseller Partner
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-gray-100 text-gray-700">
                            Customer
                          </span>
                        )}
                      </td>

                      {/* Orders */}
                      <td className="py-3.5 px-4 text-center font-medium text-gray-700">
                        {u.totalOrders || 0}
                      </td>

                      {/* Action buttons / Role Selector */}
                      <td className="py-3.5 px-4 text-right">
                        {isUserOwner ? (
                          <span className="text-[11px] text-gray-400 italic">
                            Protected Owner
                          </span>
                        ) : (
                          <div className="flex items-center justify-end gap-2">
                            <select
                              value={u.role || 'customer'}
                              onChange={(e) => handleSetUserRole(u.email, e.target.value)}
                              disabled={submitting}
                              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-gray-800 hover:border-emerald-700 focus:outline-none focus:ring-1 focus:ring-emerald-700 cursor-pointer disabled:opacity-50"
                            >
                              <option value="admin">Administrator</option>
                              <option value="seller">Authorized Seller</option>
                              <option value="reseller">Reseller Partner</option>
                              <option value="customer">Customer</option>
                            </select>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
};
