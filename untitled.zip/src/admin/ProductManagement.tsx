import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Edit2, Trash2, Eye, Upload, 
  X, Check, AlertCircle, Image as ImageIcon, Sparkles, Star
} from 'lucide-react';
import { api } from '../services/api';
import { Product, Category, ProductVariant } from '../types';
import { uploadImageToGoogleDrive, getCachedAccessToken, DRIVE_FOLDER_ID } from '../services/googleWorkspace';
import { useAuth } from '../contexts/AuthContext';

export const ProductManagement: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [loading, setLoading] = useState(true);

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Delete confirmation modal state (replaces window.confirm)
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Form fields
  const [title, setTitle] = useState('');
  const [sku, setSku] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [brand, setBrand] = useState('Noor Al Huda Fragrances');
  const [price, setPrice] = useState<number>(499);
  const [originalPrice, setOriginalPrice] = useState<number>(799);
  const [stock, setStock] = useState<number>(30);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(10);
  const [sellerName, setSellerName] = useState('Noor Al Huda Direct');
  const [description, setDescription] = useState('');
  // Multiple images state (Flipkart / Amazon style)
  const [images, setImages] = useState<string[]>([]);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isBestSeller, setIsBestSeller] = useState(false);

  // File upload state
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);

  const loadData = () => {
    setLoading(true);
    Promise.all([api.getProducts(), api.getCategories()]).then(([p, c]) => {
      setProducts(p);
      setCategories(c);
      if (c.length > 0 && !categoryId) {
        setCategoryId(c[0].id);
      }
      setLoading(false);
    }).catch(console.error);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setTitle('');
    setSku(`NAH-PRD-${Math.floor(100 + Math.random() * 900)}`);
    setCategoryId(categories[0]?.id || 'cat-attars');
    setBrand('Noor Al Huda Fragrances');
    setPrice(499);
    setOriginalPrice(799);
    setStock(25);
    setLowStockThreshold(8);
    setDescription('');
    setImages(['https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=800&auto=format&fit=crop&q=80']);
    setCustomImageUrl('');
    setIsActive(true);
    setIsFeatured(false);
    setIsBestSeller(false);
    setSellerName('Noor Al Huda Direct');
    setUploadMessage(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setTitle(prod.title);
    setSku(prod.sku);
    setCategoryId(prod.categoryId);
    setBrand(prod.brand || 'Noor Al Huda');
    setPrice(prod.price);
    setOriginalPrice(prod.originalPrice || 0);
    setStock(prod.stock);
    setLowStockThreshold(prod.lowStockThreshold || 10);
    setSellerName(prod.sellerName || 'Noor Al Huda Direct');
    setDescription(prod.description);
    setImages(prod.images && prod.images.length > 0 ? [...prod.images] : ['https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=800&auto=format&fit=crop&q=80']);
    setCustomImageUrl('');
    setIsActive(prod.isActive);
    setIsFeatured(prod.isFeatured);
    setIsBestSeller(prod.isBestSeller || false);
    setUploadMessage(null);
    setIsModalOpen(true);
  };

  // Support multiple image files upload simultaneously
  const handleImageFilesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadingImage(true);
    setUploadMessage(null);

    const uploadedUrls: string[] = [];
    const token = getCachedAccessToken();
    let driveUploadedCount = 0;

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > 10 * 1024 * 1024) continue;

        // Try direct Google Drive upload first if token is available
        if (token) {
          try {
            const driveFile = await uploadImageToGoogleDrive(file, DRIVE_FOLDER_ID);
            if (driveFile.url) {
              uploadedUrls.push(driveFile.url);
              driveUploadedCount++;
              continue;
            }
          } catch (dErr) {
            console.warn('[Google Drive] Direct upload notice, using local backup:', dErr);
          }
        }

        // Server storage fallback
        const base64Data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileData: base64Data,
            fileName: file.name,
          }),
        });
        const data = await res.json();
        if (data.url) {
          uploadedUrls.push(data.url);
        }
      }

      if (uploadedUrls.length > 0) {
        setImages((prev) => [...prev, ...uploadedUrls]);
        if (driveUploadedCount > 0) {
          setUploadMessage(`✓ Successfully uploaded ${driveUploadedCount} photo(s) directly to your Google Drive folder (${DRIVE_FOLDER_ID})!`);
        } else {
          setUploadMessage(`✓ Added ${uploadedUrls.length} image(s) to product gallery!`);
        }
      }
    } catch (err: any) {
      setUploadMessage('Failed to upload some images.');
    } finally {
      setUploadingImage(false);
      e.target.value = '';
    }
  };

  const handleAddCustomImageUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customImageUrl.trim()) return;
    setImages((prev) => [...prev, customImageUrl.trim()]);
    setCustomImageUrl('');
  };

  const handleRemoveImage = (indexToRemove: number) => {
    if (images.length <= 1) {
      alert('Product must have at least one image.');
      return;
    }
    setImages((prev) => prev.filter((_, i) => i !== indexToRemove));
  };

  const handleSetCoverImage = (indexToCover: number) => {
    if (indexToCover === 0) return;
    setImages((prev) => {
      const copy = [...prev];
      const [target] = copy.splice(indexToCover, 1);
      return [target, ...copy];
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return alert('Please enter product title');
    if (images.length === 0) return alert('Please add at least one product image.');

    const catObj = categories.find((c) => c.id === categoryId);

    const payload: Partial<Product> = {
      title: title.trim(),
      slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      sku: sku.trim(),
      categoryId,
      categoryName: catObj?.name || 'Islamic Goods',
      brand: brand.trim(),
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : undefined,
      discountPercentage: originalPrice && originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0,
      stock: Number(stock),
      lowStockThreshold: Number(lowStockThreshold),
      description: description.trim(),
      images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1615655406736-b37c4fabf923?w=800&auto=format&fit=crop&q=80'],
      isActive,
      isFeatured,
      isBestSeller,
      sellerName: sellerName.trim() || 'Noor Al Huda Direct',
    };

    try {
      if (editingProduct) {
        await api.updateProduct(editingProduct.id, payload);
      } else {
        await api.createProduct(payload);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Operation failed');
    }
  };

  // Safe In-App Delete Execution
  const executeDeleteProduct = async () => {
    if (!productToDelete) return;
    setDeleting(true);
    try {
      await api.deleteProduct(productToDelete.id);
      setProductToDelete(null);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete product');
    } finally {
      setDeleting(false);
    }
  };

  const filteredProducts = products.filter((p) => {
    const matchSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = !selectedCategory || p.categoryId === selectedCategory;
    return matchSearch && matchCategory;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Product Catalog Management
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Add multiple images, manage prices, update stock, and control storefront availability.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by title, fragrance name or SKU..."
            className="w-full pl-10 pr-4 py-2 text-xs border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 text-xs border border-gray-300 rounded-xl outline-none bg-white font-medium text-gray-700"
        >
          <option value="">All Categories ({categories.length})</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50/80 border-b border-gray-200/80 text-gray-500 uppercase tracking-wider font-semibold text-[10px]">
              <tr>
                <th className="px-5 py-3.5">Product</th>
                <th className="px-5 py-3.5">Category</th>
                <th className="px-5 py-3.5">Price</th>
                <th className="px-5 py-3.5">Stock</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredProducts.map((p) => {
                const isLowStock = p.stock > 0 && p.stock <= (p.lowStockThreshold || 10);
                const isOutOfStock = p.stock <= 0;

                return (
                  <tr key={p.id} className="hover:bg-gray-50/60 transition">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="relative w-12 h-12 rounded-xl bg-gray-100 overflow-hidden border border-gray-200 shrink-0">
                          <img src={p.images[0]} alt={p.title} className="w-full h-full object-cover" />
                          {p.images.length > 1 && (
                            <span className="absolute bottom-0 right-0 bg-emerald-900/90 text-white text-[9px] font-bold px-1 rounded-tl-md">
                              +{p.images.length - 1}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 leading-snug">{p.title}</p>
                          <div className="flex items-center flex-wrap gap-2 mt-0.5">
                            <span className="font-mono text-[10px] text-gray-400">SKU: {p.sku}</span>
                            <span className="text-gray-300">•</span>
                            <span className="text-[10px] text-emerald-800 font-semibold">{p.images.length} photo{p.images.length > 1 ? 's' : ''}</span>
                            {p.sellerName && (
                              <>
                                <span className="text-gray-300">•</span>
                                <span className="text-[10px] bg-blue-50 text-blue-800 px-1.5 py-0.2 rounded font-medium border border-blue-200">
                                  Seller: {p.sellerName}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-3 font-medium text-gray-600">
                      {p.categoryName || 'Islamic Goods'}
                    </td>

                    <td className="px-5 py-3 font-bold text-gray-900">
                      ₹{p.price}
                      {p.originalPrice && (
                        <span className="text-[10px] text-gray-400 line-through block">₹{p.originalPrice}</span>
                      )}
                    </td>

                    <td className="px-5 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isOutOfStock ? 'bg-red-50 text-red-700' : isLowStock ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {p.stock} units
                      </span>
                    </td>

                    <td className="px-5 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        p.isActive ? 'bg-emerald-100 text-emerald-900' : 'bg-gray-100 text-gray-500'
                      }`}>
                        {p.isActive ? 'Active' : 'Draft'}
                      </span>
                    </td>

                    <td className="px-5 py-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => handleOpenEditModal(p)}
                        className="p-1.5 rounded-lg bg-gray-100 hover:bg-emerald-800 hover:text-white transition text-gray-600 cursor-pointer"
                        title="Edit Product"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setProductToDelete(p)}
                        className="p-1.5 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white transition text-red-600 cursor-pointer"
                        title="Delete Product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Safe In-App Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-gray-100 animate-scale-up">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-extrabold text-gray-900 mb-2">Delete Product Permanently?</h3>
            <p className="text-xs text-gray-500 mb-5 leading-relaxed">
              Are you sure you want to remove <strong className="text-gray-900">"{productToDelete.title}"</strong> from the store catalog? It will be removed immediately from the customer storefront and database.
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                disabled={deleting}
                className="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-50 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeDeleteProduct}
                disabled={deleting}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
              >
                {deleting ? 'Deleting...' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal with Flipkart/Amazon Multi-Photo Upload */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-gray-100 p-6 sm:p-8 my-8 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-6">
              <div>
                <h3 className="text-base font-extrabold text-gray-900">
                  {editingProduct ? 'Edit Product & Gallery' : 'Add New Product to Store'}
                </h3>
                <p className="text-xs text-gray-400">Upload multiple photos like Flipkart or Amazon. All images will be viewable by customers.</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-gray-700 mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Royal Cambodian Dehn Al Oudh (Pure Aged)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">SKU / Item Code *</label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    placeholder="NAH-ATT-001"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Category *</label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none bg-white text-xs"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Selling Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Original Price / MRP (₹)</label>
                  <input
                    type="number"
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Available Physical Stock *</label>
                  <input
                    type="number"
                    required
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Low Stock Warning Limit</label>
                  <input
                    type="number"
                    value={lowStockThreshold}
                    onChange={(e) => setLowStockThreshold(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Brand Name</label>
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="Noor Al Huda Fragrances"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Seller / Reseller Partner</label>
                  <input
                    type="text"
                    value={sellerName}
                    onChange={(e) => setSellerName(e.target.value)}
                    placeholder="e.g. Noor Al Huda Direct / Authorized Seller"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs"
                  />
                </div>
              </div>

              {/* Flipkart / Amazon Multi-Photo Gallery Section */}
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-gray-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-emerald-800" />
                    Product Photos Gallery ({images.length} uploaded)
                  </label>
                  <span className="text-[10px] text-gray-500 font-medium">
                    Multiple photos enabled (First image is Cover)
                  </span>
                </div>

                {/* Upload Buttons & URL Input */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
                      Upload from Device (Select multiple):
                    </label>
                    <div className="flex flex-col gap-1.5">
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleImageFilesChange}
                        disabled={uploadingImage}
                        className="text-xs text-gray-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-emerald-800 file:text-white hover:file:bg-emerald-900 cursor-pointer disabled:opacity-50 max-w-full"
                      />
                      {uploadingImage && (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-semibold animate-pulse bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                          <span>Uploading image(s) to permanent storage...</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">
                      Or Add by Image URL:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={customImageUrl}
                        onChange={(e) => setCustomImageUrl(e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-700 bg-white"
                      />
                      <button
                        type="button"
                        onClick={handleAddCustomImageUrl}
                        className="px-3 py-1.5 bg-gray-800 hover:bg-gray-900 text-white rounded-xl text-xs font-semibold cursor-pointer shrink-0"
                      >
                        + Add
                      </button>
                    </div>
                  </div>
                </div>

                {uploadMessage && (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold break-words">
                    {uploadMessage}
                  </div>
                )}

                {/* Photo Previews Grid */}
                <div className="pt-2">
                  <p className="text-[10px] text-gray-400 mb-2 font-medium">
                    Current Photos (click "Make Cover" to set as main thumbnail):
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
                    {images.map((img, idx) => (
                      <div
                        key={idx}
                        className={`relative group rounded-xl overflow-hidden border-2 bg-white p-1 transition ${
                          idx === 0 ? 'border-emerald-700 shadow-sm' : 'border-gray-200'
                        }`}
                      >
                        <div className="aspect-square rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center p-0.5">
                          <img src={img} alt={`Preview ${idx}`} className="w-full h-full object-contain" />
                        </div>
                        
                        {idx === 0 ? (
                          <span className="absolute top-2 left-2 bg-emerald-800 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-md shadow-xs">
                            Cover
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSetCoverImage(idx)}
                            className="absolute top-2 left-2 bg-black/70 hover:bg-emerald-800 text-white text-[9px] font-semibold px-1.5 py-0.5 rounded-md opacity-0 group-hover:opacity-100 transition cursor-pointer"
                            title="Set as Main Cover Photo"
                          >
                            Set Cover
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleRemoveImage(idx)}
                          className="absolute top-2 right-2 p-1 bg-red-600 hover:bg-red-700 text-white rounded-full transition shadow-xs cursor-pointer opacity-80 group-hover:opacity-100"
                          title="Remove Photo"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-bold text-gray-700 mb-1">Product Description</label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail the fragrance notes, alcohol-free guarantee, origin, fabric details..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 text-xs leading-relaxed"
                />
              </div>

              {/* Toggles */}
              <div className="pt-2 flex flex-wrap items-center gap-5">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-800 focus:ring-emerald-700"
                  />
                  <span className="font-semibold text-gray-800">Publish on Storefront</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-800 focus:ring-emerald-700"
                  />
                  <span className="font-semibold text-gray-800">Feature on Homepage</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBestSeller}
                    onChange={(e) => setIsBestSeller(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-800 focus:ring-emerald-700"
                  />
                  <span className="font-semibold text-gray-800">Bestseller Badge</span>
                </label>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl shadow-md transition cursor-pointer"
                >
                  {editingProduct ? 'Save Updates' : 'Publish Product'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
