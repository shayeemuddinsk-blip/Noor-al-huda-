import React, { useState, useEffect } from 'react';
import { Truck, Check, AlertCircle, ShieldCheck } from 'lucide-react';
import { api } from '../services/api';
import { StoreSettings } from '../types';

export const DeliverySettings: React.FC = () => {
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [standardFee, setStandardFee] = useState<number>(40);
  const [freeThreshold, setFreeThreshold] = useState<number>(999);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getSettings().then((s) => {
      setSettings(s);
      setStandardFee(s.standardDeliveryCharge);
      setFreeThreshold(s.freeDeliveryThreshold);
      setLoading(false);
    }).catch(console.error);
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const updated = await api.updateSettings({
        standardDeliveryCharge: Number(standardFee),
        freeDeliveryThreshold: Number(freeThreshold),
      });
      setSettings(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err: any) {
      alert('Failed to update delivery settings: ' + err.message);
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
          Delivery Rules & Free Shipping Thresholds
        </h1>
        <p className="text-xs text-gray-500 mt-0.5">
          Configure nationwide shipping charges and automatic free delivery qualification.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Delivery rules updated and enforced across checkout!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200/80 shadow-xs space-y-5 text-xs">
        
        <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-900/10 flex items-start gap-3">
          <Truck className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold text-emerald-950">Dynamic Delivery Rule Logic</h4>
            <p className="text-[11px] text-gray-600 mt-0.5 leading-relaxed">
              When an eligible cart subtotal reaches the <strong>Free Delivery Threshold</strong>, the delivery fee becomes ₹0. Below this threshold, the configured <strong>Standard Delivery Charge</strong> applies automatically.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-gray-700 mb-1">
              Standard Delivery Charge (₹)
            </label>
            <input
              type="number"
              required
              min="0"
              value={standardFee}
              onChange={(e) => setStandardFee(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 font-bold"
            />
            <span className="text-[10px] text-gray-400 mt-1 block">Default: ₹40</span>
          </div>

          <div>
            <label className="block font-bold text-gray-700 mb-1">
              Free Delivery Threshold (₹)
            </label>
            <input
              type="number"
              required
              min="0"
              value={freeThreshold}
              onChange={(e) => setFreeThreshold(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-700 font-bold"
            />
            <span className="text-[10px] text-gray-400 mt-1 block">Default: ₹999</span>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-100 flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl shadow-md transition cursor-pointer"
          >
            Save Delivery Rules
          </button>
        </div>

      </form>

    </div>
  );
};
