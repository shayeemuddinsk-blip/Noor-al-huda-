import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, ShoppingBag, Clock, PackageCheck, 
  AlertTriangle, DollarSign, Users, Database, 
  ArrowRight, Plus, CheckCircle, RefreshCw 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../services/api';
import { Order } from '../types';

export const AdminDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<{
    totalOrders: number;
    awaitingConfirmation: number;
    awaitingShipment: number;
    deliveredOrders: number;
    cancelledOrders: number;
    grossOrderValue: number;
    activeProductsCount: number;
    lowStockProductsCount: number;
    outOfStockProductsCount: number;
    totalCustomersCount: number;
    recentOrders: Order[];
  } | null>(null);

  const [loading, setLoading] = useState(true);

  const loadData = () => {
    setLoading(true);
    api.getAdminMetrics().then((res) => {
      setMetrics(res);
      setLoading(false);
    }).catch((err) => {
      console.error(err);
      setLoading(false);
    });
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Store Operational Overview
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Real-time business performance, order dispatch tracking, and inventory health.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadData}
            className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:text-emerald-800 transition shadow-xs cursor-pointer"
            title="Refresh Metrics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <Link
            to="/admin/products?action=new"
            className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Gross Order Value */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Gross Order Value</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-gray-900">
            ₹{metrics?.grossOrderValue || 0}
          </p>
          <span className="text-[10px] text-emerald-700 font-semibold mt-1 block">
            Calculated from confirmed non-cancelled orders
          </span>
        </div>

        {/* Total Orders */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-gray-900">
            {metrics?.totalOrders || 0}
          </p>
          <span className="text-[10px] text-blue-700 font-semibold mt-1 block">
            {metrics?.awaitingConfirmation || 0} awaiting confirmation
          </span>
        </div>

        {/* Active Products */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Active Products</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <PackageCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-gray-900">
            {metrics?.activeProductsCount || 0}
          </p>
          <span className="text-[10px] text-purple-700 font-semibold mt-1 block">
            Live on customer storefront
          </span>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Low Stock Alerts</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-amber-700">
            {metrics?.lowStockProductsCount || 0}
          </p>
          <span className="text-[10px] text-amber-700 font-semibold mt-1 block">
            {metrics?.outOfStockProductsCount || 0} items completely out of stock
          </span>
        </div>

      </div>

      {/* Quick Action Navigation Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Link
          to="/admin/orders"
          className="p-4 bg-white rounded-2xl border border-gray-200/80 hover:border-emerald-800/40 transition shadow-xs flex items-center gap-3 group"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center group-hover:scale-105 transition">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-900">Process Orders</h4>
            <span className="text-[10px] text-gray-400">Update statuses</span>
          </div>
        </Link>

        <Link
          to="/admin/products"
          className="p-4 bg-white rounded-2xl border border-gray-200/80 hover:border-emerald-800/40 transition shadow-xs flex items-center gap-3 group"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center group-hover:scale-105 transition">
            <PackageCheck className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-900">Manage Catalog</h4>
            <span className="text-[10px] text-gray-400">Pricing & stock</span>
          </div>
        </Link>

        <Link
          to="/admin/google-sheets"
          className="p-4 bg-white rounded-2xl border border-gray-200/80 hover:border-emerald-800/40 transition shadow-xs flex items-center gap-3 group"
        >
          <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center group-hover:scale-105 transition">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-900">Google Sheets Hub</h4>
            <span className="text-[10px] text-gray-400">30 Sheets & Drive</span>
          </div>
        </Link>

        <Link
          to="/admin/delivery"
          className="p-4 bg-white rounded-2xl border border-gray-200/80 hover:border-emerald-800/40 transition shadow-xs flex items-center gap-3 group"
        >
          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-800 flex items-center justify-center group-hover:scale-105 transition">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-900">Delivery Rules</h4>
            <span className="text-[10px] text-gray-400">₹40 / ₹999 limits</span>
          </div>
        </Link>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-gray-900">Recent Customer Orders</h3>
            <p className="text-xs text-gray-400">Showing newest customer orders placed through website or WhatsApp.</p>
          </div>
          <Link
            to="/admin/orders"
            className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1"
          >
            <span>View All Orders</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-400 uppercase font-semibold text-[10px] tracking-wider border-b border-gray-100">
              <tr>
                <th className="px-5 py-3">Order ID</th>
                <th className="px-5 py-3">Customer</th>
                <th className="px-5 py-3">City / State</th>
                <th className="px-5 py-3">Amount</th>
                <th className="px-5 py-3">Payment</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
              {metrics?.recentOrders && metrics.recentOrders.length > 0 ? (
                metrics.recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50/70 transition">
                    <td className="px-5 py-3.5 font-mono font-bold text-emerald-900">
                      {order.id}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="font-bold text-gray-900">{order.customerName}</div>
                      <div className="text-[10px] text-gray-400">{order.customerPhone}</div>
                    </td>
                    <td className="px-5 py-3.5">
                      {order.shippingAddress.city}, {order.shippingAddress.state} ({order.shippingAddress.pinCode})
                    </td>
                    <td className="px-5 py-3.5 font-bold text-gray-900">
                      ₹{order.totalAmount}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="capitalize">{order.paymentMethod.replace('_', ' ')}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                        {order.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <Link
                        to={`/admin/orders?highlight=${order.id}`}
                        className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-emerald-800 hover:text-white transition text-[11px] font-semibold"
                      >
                        Manage
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-gray-400">
                    No orders recorded yet. Place an order on the storefront to test!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
