/**
 * Cloudflare Worker - Firebase Auth & JWT Verification using Web Crypto
 * Validates Google Firebase ID Tokens server-side on Cloudflare Edge
 */

interface DecodedToken {
  header: { alg: string; kid: string; typ: string };
  payload: {
    iss: string;
    aud: string;
    sub: string;
    email?: string;
    name?: string;
    picture?: string;
    exp: number;
    iat: number;
    auth_time: number;
    user_id?: string;
    phone_number?: string;
  };
  signature: Uint8Array;
  signedData: Uint8Array;
}

// In-memory key cache for Cloudflare Workers isolate
let cachedKeys: Record<string, JsonWebKey> | null = null;
let cachedKeysExpiry = 0;

/**
 * Fetch Google's public JWK keys for Firebase Auth
 */
async function getGooglePublicKeys(): Promise<Record<string, JsonWebKey>> {
  const now = Date.now();
  if (cachedKeys && now < cachedKeysExpiry) {
    return cachedKeys;
  }

  const res = await fetch('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com');
  if (!res.ok) {
    throw new Error('Failed to fetch Google public JWKs for Firebase');
  }

  const data: { keys: Array<JsonWebKey & { kid: string }> } = await res.json();
  const keysMap: Record<string, JsonWebKey> = {};
  for (const k of data.keys) {
    keysMap[k.kid] = k;
  }

  cachedKeys = keysMap;
  // Cache for 1 hour
  cachedKeysExpiry = now + 3600 * 1000;
  return keysMap;
}

function base64UrlDecode(str: string): Uint8Array {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Verify a Firebase ID Token on Cloudflare Edge
 */
export async function verifyFirebaseToken(
  token: string,
  firebaseProjectId: string
): Promise<{ valid: boolean; uid?: string; email?: string; name?: string; picture?: string; error?: string }> {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return { valid: false, error: 'Invalid JWT structure' };
    }

    const header = JSON.parse(new TextDecoder().decode(base64UrlDecode(parts[0])));
    const payload = JSON.parse(new TextDecoder().decode(base64UrlDecode(parts[1])));
    const signature = base64UrlDecode(parts[2]);
    const signedData = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);

    // Check expiration
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) {
      return { valid: false, error: 'Token expired' };
    }

    // Verify Audience & Issuer
    if (firebaseProjectId) {
      if (payload.aud !== firebaseProjectId) {
        return { valid: false, error: `Invalid aud: expected ${firebaseProjectId}, got ${payload.aud}` };
      }
      const expectedIssuer = `https://securetoken.google.com/${firebaseProjectId}`;
      if (payload.iss !== expectedIssuer) {
        return { valid: false, error: `Invalid iss: expected ${expectedIssuer}, got ${payload.iss}` };
      }
    }

    // Verify Cryptographic Signature
    const keys = await getGooglePublicKeys();
    const jwk = keys[header.kid];
    if (!jwk) {
      return { valid: false, error: 'Matching Google public key kid not found' };
    }

    const cryptoKey = await crypto.subtle.importKey(
      'jwk',
      jwk,
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      false,
      ['verify']
    );

    const isValid = await crypto.subtle.verify(
      'RSASSA-PKCS1-v1_5',
      cryptoKey,
      signature as any,
      signedData as any
    );

    if (!isValid) {
      return { valid: false, error: 'Invalid cryptographic signature' };
    }

    return {
      valid: true,
      uid: payload.sub || payload.user_id,
      email: payload.email,
      name: payload.name,
      picture: payload.picture,
    };
  } catch (err: any) {
    return { valid: false, error: err.message || 'Verification exception' };
  }
}
