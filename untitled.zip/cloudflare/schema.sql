-- ==========================================================
-- NOOR AL HUDA ISLAMIC SHOP
-- Cloudflare D1 Relational SQLite Schema
-- Production-Ready Edge Database Configuration
-- ==========================================================

PRAGMA foreign_keys = ON;

-- 1. STORE SETTINGS TABLE
CREATE TABLE IF NOT EXISTS store_settings (
    id TEXT PRIMARY KEY,
    store_name TEXT NOT NULL,
    owner_email TEXT NOT NULL,
    whatsapp_number TEXT,
    standard_delivery_charge REAL DEFAULT 40,
    free_delivery_threshold REAL DEFAULT 999,
    currency_symbol TEXT DEFAULT '₹',
    announcement_text TEXT,
    announcement_active INTEGER DEFAULT 0,
    google_sheets_id TEXT,
    google_drive_folder_id TEXT,
    upi_id TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);

-- 2. CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    image_url TEXT,
    sort_order INTEGER DEFAULT 1,
    is_active INTEGER DEFAULT 1,
    item_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 3. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    sku TEXT,
    description TEXT,
    category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    category_name TEXT,
    brand TEXT DEFAULT 'Noor Al Huda',
    price REAL NOT NULL,
    original_price REAL,
    discount_percentage REAL DEFAULT 0,
    stock INTEGER NOT NULL DEFAULT 0,
    low_stock_threshold INTEGER DEFAULT 5,
    images TEXT NOT NULL,              -- JSON Array of R2 Public URLs
    specifications TEXT,              -- JSON Key-Value pairs
    is_active INTEGER DEFAULT 1,
    is_featured INTEGER DEFAULT 0,
    is_best_seller INTEGER DEFAULT 0,
    is_new_arrival INTEGER DEFAULT 0,
    rating REAL DEFAULT 5.0,
    review_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- 4. PRODUCT VARIANTS TABLE
CREATE TABLE IF NOT EXISTS product_variants (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    sku TEXT,
    price REAL NOT NULL,
    original_price REAL,
    stock INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 5. CUSTOMERS TABLE (Synchronized with Firebase Auth / Registrations)
CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,              -- Firebase UID or auto-generated customer ID
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    photo_url TEXT,
    role TEXT DEFAULT 'customer',
    total_orders INTEGER DEFAULT 0,
    total_spent REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- 6. ADMIN USERS TABLE
CREATE TABLE IF NOT EXISTS admin_users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    role TEXT NOT NULL,               -- 'owner', 'super_admin', 'product_manager', 'order_manager'
    permissions TEXT,                 -- JSON Array of strings
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 7. ORDERS TABLE (Server-Authoritative Pricing & Stock)
CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    idempotency_key TEXT UNIQUE,       -- Prevents duplicate double-orders
    customer_id TEXT,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    shipping_address TEXT NOT NULL,   -- JSON Address Object
    subtotal REAL NOT NULL,
    discount_amount REAL DEFAULT 0,
    delivery_charge REAL DEFAULT 0,
    total_amount REAL NOT NULL,
    coupon_code TEXT,
    status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'
    payment_method TEXT NOT NULL,     -- 'cash_on_delivery', 'whatsapp_assisted', 'upi_manual'
    payment_status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'paid', 'failed'
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- 8. ORDER ITEMS TABLE
CREATE TABLE IF NOT EXISTS order_items (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES products(id),
    product_title TEXT NOT NULL,
    variant_id TEXT,
    variant_name TEXT,
    sku TEXT,
    price REAL NOT NULL,
    quantity INTEGER NOT NULL,
    total REAL NOT NULL,
    image_url TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 9. INVENTORY TRANSACTIONS TABLE (Stock Audit Trail)
CREATE TABLE IF NOT EXISTS inventory_transactions (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id),
    product_title TEXT NOT NULL,
    type TEXT NOT NULL,                -- 'stock_in', 'stock_out', 'adjustment', 'order_fulfillment', 'order_cancellation'
    change_qty INTEGER NOT NULL,
    previous_stock INTEGER NOT NULL,
    new_stock INTEGER NOT NULL,
    order_id TEXT,
    reason TEXT,
    timestamp TEXT DEFAULT (datetime('now'))
);

-- 10. PROMOTIONAL BANNERS TABLE
CREATE TABLE IF NOT EXISTS banners (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT,
    badge TEXT,
    image_url TEXT NOT NULL,          -- R2 Storage URL
    link TEXT,
    button_text TEXT,
    sort_order INTEGER DEFAULT 1,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 11. COUPONS TABLE
CREATE TABLE IF NOT EXISTS coupons (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    discount_type TEXT NOT NULL,       -- 'percentage' | 'fixed'
    discount_value REAL NOT NULL,
    min_order_value REAL DEFAULT 0,
    max_discount REAL,
    usage_limit INTEGER,
    used_count INTEGER DEFAULT 0,
    valid_until TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

-- 12. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT DEFAULT (datetime('now')),
    actor_email TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    details TEXT
);

-- 13. R2 MEDIA ASSETS TABLE (Ref count to prevent deleting shared images)
CREATE TABLE IF NOT EXISTS media_assets (
    id TEXT PRIMARY KEY,
    r2_key TEXT NOT NULL UNIQUE,
    original_name TEXT,
    mime_type TEXT,
    size_bytes INTEGER,
    public_url TEXT NOT NULL,
    reference_count INTEGER DEFAULT 1,
    uploaded_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- ==========================================================
-- INDEXES FOR MAXIMUM EDGE QUERY PERFORMANCE
-- ==========================================================
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_orders_customer_email ON orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_inventory_prod ON inventory_transactions(product_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_media_r2_key ON media_assets(r2_key);
