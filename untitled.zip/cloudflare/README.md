# নূর আল হুদা ইসলামিক শপ - ক্লাউডফ্লেয়ার (Cloudflare) সম্পূর্ণ সংযোগ ও ডিপ্লয়মেন্ট গাইড

এই নির্দেশিকাটি অনুসরণ করে আপনি আপনার **Noor Al Huda Islamic Shop** ই-কমার্স ওয়েবসাইটকে বিনামূল্যে **Cloudflare D1 Database**, **Cloudflare R2 Object Storage**, এবং **Cloudflare Workers API**-এর সঙ্গে সম্পূর্ণ কানেক্ট করতে পারবেন।

---

## ১. কোন কোন সার্ভিস প্রয়োজন হবে (সম্পূর্ণ Free Tier)

| সার্ভিস | ভূমিকা | ফ্রি লিমিট (বাজেট শূন্যের জন্য যথেষ্ট) |
|---|---|---|
| **Cloudflare D1** | SQLite রিলেশনাল ডাটাবেস (প্রোডাক্ট, অর্ডার, কাস্টমার, ইনভেন্টরি, কুপন) | **প্রতিদিন ৫০ লাখ (5M) রিড**, **১ লাখ (100k) রাইট**, **৫ GB স্টোরেজ** |
| **Cloudflare R2** | অবজেক্ট স্টোরেজ (প্রোডাক্ট ও ক্যাটাগরির ছবি) | **১০ GB ফ্রি স্টোরেজ**, **জিরো ইগ্রেস ফি** (ব্যান্ডউইথের কোনো খরচ নেই) |
| **Cloudflare Workers** | সার্ভারলেস ব্যাকএন্ড API ও সিকিউরিটি গেটওয়ে | **প্রতিদিন ১,০০,০০০ রিকোয়েস্ট ফ্রি** |
| **Firebase Auth** | কাস্টমার ও ওনার গুগল লগইন ব্যবস্থা | **প্রতিমাসে ৫০,০০০ অ্যাক্টিভ ইউজার ফ্রি** |

> **ফ্রি কোটা শেষ হলে কী হবে?**
> ক্লাউডফ্লেয়ার ফ্রি লিমিটে পৌঁছালে স্বয়ংক্রিয়ভাবে কোনো চার্জ কাটে না; অতিরিক্ত রিকোয়েস্ট আসলে সাময়িক `429 Too Many Requests` রেসপন্স দেয়। আমাদের নূর আল হুদা শপের জন্য দৈনিক ১০০,০০০ রিকোয়েস্ট এবং ১০ জিবি ছবি সম্পূর্ণ পর্যাপ্ত।

---

## ২. ধাপে ধাপে ক্লাউডফ্লেয়ার সেটআপ নির্দেশিকা

### ধাপ ১: Cloudflare ফ্রি অ্যাকাউন্ট তৈরি
১. [cloudflare.com](https://dash.cloudflare.com/sign-up)-এ গিয়ে একটি ফ্রি অ্যাকাউন্ট খুলুন (যদি আগে না থাকে)।
২. ইমেইল ভেরিফাই করুন।

---

### ধাপ ২: Cloudflare D1 ডাটাবেস তৈরি করুন
১. Cloudflare ড্যাশবোর্ডের বাম পাশের মেনু থেকে **Storage & Databases** > **D1 SQL Database**-এ ক্লিক করুন।
২. **Create Database** বাটনে ক্লিক করুন।
৩. Database Name দিন: `noor-al-huda-db`
৪. তৈরি সম্পন্ন হলে আপনি একটি **Database ID** (যেমন: `a1b2c3d4-xxxx-xxxx-xxxx-xxxxxxxxxxxx`) দেখতে পাবেন।
৫. আপনার প্রজেক্টের `cloudflare/wrangler.jsonc` ফাইলে যান এবং `YOUR_D1_DATABASE_ID`-এর জায়গায় আপনার এই আসল ডাটাবেস আইডিটি বসিয়ে দিন:
```jsonc
"d1_databases": [
  {
    "binding": "DB",
    "database_name": "noor-al-huda-db",
    "database_id": "আপনার_ডাটাবেস_আইডি"
  }
]
```

#### D1-এ টেবিল ও স্কিমা তৈরি করুন (Console বা CLI দিয়ে):
Cloudflare ড্যাশবোর্ডে আপনার ডাটাবেসের **Console** ট্যাবে গিয়ে `cloudflare/schema.sql` ফাইলের সমস্ত কোড কপি করে পেস্ট করে **Execute** চাপুন।
অথবা টার্মিনালে রান করুন:
```bash
cd cloudflare
npx wrangler d1 execute noor-al-huda-db --file=./schema.sql --remote
```

#### বর্তমান ওয়েবসাইটের ডেটা D1-এ ইমপোর্ট করুন:
আপনার বর্তমান সব প্রোডাক্ট, ক্যাটাগরি ও সেটিংস D1-এ পাঠাতে `cloudflare/seed.sql` রান করুন:
```bash
npx wrangler d1 execute noor-al-huda-db --file=./seed.sql --remote
```

---

### ধাপ ৩: Cloudflare R2 বাকেট তৈরি করুন (ছবির জন্য)
১. Cloudflare ড্যাশবোর্ডের বাম মেনু থেকে **Storage & Databases** > **R2 Object Storage**-এ ক্লিক করুন।
২. **Create Bucket** বাটনে ক্লিক করুন।
৩. Bucket Name দিন: `noor-al-huda-media`
৪. Location Hint: **Asia-Pacific (APAC)** নির্বাচন করুন (যাতে ভারত ও বাংলাদেশ থেকে দ্রুততম লোড হয়)।
৫. **Create Bucket**-এ ক্লিক করুন।
৬. (ঐচ্ছিক) যদি কাস্টম ডোমেইন চান, বাকেটের **Settings** > **Public Development URL** বা **Custom Domains** চালু করে `r2.yourdomain.com` দিতে পারেন। নতুবা আমাদের ক্লাউডফ্লেয়ার ওয়ার্কার স্বয়ংক্রিয়ভাবে `/api/images/:key` রুটের মাধ্যমে সরাসরি R2 থেকে সর্বোচ্চ ক্যাশ স্পিডে ছবি সার্ভ করবে!

---

### ধাপ ৪: Cloudflare Worker API ডিপ্লয় করুন
১. আপনার কম্পিউটারের টার্মিনালে প্রজেক্টের `cloudflare` ফোল্ডারে যান:
```bash
cd cloudflare
```
২. Cloudflare অ্যাকাউন্টে লগইন করুন:
```bash
npx wrangler login
```
(ব্রাউজারে একটি উইন্ডো খুলে "Allow" কনফার্মেশন চাইবে, অনুমোদন দিন)

৩. ওয়ার্কারটি ডিপ্লয় করে দিন:
```bash
npx wrangler deploy
```
৪. ডিপ্লয় সফল হলে টার্মিনালে আপনার লাইভ Worker URL দেখতে পাবেন, যেমন:
`https://noor-al-huda-backend.<your-subdomain>.workers.dev`

---

### ধাপ ৫: Environment Variables ও Secrets সেটআপ
আমাদের `wrangler.jsonc`-এ ডিফল্ট ভেরিয়েবল দেওয়া আছে:
- `FIREBASE_PROJECT_ID`: `gen-lang-client-0937578981`
- `ADMIN_EMAILS`: `uskshayeem@gmail.com,shayeemuddinsk@gmail.com`

Cloudflare ড্যাশবোর্ডে গিয়ে আপনার Worker > **Settings** > **Variables** ট্যাবে এগুলো যেকোনো সময় পরিবর্তন করতে পারবেন।

---

### ধাপ ৬: Firebase Authentication ও Cloudflare Workers সংযোগ কীভাবে কাজ করছে
১. ক্লায়েন্ট ব্রাউজারে কাস্টমার বা অ্যাডমিন Google Sign-In সম্পন্ন করলে Firebase একটি ক্রিপ্টোগ্রাফিক **Firebase ID Token** (JWT) প্রদান করে।
২. ব্রাউজার থেকে যখনই কোনো সুরক্ষিত API রিকোয়েস্ট (যেমন: অর্ডার দেখা, প্রোডাক্ট তৈরি/ডিলিট, ইনভেন্টরি বদল) পাঠানো হয়, হেডারে `Authorization: Bearer <ID_TOKEN>` থাকে।
৩. Cloudflare Worker-এ থাকা `src/firebaseAuth.ts` ফাইলটি Google-এর অফিশিয়াল পাবলিক কিউ (JWK) ব্যবহার করে ক্লাউড এজ-এ তাৎক্ষণিক টোকেনের ডিজিটাল সিগনেচার যাচাই করে।
৪. যাচাই সফল হলে কাস্টমারের ইমেইলটি ওনার ইমেইল (`shayeemuddinsk@gmail.com` বা `uskshayeem@gmail.com`) কিনা তা দেখে সরাসরি ওনার রোল প্রদান করে। ফলে কোনো অননুমোদিত ব্যক্তি অ্যাডমিন API ব্যবহার করতে পারে না।

---

### ধাপ ৭: Frontend ওয়েবসাইটে Cloudflare API URL বসানো
আপনার ফ্রন্টএন্ড ওয়েবসাইটের `.env` বা ক্লাউড হোস্টিংয়ে (Cloudflare Pages বা Vercel বা এই প্রজেক্টের `.env`) নিচের লাইনটি যুক্ত করুন:

```env
VITE_CLOUDFLARE_WORKER_URL=https://noor-al-huda-backend.<your-subdomain>.workers.dev
```

> **উল্লেখ্য:** যদি `VITE_CLOUDFLARE_WORKER_URL` সেট না থাকে, তবে ওয়েবসাইটটি বর্তমানের মতোই হাই-পারফরম্যান্স লোকাল/সার্ভার ব্যাকএন্ড ব্যবহার করবে। ফলে ডিপ্লয় করার আগে বা পরে ওয়েবসাইট কখনো অফলাইন হবে না!

---

### ধাপ ৮: কীভাবে পরীক্ষা করবেন যে ডেটা সত্যিই Cloudflare-এ সংরক্ষিত হচ্ছে?

১. **অ্যাডমিন ড্যাশবোর্ড থেকে লাইভ টেস্ট:**
   - ওয়েবসাইটের অ্যাডমিন প্যানেলে লগইন করুন।
   - নতুন মেনু **"Cloudflare Hub"**-এ যান।
   - সেখানে আপনার Worker URL বসিয়ে **"Ping Worker & Test Connection"** বাটনে ক্লিক করুন।
   - সিস্টেম সরাসরি Cloudflare D1 ডাটাবেস ও R2 বাকেটে পিং পাঠিয়ে মিলিসেকেন্ডে রেসপন্স স্ট্যাটাস দেখিয়ে দেবে।

২. **D1 ডাটাবেস কোয়েরি টেস্ট (CLI):**
   ```bash
   npx wrangler d1 execute noor-al-huda-db --command="SELECT count(*) FROM products;" --remote
   ```
   এটি চালালে ক্লাউডফ্লেয়ার D1-এ থাকা আসল প্রোডাক্ট কাউন্ট দেখতে পাবেন।

৩. **R2 বাকেট ফাইল টেস্ট (CLI):**
   ```bash
   npx wrangler r2 object list noor-al-huda-media
   ```
   এটি চালালে R2-তে আপলোড হওয়া সমস্ত ছবির তালিকা আসবে।

---

## ৩. নিরাপত্তা ও বেস্ট প্র্যাকটিস যা বাস্তবায়ন করা হয়েছে
1. **No Tokens in Frontend:** Cloudflare API Token বা R2 Secrets কখনো ফ্রন্টএন্ডে এক্সপোজ করা হয়নি।
2. **Server-Side Token Verification:** শুধু ব্রাউজার থেকে পাঠানো UID বা ইমেইল বিশ্বাস করা হয় না; Google-এর ক্রিপ্টোগ্রাফিক পাবলিক কিউ দিয়ে প্রতিটি টোকেন যাচাই করা হয়।
3. **Idempotency Protection:** ডাবল ক্লিক বা নেটওয়ার্ক ল্যাগের কারণে একই অর্ডার যেন বারবার প্লেস না হয়, তার জন্য `x-idempotency-key` ব্যবহার করা হয়েছে।
4. **Authoritative Server Pricing:** ব্রাউজার থেকে পাঠানো দাম গ্রাহ্য করা হয় না; D1 ডাটাবেস থেকে আসল দাম ও স্টক যাচাই করে সার্ভার স্বয়ংক্রিয়ভাবে টোটাল ও ডেলিভারি চার্জ হিসাব করে।
5. **Safe Image Cleanup:** প্রোডাক্ট ডিলিট করার সময় যদি সেই একই ছবি অন্য কোনো প্রোডাক্টে ব্যবহার করা থাকে, তবে R2 থেকে তা ভুলবশত ডিলিট হবে না।
