/**
 * Google Apps Script for NOOR AL HUDA ISLAMIC SHOP
 * Automatically creates and configures the canonical 15 worksheets with exact column headers.
 * 
 * Instructions:
 * 1. Open your Google Spreadsheet in Google Chrome.
 * 2. Tap Extensions > Apps Script.
 * 3. Replace any code with this file and tap "Run".
 * 4. All 15 worksheets will be generated automatically!
 */

function setupNoorAlHuda15Worksheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  const worksheets = [
    {
      name: "Customers",
      headers: ["Customer ID", "Full Name", "Email", "Phone", "Total Orders", "Total Spent (INR)", "Created At"]
    },
    {
      name: "Products",
      headers: ["Product ID", "Title", "SKU", "Category ID", "Price", "Original Price", "Stock", "Is Active", "Rating"]
    },
    {
      name: "Categories",
      headers: ["Category ID", "Name", "Slug", "Description", "Sort Order", "Is Active"]
    },
    {
      name: "Orders",
      headers: ["Order ID", "Customer Name", "Customer Email", "Phone", "Subtotal", "Discount", "Delivery Fee", "Total Amount", "Status", "Payment Method", "Payment Status", "Created At"]
    },
    {
      name: "OrderItems",
      headers: ["Item ID", "Order ID", "Product ID", "Product Title", "Variant", "SKU", "Price", "Quantity", "Line Total"]
    },
    {
      name: "Inventory",
      headers: ["Product ID", "Title", "Total Stock", "Reserved Units", "Available For Sale"]
    },
    {
      name: "Addresses",
      headers: ["Address ID", "User ID", "Full Name", "Phone", "House/Flat", "Street", "City", "State", "PIN Code", "Address Type"]
    },
    {
      name: "Banners",
      headers: ["Banner ID", "Title", "Subtitle", "Eyebrow", "Image URL", "Button Text", "Button Link", "Sort Order", "Is Active"]
    },
    {
      name: "Coupons",
      headers: ["Coupon ID", "Code", "Discount Type", "Value", "Min Order Value", "Max Discount", "Times Used", "Is Active"]
    },
    {
      name: "Reviews",
      headers: ["Review ID", "Product ID", "Customer Name", "Rating (1-5)", "Comment", "Created At"]
    },
    {
      name: "Wishlist",
      headers: ["Wishlist Item ID", "User ID", "Product ID", "Added At"]
    },
    {
      name: "Notifications",
      headers: ["Notification ID", "User ID", "Title", "Message", "Is Read", "Created At"]
    },
    {
      name: "StoreSettings",
      headers: ["Store Name", "Owner Email", "WhatsApp Number", "Standard Delivery (INR)", "Free Delivery Threshold (INR)", "Currency", "UPI ID"]
    },
    {
      name: "AdminUsers",
      headers: ["Admin ID", "Email", "Name", "Role", "Phone", "Permissions", "Created At"]
    },
    {
      name: "AuditLogs",
      headers: ["Log ID", "Timestamp", "Actor Email", "Action", "Entity Type", "Entity ID", "Details"]
    }
  ];

  worksheets.forEach(function(item) {
    let sheet = ss.getSheetByName(item.name);
    if (!sheet) {
      sheet = ss.insertSheet(item.name);
    }
    
    // Set headers if empty
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(item.headers);
      const headerRange = sheet.getRange(1, 1, 1, item.headers.length);
      headerRange.setFontWeight("bold");
      headerRange.setBackground("#064E3B"); // Emerald 900
      headerRange.setFontColor("#FFFFFF");
      sheet.setFrozenRows(1);
    }
  });

  // Remove default 'Sheet1' if present and other sheets exist
  const defaultSheet = ss.getSheetByName("Sheet1");
  if (defaultSheet && ss.getSheets().length > 1) {
    try {
      ss.deleteSheet(defaultSheet);
    } catch (e) {
      // Ignored
    }
  }

  Logger.log("All 15 worksheets configured successfully for NOOR AL HUDA ISLAMIC SHOP!");
}
