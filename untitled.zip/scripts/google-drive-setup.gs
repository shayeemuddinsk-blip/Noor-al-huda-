/**
 * Google Apps Script for NOOR AL HUDA ISLAMIC SHOP
 * Run this in https://script.google.com or Extensions > Apps Script in Google Drive
 * to automatically create the folder structure and get your GOOGLE_DRIVE_FOLDER_ID.
 */

function setupNoorAlHudaDrive() {
  const rootFolderName = "NOOR AL HUDA ISLAMIC SHOP";
  
  // 1. Check if folder already exists
  const existingFolders = DriveApp.getFoldersByName(rootFolderName);
  let rootFolder;
  
  if (existingFolders.hasNext()) {
    rootFolder = existingFolders.next();
    Logger.log("Existing root folder found: " + rootFolderName);
  } else {
    rootFolder = DriveApp.createFolder(rootFolderName);
    Logger.log("Created root folder: " + rootFolderName);
  }
  
  const rootId = rootFolder.getId();
  Logger.log("==================================================");
  Logger.log("YOUR GOOGLE_DRIVE_FOLDER_ID IS:");
  Logger.log(rootId);
  Logger.log("==================================================");
  
  // 2. Create standard store subfolders
  const subfolders = ["products", "banners", "categories"];
  subfolders.forEach(function(subName) {
    const existing = rootFolder.getFoldersByName(subName);
    if (!existing.hasNext()) {
      rootFolder.createFolder(subName);
      Logger.log("Created subfolder: " + subName);
    }
  });
  
  Logger.log("All subfolders are ready for product uploads!");
  return rootId;
}
